// Dirty Dozen Security Test Matrix for firestore.rules
// Verifies identity isolation, family room passcode gates, strict schema keys, server timestamps, ID guards, and query constraints.

export const DIRTY_DOZEN_CASES = [
  { name: "unauth_read_workspace", path: "/users/u1", op: "get", expected: "PERMISSION_DENIED" },
  { name: "cross_user_read_workspace", path: "/users/victim", op: "get", caller: "attacker", expected: "PERMISSION_DENIED" },
  { name: "unverified_email_create", path: "/users/u1", op: "create", verified: false, expected: "PERMISSION_DENIED" },
  { name: "shadow_admin_field_create", path: "/users/u1", op: "create", payload: { isAdmin: true }, expected: "PERMISSION_DENIED" },
  { name: "owner_uid_spoof_vital", path: "/users/attacker/vitals/v1", op: "create", payload: { ownerUid: "victim" }, expected: "PERMISSION_DENIED" },
  { name: "client_forged_timestamp", path: "/users/u1/reports/r1", op: "create", forgedTime: true, expected: "PERMISSION_DENIED" },
  { name: "oversized_channel_exhaustion", path: "/rooms/FAM1/channels/chat", op: "update", itemsJsonLen: 120001, expected: "PERMISSION_DENIED" },
  { name: "invalid_doc_id_poisoning", path: "/rooms/bad$room!/members/u1", op: "create", expected: "PERMISSION_DENIED" },
  { name: "wrong_room_passcode_join", path: "/rooms/FAM1/members/attacker", op: "create", payload: { passcode: "0000" }, expected: "PERMISSION_DENIED" },
  { name: "forged_owner_role_on_join", path: "/rooms/FAM1/members/member2", op: "create", payload: { role: "owner" }, expected: "PERMISSION_DENIED" },
  { name: "non_member_room_passcode_scrape", path: "/rooms/FAM1", op: "get", caller: "outsider", expected: "PERMISSION_DENIED" },
  { name: "unscoped_message_list_query", path: "/users/u1/messages", op: "list", filterOwnerUid: "other", expected: "PERMISSION_DENIED" },
] as const;
