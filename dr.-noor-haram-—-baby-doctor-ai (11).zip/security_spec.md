# Firestore Security Specification — Dr. Noor Haram AI

## 1. Data Invariants
1. No unauthenticated caller may read or write any Firestore document (`request.auth != null` and `request.auth.token.email_verified == true`).
2. Users may only read, list, create, update, or delete their own `/users/{userId}` document and subcollections (`messages`, `reminders`, `diary`, `vitals`, `reports`) where `request.auth.uid == userId` AND the parent `/users/{userId}` exists for subcollection writes.
3. Shared Multi-Phone Family Rooms (`/rooms/{roomId}`) are strictly non-listable (`allow list: if false;`), readable only by the room owner or verified members in `/rooms/{roomId}/members/{request.auth.uid}`, and joining `/rooms/{roomId}/members/{memberUid}` requires `incoming().passcode == get(.../rooms/$(roomId)).data.passcode` plus `memberUid == request.auth.uid`.
4. Shared Room Channels (`/rooms/{roomId}/channels/{channelId}`) are restricted to the fixed allowlist `['chat', 'reminders', 'diary', 'vitals', 'reports']`, non-listable, and readable/writable only by current room members.
5. Every `uid` / `ownerUid` / `memberUid` / `updatedByUid` field MUST strictly match `request.auth.uid` on create/write and remain immutable where applicable.
6. All document IDs must satisfy `^[a-zA-Z0-9_\-]+$` with length <= 128 (`roomId` <= 32).
7. Every string field has strict `.size()` upper bounds, enums are validated against explicit allowlists, and unknown/shadow keys are rejected (`hasOnly`).
8. All `createdAt`, `updatedAt`, and `joinedAt` timestamps must equal server `request.time`.

## 2. Dirty Dozen Adversarial Payloads
1. Unauthenticated read/write to `/users/u1` -> PERMISSION_DENIED.
2. Cross-user read (`get`) on `/users/victimUid` by `attackerUid` -> PERMISSION_DENIED.
3. Unverified email (`email_verified: false`) writing `/users/u1` -> PERMISSION_DENIED.
4. Shadow/ghost field injection (`{ uid: "u1", isAdmin: true, ... }`) -> PERMISSION_DENIED (`hasOnly` rejects).
5. Owner spoofing on message/vital/report create (`{ ownerUid: "victimUid", ... }` inside `/users/attackerUid/...`) -> PERMISSION_DENIED.
6. Client-forged timestamp (`createdAt: Timestamp.fromMillis(0)`) -> PERMISSION_DENIED (`== request.time` rejects).
7. Oversized `content` (> 16000) or `itemsJson` (> 120000) exhaustion attack -> PERMISSION_DENIED.
8. Invalid ID poisoning (`/users/u1/messages/bad$id!` or `/rooms/bad$room`) -> PERMISSION_DENIED.
9. Joining `/rooms/{roomId}/members/{uid}` with wrong passcode or forging `role: "owner"` -> PERMISSION_DENIED.
10. Non-member reading `/rooms/{roomId}` (to scrape passcode) or `/rooms/{roomId}/channels/chat` -> PERMISSION_DENIED.
11. Listing `/rooms` or `/rooms/{roomId}/members` -> PERMISSION_DENIED (`allow list: if false`).
12. Creating a subcollection item when parent `/users/{userId}` or `/rooms/{roomId}` does not exist -> PERMISSION_DENIED (`exists()` Master Gate).
