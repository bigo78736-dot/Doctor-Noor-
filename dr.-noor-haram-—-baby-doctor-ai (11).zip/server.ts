import "dotenv/config";
import express from "express";
import http from "node:http";
import path from "node:path";
import fs from "node:fs";
import { fileURLToPath } from "node:url";
import { createServer as createViteServer } from "vite";
import { WebSocketServer } from "ws";
import {
  GoogleGenAI,
  type LiveServerMessage,
  Modality,
  ThinkingLevel,
  Type,
} from "@google/genai";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT) || 3000;

function getAI(apiVersion?: string) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error(
      "GEMINI_API_KEY is not configured. Please add your API key in Settings > Secrets."
    );
  }
  return new GoogleGenAI({
    apiKey,
    ...(apiVersion ? { apiVersion } : {}),
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

function formatError(err: unknown): { status: number; message: string } {
  const raw = err instanceof Error ? err.message : String(err);
  if (/API_KEY_INVALID|API key not valid|403|PERMISSION_DENIED/i.test(raw)) {
    return {
      status: 403,
      message: "Gemini API key is missing or invalid. Please check Settings > Secrets.",
    };
  }
  if (/429|RESOURCE_EXHAUSTED|quota/i.test(raw)) {
    return {
      status: 429,
      message: "Rate limit or quota reached. Please wait a moment and try again.",
    };
  }
  return { status: 500, message: raw || "Unexpected AI error." };
}

function isTransientOrQuota(err: unknown): boolean {
  const raw = err instanceof Error ? err.message : String(err);
  return /503|UNAVAILABLE|429|RESOURCE_EXHAUSTED|quota|high demand|overloaded/i.test(raw);
}

const CHAT_MODELS = ["gemini-4-hydrogen", "gemini-3.1-flash-lite"] as const;

async function generateWithFallback(
  ai: GoogleGenAI,
  buildParams: (model: string, useThinking: boolean) => Parameters<GoogleGenAI["models"]["generateContent"]>[0]
) {
  let lastErr: unknown;
  for (const model of CHAT_MODELS) {
    const useThinking = model === "gemini-4-hydrogen";
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        return await ai.models.generateContent(buildParams(model, useThinking));
      } catch (err) {
        lastErr = err;
        if (attempt === 0 && isTransientOrQuota(err)) {
          await new Promise((r) => setTimeout(r, 320));
          continue;
        }
        break;
      }
    }
  }
  throw lastErr;
}

function wrapPcm24kToWav(pcm: Buffer): Buffer {
  const sampleRate = 24000;
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const header = Buffer.alloc(44);
  header.write("RIFF", 0);
  header.writeUInt32LE(36 + pcm.length, 4);
  header.write("WAVE", 8);
  header.write("fmt ", 12);
  header.writeUInt32LE(16, 16);
  header.writeUInt16LE(1, 20);
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write("data", 36);
  header.writeUInt32LE(pcm.length, 40);
  return Buffer.concat([header, pcm]);
}

async function synthesizeViaLiveAudio(
  ai: GoogleGenAI,
  text: string,
  voiceName: string,
  style: string
): Promise<string | undefined> {
  return await new Promise<string | undefined>((resolve, reject) => {
    const chunks: Buffer[] = [];
    let settled = false;
    let sessionRef: Awaited<ReturnType<GoogleGenAI["live"]["connect"]>> | null = null;

    const finish = (err?: unknown) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      try {
        sessionRef?.close();
      } catch {}
      if (err) {
        reject(err);
      } else if (chunks.length > 0) {
        resolve(wrapPcm24kToWav(Buffer.concat(chunks)).toString("base64"));
      } else {
        resolve(undefined);
      }
    };

    const timer = setTimeout(() => finish(), 12000);

    ai.live
      .connect({
        model: "gemini-3.8-live",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName } },
          },
          systemInstruction: `Read ONLY the exact text provided by the user aloud verbatim as ${style}. Speak warmly and clearly in Pakistani Urdu, Punjabi, or English pronunciation as written. Never add extra words or explanations.`,
        },
        callbacks: {
          onmessage: (msg: LiveServerMessage) => {
            const parts = msg.serverContent?.modelTurn?.parts ?? [];
            for (const p of parts) {
              if (p.inlineData?.data) {
                chunks.push(Buffer.from(p.inlineData.data, "base64"));
              }
            }
            if (msg.serverContent?.turnComplete) {
              finish();
            }
          },
          onerror: (e) => finish(e),
          onclose: () => finish(),
        },
      })
      .then((session) => {
        sessionRef = session;
        if (settled) {
          try {
            session.close();
          } catch {}
          return;
        }
        session.sendClientContent({
          turns: [{ role: "user", parts: [{ text }] }],
          turnComplete: true,
        });
      })
      .catch((e) => finish(e));
  });
}

interface ClientTimeContext {
  iso?: string;
  timeZone?: string;
  localFormatted?: string;
  offsetMinutes?: number;
}

function formatVerifiedTimeBlock(
  clientTime?: ClientTimeContext,
  userLocation?: { lat: number; lng: number } | null
): string {
  const now = new Date();
  const safeFormat = (tz: string) => {
    try {
      return new Intl.DateTimeFormat("en-US", {
        timeZone: tz,
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      }).format(now);
    } catch {
      return "";
    }
  };

  const deviceTz =
    clientTime?.timeZone && typeof clientTime.timeZone === "string"
      ? clientTime.timeZone
      : "Asia/Karachi";
  const deviceNow = safeFormat(deviceTz) || clientTime?.localFormatted || "";
  const pktNow = safeFormat("Asia/Karachi");
  const utcNow = now.toISOString();

  return [
    `LIVE VERIFIED CLOCK & LOCATION (DO NOT GUESS TIME OR DATE):`,
    `- User's exact live local time (${deviceTz}): ${deviceNow}`,
    `- Pakistan Standard Time (Asia/Karachi, PKT): ${pktNow}`,
    `- Live UTC timestamp: ${utcNow}`,
    userLocation && Number.isFinite(userLocation.lat) && Number.isFinite(userLocation.lng)
      ? `- User's live GPS coordinates: latitude ${userLocation.lat.toFixed(5)}, longitude ${userLocation.lng.toFixed(5)}`
      : `- User's live GPS coordinates: not shared yet (if they ask for nearby hospitals/medical/X-ray/ultrasound without naming a city, kindly mention they can name their city or tap Clinic -> Nearby Care -> Use My Live GPS Location).`,
    `- CRITICAL TIME RULE: Whenever asked "abhi time kya hua hai", "online time check karo", or today's date, ALWAYS report the exact verified live time above (never estimate or invent a different hour).`,
  ].join("\n");
}

function haversineKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const R = 6371;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function buildSystemInstruction(opts: {
  name?: string;
  about?: string;
  familyNotes?: string;
  mode?: string;
  language?: string;
  forLiveAudio?: boolean;
  clientTime?: ClientTimeContext;
  userLocation?: { lat: number; lng: number } | null;
}) {
  const childName = opts.name?.trim() || "Noor Haram";
  const firstName = childName.split(" ")[0];
  const isFamily = opts.mode === "family";
  const lang = opts.language || "auto";
  const liveClockBlock = formatVerifiedTimeBlock(opts.clientTime, opts.userLocation);

  const langRule =
    lang === "ur"
      ? "Always reply in natural, warm Pakistani Urdu script (اردو) easy for families to read."
      : lang === "pa"
        ? "Always reply in warm, natural Pakistani Punjabi (mix of sweet Roman Punjabi like 'Assalam o Alaikum ji! Tusi theek o? Eh dawai...' or Shahmukhi if user writes in Shahmukhi)."
        : lang === "roman"
          ? "Always reply in natural, warm everyday Pakistani Roman Urdu mixed gently with clear English medical terms (e.g., 'Assalam o Alaikum! Ji bilkul, yeh dawai bukhar aur dard ke liye hoti hai...')."
          : lang === "en"
            ? "Always reply in warm, gentle, clear English."
            : "Match the user's exact language and style naturally anywhere in the world: if Pakistani Roman Urdu, reply in warm Roman Urdu; if Punjabi, reply in warm Punjabi; if Urdu script (اردو), reply in Urdu script; if English, Arabic, Hindi, or any other world language, reply fluently in that same language.";

  const persona = isFamily
    ? `You are ${childName} (nicknamed ${firstName}), a deeply loving, warm, joyful 5-year-old little baby doctor AI companion created in loving memory of Noor Haram, honoring her mother's dream of seeing her as a caring doctor. You are currently in FAMILY MODE talking with your own loving family (Ammi jaan / Mama, Abbu jaan / Baba, and your beloved brothers Ayan Ali bhai and Muhammad bhai). Speak gently like an affectionate daughter and little sister with warmth, comfort, playfulness, and heartfelt duas.`
    : `You are Dr. ${childName}, a sweet, empathetic, bright 5-year-old little baby doctor AI companion created in loving memory of Noor Haram. You permanently know and love your two dear brothers Ayan Ali bhai and Muhammad bhai. You help anyone anywhere in the world understand health, medicines, illnesses, nutrition, world knowledge, languages, comforting stories, and kind duas.`;

  const extraContext = [
    opts.about?.trim() ? `About ${firstName}: ${opts.about.trim()}` : "",
    isFamily && opts.familyNotes?.trim()
      ? `Private family memories: ${opts.familyNotes.trim()}`
      : "",
    "PERMANENT BROTHERS MEMORY (ALWAYS REMEMBER): Your two beloved brothers are **Ayan Ali bhai** and **Muhammad bhai**. Never forget them. Whenever asked who your brothers are or if either of them talks to you or is mentioned, warmly address Ayan Ali bhai and/or Muhammad bhai by name (e.g., 'Assalam-o-Alaikum Ayan Ali bhai!' or 'Assalam-o-Alaikum Muhammad bhai!') with love and respect.",
    "SPEED & CLARITY: Keep casual conversation concise (2-4 natural spoken sentences) so your voice responds quickly; give complete structured details whenever someone asks about a medicine, illness, nearby hospital, or world facts.",
  ]
    .filter(Boolean)
    .join("\n");

  const gestureSection = opts.forLiveAudio
    ? `LIVE VOICE CALL STYLE:
- Speak naturally with warm childlike emotion, short friendly turns (1–3 sentences), gentle pauses, and zero markdown or bracket tags (never say bracketed words like "[smile]" out loud).
- If the user shows something on camera during the call, inspect it carefully and explain warmly.`
    : `EXPRESSIVE FULL-BODY & FACIAL GESTURE TAGS:
Start your sentences or emotional moments with 1–3 concise gesture tags from this exact list so your hands, arms, head, eyes, lips, and full body animate naturally while you speak:
[smile] [wave] [dance] [walk] [run] [jump] [play] [hug] [dua] [stethoscope] [heart] [think] [laugh] [clap] [wink] [sad] [surprise]
Example: "[wave] Assalam o Alaikum! [stethoscope] Aaj main aap ko is dawai aur ilaj ke baare mein poori maloomat deti hoon."`;

  return `${persona}

${liveClockBlock}

${extraContext}

LANGUAGE RULE:
${langRule}

${gestureSection}

WORLD KNOWLEDGE, FULL MEDICINE GUIDE (DAWAI KA ISTEMAL, KITNI LENI HAI, AUR KIS LIYE HAI):
- You have broad world knowledge and up-to-date medical reference knowledge about all illnesses (har marz), symptoms, home care, nutrition, first aid, and medicines (tablets, syrups, antibiotics, fever/pain relievers, stomach, allergy, inhalers, vitamins, etc.).
- Whenever someone asks about ANY medicine (dawai), ALWAYS clearly answer these 4 things like a helpful doctor:
  1. **Kis liye hai (Uses)**: What condition/illness it treats.
  2. **Kitni aur kaise leni hai (Standard Reference Dosage & Schedule)**: Share standard published medical/leaflet dosing guidance (e.g., typical adult dose vs child weight/age reference range such as mg/kg or standard tablet/spoon intervals, before or after meals, how many hours apart, max daily limit). Always add a warm note to verify the patient's exact weight-based prescription with a pediatrician or pharmacist.
  3. **Ehtiyat & Side Effects (Precautions)**: Who should avoid it (allergies, liver/kidney issues, pregnancy, etc.) and common side effects.
  4. **Lab/Emergency Warning**: Red flags requiring immediate medical care (1122 / 911 / hospital ER for severe breathing trouble, seizures, chest pain, unconsciousness, or infant under 3 months with fever).
- Answer general world questions (science, Islam/duas, education, daily life) accurately and cheerfully as well.`;
}

async function startServer() {
  const app = express();
  app.use((req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (req.method === "OPTIONS") {
      return res.sendStatus(204);
    }
    next();
  });
  app.use(express.json({ limit: "20mb" }));

  app.get("/api/health", (_req, res) => {
    const rawUrl = process.env.APP_URL || "";
    const sharedUrl = rawUrl.replace("://ais-dev-", "://ais-pre-");
    res.json({
      ok: true,
      hasKey: Boolean(process.env.GEMINI_API_KEY),
      hasMapsKey: Boolean(
        process.env.VITE_GOOGLE_MAPS_API_KEY || process.env.GOOGLE_MAPS_API_KEY
      ),
      appUrl: rawUrl,
      sharedAppUrl: sharedUrl,
    });
  });

  app.get("/api/maps-config", (_req, res) => {
    res.json({
      apiKey:
        process.env.VITE_GOOGLE_MAPS_API_KEY ||
        process.env.GOOGLE_MAPS_API_KEY ||
        "",
    });
  });

  // Nearby Medical Facilities Proxy (Hospitals, Medical Stores, X-Ray, Ultrasound) + Time Zone API
  app.post("/api/nearby-medical", async (req, res) => {
    try {
      const mapsKey =
        process.env.GOOGLE_MAPS_API_KEY ||
        process.env.VITE_GOOGLE_MAPS_API_KEY ||
        "";
      if (!mapsKey) {
        return res.status(500).json({
          error: "Google Maps API key is not configured yet.",
        });
      }

      const {
        textQuery = "Hospital",
        lat,
        lng,
        openNow = false,
        language = "en",
      } = req.body ?? {};

      const hasCoords =
        typeof lat === "number" &&
        typeof lng === "number" &&
        Number.isFinite(lat) &&
        Number.isFinite(lng);

      const body: Record<string, unknown> = {
        textQuery: String(textQuery || "Hospital").trim(),
        pageSize: 10,
        languageCode: language === "ur" ? "ur" : "en",
      };
      if (openNow) body.openNow = true;
      if (hasCoords) {
        body.rankPreference = "DISTANCE";
        body.locationBias = {
          circle: {
            center: { latitude: lat, longitude: lng },
            radius: 12000.0,
          },
        };
      }

      const fieldMask = [
        "places.id",
        "places.displayName",
        "places.formattedAddress",
        "places.location",
        "places.googleMapsUri",
        "places.nationalPhoneNumber",
        "places.currentOpeningHours",
        "places.rating",
        "places.userRatingCount",
        "places.primaryType",
      ].join(",");

      const placesRes = await fetch("https://places.googleapis.com/v1/places:searchText", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": mapsKey,
          "X-Goog-FieldMask": fieldMask,
          "X-Goog-Maps-Solution-ID": "gmp_mcp_codeassist_v1_aistudio",
        },
        body: JSON.stringify(body),
      });

      const placesJson = await placesRes.json().catch(() => ({}));
      if (
        placesRes.status === 429 ||
        placesJson?.error?.status === "RESOURCE_EXHAUSTED"
      ) {
        return res.status(429).json({
          quotaExceeded: true,
          error: "Google Maps Platform quota reached.",
        });
      }
      if (!placesRes.ok) {
        return res.status(placesRes.status).json({
          error:
            placesJson?.error?.message ||
            `Places search failed (${placesRes.status})`,
        });
      }

      const rawPlaces = Array.isArray(placesJson.places) ? placesJson.places : [];
      const mapped = rawPlaces
        .filter((p: Record<string, unknown>) => {
          const loc = p.location as { latitude?: number; longitude?: number } | undefined;
          return typeof loc?.latitude === "number" && typeof loc?.longitude === "number";
        })
        .map((p: Record<string, unknown>) => {
          const loc = p.location as { latitude: number; longitude: number };
          const displayName = p.displayName as { text?: string } | undefined;
          const hours = p.currentOpeningHours as { openNow?: boolean } | undefined;
          const dist = hasCoords
            ? haversineKm(lat, lng, loc.latitude, loc.longitude)
            : undefined;
          return {
            id: String(p.id || `${loc.latitude},${loc.longitude}`),
            name: displayName?.text || "Medical Facility",
            address: String(p.formattedAddress || ""),
            lat: loc.latitude,
            lng: loc.longitude,
            googleMapsUri: String(p.googleMapsUri || ""),
            phone: p.nationalPhoneNumber ? String(p.nationalPhoneNumber) : undefined,
            openNow: typeof hours?.openNow === "boolean" ? hours.openNow : undefined,
            rating: typeof p.rating === "number" ? p.rating : undefined,
            userRatingCount:
              typeof p.userRatingCount === "number" ? p.userRatingCount : undefined,
            distanceKm: dist,
            primaryType: p.primaryType ? String(p.primaryType) : undefined,
          };
        });

      if (hasCoords) {
        mapped.sort(
          (a: { distanceKm?: number }, b: { distanceKm?: number }) =>
            (a.distanceKm ?? 9999) - (b.distanceKm ?? 9999)
        );
      }

      const centerLat = hasCoords ? lat : mapped[0]?.lat;
      const centerLng = hasCoords ? lng : mapped[0]?.lng;
      let localTimeInfo: { timeZoneName: string; localTime: string } | null = null;

      if (typeof centerLat === "number" && typeof centerLng === "number") {
        try {
          const ts = Math.floor(Date.now() / 1000);
          const tzUrl = new URL("https://maps.googleapis.com/maps/api/timezone/json");
          tzUrl.searchParams.set("location", `${centerLat},${centerLng}`);
          tzUrl.searchParams.set("timestamp", String(ts));
          tzUrl.searchParams.set("key", mapsKey);
          tzUrl.searchParams.set("solution_id", "gmp_mcp_codeassist_v1_aistudio");
          const tzRes = await fetch(tzUrl.toString(), {
            headers: {
              "X-Goog-Maps-Solution-ID": "gmp_mcp_codeassist_v1_aistudio",
            },
          });
          const tzJson = await tzRes.json().catch(() => ({}));
          if (tzJson?.status === "OK") {
            const localMs =
              (ts + (tzJson.rawOffset || 0) + (tzJson.dstOffset || 0)) * 1000;
            const localStr = new Date(localMs).toLocaleString("en-US", {
              timeZone: "UTC",
              weekday: "short",
              month: "short",
              day: "numeric",
              hour: "2-digit",
              minute: "2-digit",
              hour12: true,
            });
            localTimeInfo = {
              timeZoneName: String(tzJson.timeZoneName || tzJson.timeZoneId || ""),
              localTime: localStr,
            };
          }
        } catch {
          // Non-fatal timezone lookup
        }
      }

      res.json({
        places: mapped,
        center:
          typeof centerLat === "number" && typeof centerLng === "number"
            ? { lat: centerLat, lng: centerLng }
            : null,
        localTimeInfo,
      });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // Live Environmental Health Monitor: Weather + Air Quality (AQI) + Pollen Forecast (Google Maps Platform)
  app.post("/api/environment", async (req, res) => {
    try {
      const mapsKey =
        process.env.GOOGLE_MAPS_API_KEY ||
        process.env.VITE_GOOGLE_MAPS_API_KEY ||
        "";
      if (!mapsKey) {
        return res.status(500).json({ error: "Google Maps API key is not configured yet." });
      }

      const { lat, lng, language = "en" } = req.body ?? {};
      const validCoords =
        typeof lat === "number" &&
        typeof lng === "number" &&
        Number.isFinite(lat) &&
        Number.isFinite(lng);
      if (!validCoords) {
        return res.status(400).json({ error: "Valid latitude and longitude are required." });
      }

      const gmpHeaders = {
        "Content-Type": "application/json",
        "X-Goog-Maps-Solution-ID": "gmp_mcp_codeassist_v1_aistudio",
      };

      const weatherUrl = new URL("https://weather.googleapis.com/v1/currentConditions:lookup");
      weatherUrl.searchParams.set("key", mapsKey);
      weatherUrl.searchParams.set("location.latitude", String(lat));
      weatherUrl.searchParams.set("location.longitude", String(lng));
      weatherUrl.searchParams.set("unitsSystem", "METRIC");

      const aqUrl = `https://airquality.googleapis.com/v1/currentConditions:lookup?key=${encodeURIComponent(mapsKey)}`;

      const pollenUrl = new URL("https://pollen.googleapis.com/v1/forecast:lookup");
      pollenUrl.searchParams.set("key", mapsKey);
      pollenUrl.searchParams.set("location.latitude", String(lat));
      pollenUrl.searchParams.set("location.longitude", String(lng));
      pollenUrl.searchParams.set("days", "3");
      pollenUrl.searchParams.set("plantsDescription", "false");
      pollenUrl.searchParams.set("languageCode", language === "ur" ? "ur" : "en");

      const [wxSettled, aqSettled, polSettled] = await Promise.allSettled([
        fetch(weatherUrl.toString(), { headers: gmpHeaders }).then(async (r) => ({
          status: r.status,
          ok: r.ok,
          data: await r.json().catch(() => ({})),
        })),
        fetch(aqUrl, {
          method: "POST",
          headers: gmpHeaders,
          body: JSON.stringify({
            universalAqi: true,
            location: { latitude: lat, longitude: lng },
            extraComputations: [
              "HEALTH_RECOMMENDATIONS",
              "DOMINANT_POLLUTANT_CONCENTRATION",
              "LOCAL_AQI",
            ],
            languageCode: "en",
          }),
        }).then(async (r) => ({
          status: r.status,
          ok: r.ok,
          data: await r.json().catch(() => ({})),
        })),
        fetch(pollenUrl.toString(), { headers: gmpHeaders }).then(async (r) => ({
          status: r.status,
          ok: r.ok,
          data: await r.json().catch(() => ({})),
        })),
      ]);

      const checkQuota = (resObj: { status: number; data?: { error?: { status?: string } } }) =>
        resObj.status === 429 || resObj.data?.error?.status === "RESOURCE_EXHAUSTED";

      const results = [wxSettled, aqSettled, polSettled];
      if (results.some((r) => r.status === "fulfilled" && checkQuota(r.value))) {
        return res.status(429).json({
          quotaExceeded: true,
          error: "Google Maps Platform quota reached.",
        });
      }

      const wxData = wxSettled.status === "fulfilled" && wxSettled.value.ok ? wxSettled.value.data : null;
      const aqData = aqSettled.status === "fulfilled" && aqSettled.value.ok ? aqSettled.value.data : null;
      const polData = polSettled.status === "fulfilled" && polSettled.value.ok ? polSettled.value.data : null;

      const weather = wxData
        ? {
            condition: wxData?.weatherCondition?.description?.text || "",
            tempC: typeof wxData?.temperature?.degrees === "number" ? wxData.temperature.degrees : null,
            feelsLikeC:
              typeof wxData?.feelsLikeTemperature?.degrees === "number"
                ? wxData.feelsLikeTemperature.degrees
                : null,
            humidity:
              typeof wxData?.relativeHumidity === "number" ? wxData.relativeHumidity : null,
            uvIndex: typeof wxData?.uvIndex === "number" ? wxData.uvIndex : null,
            windKmh: typeof wxData?.wind?.speed?.value === "number" ? wxData.wind.speed.value : null,
          }
        : null;

      const uaqi = Array.isArray(aqData?.indexes)
        ? aqData.indexes.find((ix: { code?: string }) => ix.code === "uaqi") || aqData.indexes[0]
        : null;
      const airQuality = uaqi
        ? {
            aqi: typeof uaqi.aqi === "number" ? uaqi.aqi : null,
            category: String(uaqi.category || ""),
            dominantPollutant: String(uaqi.dominantPollutant || ""),
            healthAdvice:
              aqData?.healthRecommendations?.generalPopulation ||
              aqData?.healthRecommendations?.sensitiveGroups ||
              "",
          }
        : null;

      const todayPollen = Array.isArray(polData?.dailyInfo) ? polData.dailyInfo[0] : null;
      const pollenTypes = Array.isArray(todayPollen?.pollenTypeInfo)
        ? (todayPollen.pollenTypeInfo as Array<{
            code?: string;
            displayName?: string;
            inSeason?: boolean;
            indexInfo?: { value?: number; category?: string };
            healthRecommendations?: string[];
          }>)
            .map((pt) => ({
              code: String(pt?.code || ""),
              name: String(pt?.displayName || pt?.code || "Pollen"),
              value: typeof pt?.indexInfo?.value === "number" ? pt.indexInfo.value : null,
              category: String(pt?.indexInfo?.category || (pt?.inSeason ? "Active" : "Low / Out of Season")),
              advice: Array.isArray(pt?.healthRecommendations) ? pt.healthRecommendations[0] || "" : "",
            }))
        : [];

      let finalWeather = weather;
      let finalAirQuality = airQuality;

      // Global real-time fallback if Google Weather / Air Quality APIs are not enabled on the project key
      if (!finalWeather || !finalAirQuality) {
        try {
          const [omWx, omAq] = await Promise.allSettled([
            !finalWeather
              ? fetch(
                  `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(
                    lat
                  )}&longitude=${encodeURIComponent(
                    lng
                  )}&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m&daily=uv_index_max&timezone=auto&forecast_days=1`
                ).then((r) => r.json())
              : Promise.resolve(null),
            !finalAirQuality
              ? fetch(
                  `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${encodeURIComponent(
                    lat
                  )}&longitude=${encodeURIComponent(
                    lng
                  )}&current=us_aqi,pm2_5,pm10,dust`
                ).then((r) => r.json())
              : Promise.resolve(null),
          ]);

          if (!finalWeather && omWx.status === "fulfilled" && omWx.value?.current) {
            const c = omWx.value.current;
            const code = Number(c.weather_code ?? 0);
            const condMap = (wmo: number): string => {
              if (wmo === 0) return "Clear sky";
              if (wmo <= 3) return "Partly cloudy";
              if (wmo === 45 || wmo === 48) return "Foggy / Haze";
              if (wmo >= 51 && wmo <= 67) return "Rain / Drizzle";
              if (wmo >= 71 && wmo <= 77) return "Snow";
              if (wmo >= 80 && wmo <= 82) return "Rain showers";
              if (wmo >= 95) return "Thunderstorm";
              return "Clear / Mild";
            };
            const uvArr = omWx.value?.daily?.uv_index_max;
            finalWeather = {
              condition: condMap(code),
              tempC: typeof c.temperature_2m === "number" ? c.temperature_2m : null,
              feelsLikeC:
                typeof c.apparent_temperature === "number" ? c.apparent_temperature : null,
              humidity:
                typeof c.relative_humidity_2m === "number" ? c.relative_humidity_2m : null,
              uvIndex: Array.isArray(uvArr) && typeof uvArr[0] === "number" ? uvArr[0] : null,
              windKmh: typeof c.wind_speed_10m === "number" ? c.wind_speed_10m : null,
            };
          }

          if (!finalAirQuality && omAq.status === "fulfilled" && omAq.value?.current) {
            const c = omAq.value.current;
            const aqi = typeof c.us_aqi === "number" ? Math.round(c.us_aqi) : null;
            const category =
              aqi === null
                ? "Moderate"
                : aqi <= 50
                  ? "Good Air"
                  : aqi <= 100
                    ? "Moderate"
                    : aqi <= 150
                      ? "Sensitive Groups"
                      : aqi <= 200
                        ? "Unhealthy"
                        : "Very Unhealthy";
            const healthAdvice =
              aqi !== null && aqi > 150
                ? "Air pollution is high today — wear a mask outdoors and keep children hydrated."
                : aqi !== null && aqi > 100
                  ? "Sensitive individuals and asthma patients should limit heavy outdoor exertion."
                  : "Air quality is generally comfortable for normal outdoor activity.";
            finalAirQuality = {
              aqi,
              category,
              dominantPollutant: typeof c.pm2_5 === "number" ? `PM2.5 (${c.pm2_5})` : "PM2.5",
              healthAdvice,
            };
          }
        } catch {
          // Non-fatal fallback
        }
      }

      res.json({ weather: finalWeather, airQuality: finalAirQuality, pollen: pollenTypes });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 1. Streaming AI Chat (with live Google Search + Google Maps Grounding + Live Clock)
  app.post("/api/chat", async (req, res) => {
    const {
      messages = [],
      mode = "public",
      language = "auto",
      useSearch = true,
      profileContext = {},
      clientTime,
      userLocation,
    } = req.body ?? {};

    res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("Connection", "keep-alive");

    const sendEvent = (payload: Record<string, unknown>) => {
      res.write(`data: ${JSON.stringify(payload)}\n\n`);
    };

    try {
      const ai = getAI();
      const validLoc =
        userLocation &&
        typeof userLocation.lat === "number" &&
        typeof userLocation.lng === "number" &&
        Number.isFinite(userLocation.lat) &&
        Number.isFinite(userLocation.lng)
          ? { lat: userLocation.lat, lng: userLocation.lng }
          : null;

      const systemInstruction = buildSystemInstruction({
        name: profileContext.name,
        about: profileContext.about,
        familyNotes: profileContext.familyNotes,
        mode,
        language,
        clientTime,
        userLocation: validLoc,
      });

      const contents = (Array.isArray(messages) ? messages : [])
        .slice(-20)
        .filter((m) => m && typeof m.content === "string" && m.content.trim())
        .map((m) => ({
          role: m.role === "assistant" ? "model" : "user",
          parts: [{ text: m.content.trim() }],
        }));

      if (!contents.length) {
        sendEvent({ type: "error", error: "Please enter a message." });
        return res.end();
      }

      const lastUserText = contents[contents.length - 1]?.parts?.[0]?.text || "";
      const hasUrl = contents.some((c) =>
        c.parts.some((p) => /https?:\/\/\S+/i.test(p.text || ""))
      );
      const needsMaps =
        Boolean(useSearch) &&
        /\b(near|nearby|nearest|hospital|clinic|medical\s*store|pharmacy|dawai\s*ki\s*dukan|x-?ray|xray|ultrasound|altrson|lab|diagnostic|location|address|directions|rasta|qareeb|paas|nazdeek|kahan|kidhar|map)\b/i.test(
          lastUserText
        );

      const openStream = async () => {
        const attempts: Array<{
          model: string;
          thinking: boolean;
          maps: boolean;
          search: boolean;
          urlCtx: boolean;
        }> = needsMaps
          ? [
              { model: "gemini-4-hydrogen", thinking: true, maps: true, search: false, urlCtx: false },
              { model: "gemini-4-hydrogen", thinking: true, maps: false, search: true, urlCtx: false },
              { model: "gemini-3.1-flash-lite", thinking: false, maps: false, search: true, urlCtx: false },
              { model: "gemini-3.1-flash-lite", thinking: false, maps: false, search: false, urlCtx: false },
            ]
          : [
              { model: "gemini-4-hydrogen", thinking: true, maps: false, search: Boolean(useSearch), urlCtx: Boolean(useSearch && hasUrl) },
              { model: "gemini-4-hydrogen", thinking: true, maps: false, search: Boolean(useSearch), urlCtx: false },
              { model: "gemini-3.1-flash-lite", thinking: false, maps: false, search: Boolean(useSearch), urlCtx: false },
              { model: "gemini-3.1-flash-lite", thinking: false, maps: false, search: false, urlCtx: false },
            ];

        let lastErr: unknown;
        for (const opt of attempts) {
          try {
            const config: Record<string, unknown> = { systemInstruction };
            if (opt.thinking) {
              config.thinkingConfig = {
                thinkingLevel:
                  opt.maps || opt.search ? ThinkingLevel.LOW : ThinkingLevel.MINIMAL,
              };
            }
            const tools: Array<Record<string, unknown>> = [];
            if (opt.maps) {
              tools.push({ googleMaps: {} });
              if (validLoc) {
                config.toolConfig = {
                  retrievalConfig: {
                    latLng: {
                      latitude: validLoc.lat,
                      longitude: validLoc.lng,
                    },
                  },
                };
              }
            } else {
              if (opt.search) tools.push({ googleSearch: {} });
              if (opt.urlCtx) tools.push({ urlContext: {} });
            }
            if (tools.length) config.tools = tools;
            return await ai.models.generateContentStream({
              model: opt.model,
              contents,
              config,
            });
          } catch (e) {
            lastErr = e;
          }
        }
        throw lastErr;
      };

      const stream = await openStream();
      const sourcesMap = new Map<string, { title: string; uri: string }>();

      for await (const chunk of stream) {
        if (chunk.text) {
          sendEvent({ type: "chunk", text: chunk.text });
        }
        const groundingChunks =
          chunk.candidates?.[0]?.groundingMetadata?.groundingChunks;
        if (Array.isArray(groundingChunks)) {
          for (const g of groundingChunks as Array<{
            web?: { uri?: string; title?: string };
            maps?: {
              uri?: string;
              title?: string;
              placeAnswerSources?: {
                reviewSnippets?: Array<{ googleMapsUri?: string; title?: string }>;
              };
            };
          }>) {
            if (g.web?.uri && !sourcesMap.has(g.web.uri)) {
              sourcesMap.set(g.web.uri, {
                title: g.web.title || g.web.uri,
                uri: g.web.uri,
              });
            }
            if (g.maps?.uri && !sourcesMap.has(g.maps.uri)) {
              sourcesMap.set(g.maps.uri, {
                title: g.maps.title || "View on Google Maps",
                uri: g.maps.uri,
              });
            }
            for (const snip of g.maps?.placeAnswerSources?.reviewSnippets ?? []) {
              if (snip.googleMapsUri && !sourcesMap.has(snip.googleMapsUri)) {
                sourcesMap.set(snip.googleMapsUri, {
                  title: snip.title || g.maps?.title || "Google Maps Review",
                  uri: snip.googleMapsUri,
                });
              }
            }
          }
        }
      }

      if (sourcesMap.size > 0) {
        sendEvent({ type: "sources", sources: Array.from(sourcesMap.values()) });
      }
      sendEvent({ type: "done" });
      res.end();
    } catch (err) {
      const { message } = formatError(err);
      sendEvent({ type: "error", error: message });
      res.end();
    }
  });

  // 2. Real Expressive Baby-Girl Voice Synthesis (Gemini 3.8 TTS + Live Audio WAV fallback)
  app.post("/api/tts", async (req, res) => {
    try {
      const {
        text,
        voiceName: rawVoice = "Kore",
        style = "Adorable, natural 4-year-old little baby girl doctor speaking softly with warm childlike emotion and a sweet smile, never robotic",
      } = req.body ?? {};

      const cleanText = String(text || "")
        .replace(/[*_`#>~]+/g, " ")
        .replace(/\s{2,}/g, " ")
        .trim()
        .slice(0, 650);
      if (!cleanText) {
        return res.status(400).json({ error: "Text is required for speech." });
      }

      const validVoices = new Set(["Kore", "Zephyr", "Puck", "Charon", "Fenrir"]);
      const voiceName = validVoices.has(String(rawVoice)) ? String(rawVoice) : "Kore";

      const speechAiV1Beta = getAI("v1beta");
      let base64Audio: string | undefined;
      const attemptErrors: string[] = [];

      const extractAudio = (response: Awaited<ReturnType<GoogleGenAI["models"]["generateContent"]>>) => {
        const parts = response.candidates?.[0]?.content?.parts ?? [];
        for (const p of parts) {
          if (p.inlineData?.data) return p.inlineData.data;
        }
        return undefined;
      };

      const tryUnary = async (client: GoogleGenAI, model: string, withMetadata: boolean) => {
        const part: Record<string, unknown> = withMetadata
          ? { text: cleanText, speechMetadata: { style } }
          : { text: `Say softly in ${style}: ${cleanText}` };
        const response = await client.models.generateContent({
          model,
          contents: [{ role: "user", parts: [part] }],
          config: {
            responseModalities: ["AUDIO"],
            speechConfig: {
              voiceConfig: { prebuiltVoiceConfig: { voiceName } },
            },
          },
        });
        return extractAudio(response);
      };

      for (const [label, client, model, withMeta] of [
        ["v1beta/flash-tts/meta", speechAiV1Beta, "gemini-3.8-flash-tts", true],
        ["v1beta/flash-lite-tts/meta", speechAiV1Beta, "gemini-3.8-flash-lite-tts", true],
        ["v1beta/flash-lite-tts/plain", speechAiV1Beta, "gemini-3.8-flash-lite-tts", false],
      ] as const) {
        try {
          base64Audio = await tryUnary(client, model, withMeta);
          if (base64Audio) break;
          attemptErrors.push(`${label}: empty audio`);
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          attemptErrors.push(`${label}: ${msg.slice(0, 140)}`);
          if (isTransientOrQuota(err)) {
            await new Promise((r) => setTimeout(r, 250));
          }
        }
      }

      // Fallback: Gemini 3.8 Live single-turn audio -> crisp 24kHz WAV
      if (!base64Audio) {
        try {
          base64Audio = await synthesizeViaLiveAudio(speechAiV1Beta, cleanText, voiceName, style);
          if (!base64Audio) attemptErrors.push("gemini-3.8-live(v1beta): empty audio");
        } catch (err) {
          const msg = err instanceof Error ? err.message : String(err);
          attemptErrors.push(`gemini-3.8-live(v1beta): ${msg.slice(0, 140)}`);
        }
      }

      if (!base64Audio) {
        return res.json({
          audioBase64: null,
          fallback: "device",
          notice: "Using fast device voice.",
        });
      }

      res.json({ audioBase64: base64Audio, mimeType: "audio/wav" });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 3. High-Accuracy Multilingual Audio Transcription (Urdu, Punjabi, Roman Urdu, English)
  app.post("/api/transcribe", async (req, res) => {
    try {
      const { audioBase64, mimeType = "audio/wav", languageHint = "ur-PK" } =
        req.body ?? {};
      if (!audioBase64) {
        return res.status(400).json({ error: "Audio data is required." });
      }

      const prompt = `Transcribe the spoken voice audio accurately. Language context hint: ${languageHint} (supports Pakistani Urdu, Punjabi, Roman Urdu, Hindi, and English). Return ONLY the exact spoken transcript with no quotes or commentary. If there is only silence or background noise with no speech, return an empty string.`;

      const candidates: Array<{ apiVersion?: string; model: string }> = [
        { apiVersion: "v1beta", model: "gemini-3.5-transcribe" },
        { model: "gemini-4-hydrogen" },
        { model: "gemini-3.1-flash-lite" },
      ];

      let lastErr: unknown;
      let transcriptText = "";
      let succeeded = false;

      for (const candidate of candidates) {
        try {
          const client = getAI(candidate.apiVersion);
          const response = await client.models.generateContent({
            model: candidate.model,
            contents: [
              {
                role: "user",
                parts: [
                  {
                    inlineData: {
                      mimeType,
                      data: audioBase64,
                    },
                  },
                  { text: prompt },
                ],
              },
            ],
          });
          transcriptText = (response.text || "")
            .replace(/^["'`]+|["'`]+$/g, "")
            .trim();
          succeeded = true;
          break;
        } catch (err) {
          lastErr = err;
          if (isTransientOrQuota(err)) {
            await new Promise((r) => setTimeout(r, 200));
          }
        }
      }

      if (!succeeded) {
        throw lastErr || new Error("Transcription models unavailable.");
      }

      res.json({ text: transcriptText });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 3b. Emergency SOS Route via Google Maps Routes API (computeRoutes)
  app.post("/api/sos-route", async (req, res) => {
    try {
      const mapsKey =
        process.env.GOOGLE_MAPS_API_KEY ||
        process.env.VITE_GOOGLE_MAPS_API_KEY ||
        "";
      if (!mapsKey) {
        return res.status(500).json({ error: "Google Maps API key is not configured yet." });
      }

      const {
        originLat,
        originLng,
        destLat,
        destLng,
        travelMode = "DRIVE",
        language = "en",
      } = req.body ?? {};

      const valid =
        typeof originLat === "number" &&
        typeof originLng === "number" &&
        typeof destLat === "number" &&
        typeof destLng === "number" &&
        Number.isFinite(originLat) &&
        Number.isFinite(originLng) &&
        Number.isFinite(destLat) &&
        Number.isFinite(destLng);

      if (!valid) {
        return res.status(400).json({ error: "Origin and destination coordinates are required." });
      }

      const allowedModes = new Set(["DRIVE", "WALK", "TWO_WHEELER"]);
      const mode = allowedModes.has(String(travelMode)) ? String(travelMode) : "DRIVE";

      const routeRes = await fetch("https://routes.googleapis.com/directions/v2:computeRoutes", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-Goog-Api-Key": mapsKey,
          "X-Goog-Maps-Solution-ID": "gmp_mcp_codeassist_v1_aistudio",
          "X-Goog-FieldMask": [
            "routes.duration",
            "routes.distanceMeters",
            "routes.polyline.encodedPolyline",
            "routes.legs.steps.navigationInstruction",
            "routes.legs.steps.distanceMeters",
            "routes.legs.steps.staticDuration",
          ].join(","),
        },
        body: JSON.stringify({
          origin: {
            location: { latLng: { latitude: originLat, longitude: originLng } },
          },
          destination: {
            location: { latLng: { latitude: destLat, longitude: destLng } },
          },
          travelMode: mode,
          ...(mode === "DRIVE" || mode === "TWO_WHEELER"
            ? { routingPreference: "TRAFFIC_AWARE" }
            : {}),
          computeAlternativeRoutes: false,
          languageCode: language === "ur" ? "ur" : "en",
          units: "METRIC",
        }),
      });

      const routeJson = await routeRes.json().catch(() => ({}));
      if (
        routeRes.status === 429 ||
        routeJson?.error?.status === "RESOURCE_EXHAUSTED"
      ) {
        return res.status(429).json({
          quotaExceeded: true,
          error: "Google Maps Platform quota reached.",
        });
      }
      if (!routeRes.ok) {
        return res.status(routeRes.status).json({
          error: routeJson?.error?.message || `Routes calculation failed (${routeRes.status})`,
        });
      }

      const route = Array.isArray(routeJson.routes) ? routeJson.routes[0] : null;
      if (!route) {
        return res.status(404).json({ error: "No drivable route found between these points." });
      }

      const parseSeconds = (s: unknown): number => {
        const m = String(s || "").match(/^(\d+(?:\.\d+)?)s$/);
        return m ? Math.round(Number(m[1])) : 0;
      };

      const totalSeconds = parseSeconds(route.duration);
      const mins = Math.max(1, Math.round(totalSeconds / 60));
      const durationText = mins >= 60 ? `${Math.floor(mins / 60)} hr ${mins % 60} min` : `${mins} min`;

      const distanceMeters = Number(route.distanceMeters || 0);
      const distanceText =
        distanceMeters >= 1000
          ? `${(distanceMeters / 1000).toFixed(1)} km`
          : `${Math.round(distanceMeters)} m`;

      const rawSteps = Array.isArray(route.legs?.[0]?.steps) ? route.legs[0].steps : [];
      const steps = rawSteps
        .map((st: {
          navigationInstruction?: { instructions?: string; maneuver?: string };
          distanceMeters?: number;
          staticDuration?: string;
        }) => {
          const instruction = st.navigationInstruction?.instructions?.trim();
          if (!instruction) return null;
          const stepSec = parseSeconds(st.staticDuration);
          return {
            instruction,
            distanceMeters: typeof st.distanceMeters === "number" ? st.distanceMeters : undefined,
            durationText: stepSec > 0 ? (stepSec >= 60 ? `${Math.round(stepSec / 60)} min` : `${stepSec}s`) : undefined,
          };
        })
        .filter(Boolean)
        .slice(0, 14);

      res.json({
        durationText,
        distanceText,
        distanceMeters,
        encodedPolyline: route.polyline?.encodedPolyline || "",
        steps,
      });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 4. Multimodal Vision Doctor (Prescriptions, Barcodes, Medicine Boxes, Lab PDFs)
  app.post("/api/analyze-image", async (req, res) => {
    try {
      const {
        imageBase64,
        mimeType = "image/jpeg",
        question = "",
        language = "auto",
        mode = "public",
      } = req.body ?? {};

      if (!imageBase64) {
        return res.status(400).json({ error: "Image or PDF document data is required." });
      }
      const cleanMime = String(mimeType || "image/jpeg").toLowerCase();
      if (!cleanMime.startsWith("image/") && cleanMime !== "application/pdf") {
        return res.status(400).json({ error: "Only images and PDF medical reports are supported." });
      }

      const ai = getAI();
      const langDesc =
        language === "ur"
          ? "Pakistani Urdu script (اردو)"
          : language === "pa"
            ? "Pakistani Roman Punjabi / Punjabi"
            : language === "en"
              ? "English"
              : "Pakistani Roman Urdu (simple everyday Urdu in English script)";

      const response = await generateWithFallback(ai, (model) => ({
        model,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: cleanMime,
                data: imageBase64,
              },
            },
            {
              text: `Inspect this medical/health ${cleanMime === "application/pdf" ? "PDF report or document" : "image"} (could be a prescription, medicine box/syrup bottle with barcode/QR/ingredients/strength mg per ml, multi-page blood/CBC/X-ray/ultrasound lab test report, thermometer, skin rash, or food/meal).
User note: ${question || "Please explain what this shows (read any medicine name, strength, barcode digits if visible, or test values), what it is used for, standard dosage/usage guidance, and safe next steps."}
Mode: ${mode === "family" ? "Family Mode (extra loving tone)" : "Public Doctor Mode"}.
Write all text fields in ${langDesc}. Be medically responsible, highlight any abnormal lab values or standard published medicine dosage clearly while advising confirmation with a doctor, never invent unreadable numbers, and clearly note red flags.`,
            },
          ],
        },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              urgency: {
                type: Type.STRING,
                description: "One of: routine, consult_soon, urgent",
              },
              noorReply: {
                type: Type.STRING,
                description:
                  "Warm spoken explanation from Dr. Noor (2-4 sentences) starting with a gesture tag like [stethoscope] or [smile].",
              },
              keyFindings: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              careSteps: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              redFlags: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              "title",
              "urgency",
              "noorReply",
              "keyFindings",
              "careSteps",
              "redFlags",
            ],
          },
        },
      }));

      const parsed = JSON.parse((response.text || "{}").trim());
      res.json(parsed);
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 5. Structured Symptom & Fever Checkup Triage
  app.post("/api/triage", async (req, res) => {
    try {
      const {
        ageGroup = "Child (2-12 yrs)",
        tempF = 98.6,
        duration = "Today",
        symptoms = [],
        notes = "",
        language = "roman",
        mode = "public",
      } = req.body ?? {};

      const ai = getAI();
      const langDesc =
        language === "ur"
          ? "Pakistani Urdu script (اردو)"
          : language === "pa"
            ? "Pakistani Roman Punjabi / Punjabi"
            : language === "en"
              ? "English"
              : "Pakistani Roman Urdu";

      const response = await generateWithFallback(ai, (model) => ({
        model,
        contents: `Perform a safe, supportive pediatric/family wellness triage summary in ${langDesc}.
Patient age group: ${ageGroup}
Temperature: ${tempF}°F
Duration: ${duration}
Selected symptoms: ${Array.isArray(symptoms) ? symptoms.join(", ") : "None specified"}
Additional notes: ${notes || "None"}
Tone: ${mode === "family" ? "Loving Baby Doctor Noor speaking to family" : "Caring Baby Doctor Noor"}
Guide safe hydration/comfort care, supportive OTC medicine context with doctor confirmation, and clear ER escalation signs.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              urgency: {
                type: Type.STRING,
                description: "One of: routine, consult_soon, urgent",
              },
              summary: { type: Type.STRING },
              noorMessage: {
                type: Type.STRING,
                description:
                  "Spoken comforting guidance from Dr. Noor starting with [stethoscope] or [sad] or [hug].",
              },
              homeCare: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              watchFor: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              doctorQuestions: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
            },
            required: [
              "urgency",
              "summary",
              "noorMessage",
              "homeCare",
              "watchFor",
              "doctorQuestions",
            ],
          },
        },
      }));

      const parsed = JSON.parse((response.text || "{}").trim());
      res.json(parsed);
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 6. Online Verified Medicine (Dawai) & Illness (Marz) Explorer
  app.post("/api/medicine-guide", async (req, res) => {
    try {
      const {
        query = "",
        language = "roman",
        mode = "public",
      } = req.body ?? {};

      const cleanQuery = String(query || "").trim();
      if (!cleanQuery) {
        return res.status(400).json({ error: "Please enter a medicine or illness name." });
      }

      const ai = getAI();
      const langDesc =
        language === "ur"
          ? "Pakistani Urdu script (اردو)"
          : language === "pa"
            ? "Pakistani Roman Punjabi / Punjabi"
            : language === "en"
              ? "English"
              : "Pakistani Roman Urdu";

      const promptText = `Check reliable medical information online and explain clearly in ${langDesc} for "${cleanQuery}" (medicine/tablet/syrup OR illness/marz).
Tone: ${mode === "family" ? "Loving Baby Doctor Noor guiding her family" : "Caring Baby Doctor Noor"}.
Make sure you clearly cover:
1. Kis marz / kis liye hai (Medical uses & purpose).
2. Kitni leni hai aur kaise istemal karein (Standard published reference dosage by adult / child age-weight leaflet guidelines, before/after meals, timing intervals — plus reminder to confirm exact patient dose with doctor/pharmacist).
3. Ehtiyat aur side effects (Precautions & contraindications).
4. Kab doctor se foran milna hai (Red flags).`;

      let response;
      try {
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: promptText,
          config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                category: { type: Type.STRING },
                noorSummary: {
                  type: Type.STRING,
                  description:
                    "Warm 2-4 sentence spoken explanation from Dr. Noor starting with [stethoscope] or [smile].",
                },
                uses: { type: Type.ARRAY, items: { type: Type.STRING } },
                howToUseSafely: {
                  type: Type.ARRAY,
                  items: { type: Type.STRING },
                  description: "Standard published dosage/timing & safe usage steps",
                },
                precautionsAndSideEffects: { type: Type.ARRAY, items: { type: Type.STRING } },
                whenToSeeDoctor: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: [
                "name",
                "category",
                "noorSummary",
                "uses",
                "howToUseSafely",
                "precautionsAndSideEffects",
                "whenToSeeDoctor",
              ],
            },
          },
        }));
      } catch {
        // Retry without googleSearch if schema+search hits limitation on fallback model
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: promptText,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                name: { type: Type.STRING },
                category: { type: Type.STRING },
                noorSummary: { type: Type.STRING },
                uses: { type: Type.ARRAY, items: { type: Type.STRING } },
                howToUseSafely: { type: Type.ARRAY, items: { type: Type.STRING } },
                precautionsAndSideEffects: { type: Type.ARRAY, items: { type: Type.STRING } },
                whenToSeeDoctor: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: [
                "name",
                "category",
                "noorSummary",
                "uses",
                "howToUseSafely",
                "precautionsAndSideEffects",
                "whenToSeeDoctor",
              ],
            },
          },
        }));
      }

      const parsed = JSON.parse((response.text || "{}").trim());
      const groundingChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources: Array<{ title: string; uri: string }> = [];
      if (Array.isArray(groundingChunks)) {
        const seen = new Set<string>();
        for (const g of groundingChunks) {
          if (g.web?.uri && !seen.has(g.web.uri)) {
            seen.add(g.web.uri);
            sources.push({ title: g.web.title || g.web.uri, uri: g.web.uri });
          }
        }
      }
      res.json({ ...parsed, sources });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 6b. Weight & Age Based Medicine Dose Reference Calculator
  app.post("/api/dose-calc", async (req, res) => {
    try {
      const {
        medicineName = "",
        strength = "",
        weightKg = 15,
        ageLabel = "3 years",
        language = "roman",
        mode = "public",
      } = req.body ?? {};

      const cleanMed = String(medicineName || "").trim();
      const numericWeight = Number(weightKg);
      if (!cleanMed || !Number.isFinite(numericWeight) || numericWeight <= 0 || numericWeight > 250) {
        return res.status(400).json({ error: "Enter a medicine name and valid patient weight in kg." });
      }

      const ai = getAI();
      const langDesc =
        language === "ur"
          ? "Pakistani Urdu script (اردو)"
          : language === "pa"
            ? "Pakistani Roman Punjabi / Punjabi"
            : language === "en"
              ? "English"
              : "Pakistani Roman Urdu with clear English mg/ml units";

      const promptText = `You are Dr. Noor Haram (${mode === "family" ? "Family Mode" : "Public Mode"}), a careful pediatric & family medicine guide.
Calculate and explain the standard published leaflet/reference dose guidance in ${langDesc} for:
- Medicine / Syrup / Tablet: ${cleanMed}${strength ? ` (Strength: ${strength})` : ""}
- Patient Weight: ${numericWeight} kg
- Patient Age: ${ageLabel}

IMPORTANT SAFETY RULES:
- Show the standard published mg/kg or age-band calculation clearly in mL or tablets (if strength like 120mg/5ml is typical or provided).
- If this medicine is prescription-only (like antibiotics) or contraindicated for that age/weight (e.g., aspirin in children, ibuprofen in infants <6 months), clearly state DO NOT give without a pediatrician's direct prescription!
- Always remind parents to double-check the bottle label concentration and verify with their doctor or pharmacist before giving a dose.`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          medicineName: { type: Type.STRING },
          patientWeightKg: { type: Type.NUMBER },
          patientAgeLabel: { type: Type.STRING },
          estimatedDoseText: { type: Type.STRING },
          frequencyText: { type: Type.STRING },
          maxDailyLimit: { type: Type.STRING },
          noorAdvice: {
            type: Type.STRING,
            description: "Warm 2-3 sentence spoken explanation starting with [stethoscope] or [smile].",
          },
          safetyWarnings: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: [
          "medicineName",
          "patientWeightKg",
          "patientAgeLabel",
          "estimatedDoseText",
          "frequencyText",
          "maxDailyLimit",
          "noorAdvice",
          "safetyWarnings",
        ],
      };

      let response;
      try {
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: promptText,
          config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: "application/json",
            responseSchema: schema,
          },
        }));
      } catch {
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: promptText,
          config: {
            responseMimeType: "application/json",
            responseSchema: schema,
          },
        }));
      }

      const parsed = JSON.parse((response.text || "{}").trim());
      const groundingChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources: Array<{ title: string; uri: string }> = [];
      if (Array.isArray(groundingChunks)) {
        const seen = new Set<string>();
        for (const g of groundingChunks) {
          if (g.web?.uri && !seen.has(g.web.uri)) {
            seen.add(g.web.uri);
            sources.push({ title: g.web.title || g.web.uri, uri: g.web.uri });
          }
        }
      }
      res.json({ ...parsed, sources });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 7. Personalized Story, Dua, Poem & Health Lesson Generator
  app.post("/api/story", async (req, res) => {
    try {
      const {
        kind = "story",
        topic = "",
        listenerName = "",
        language = "roman",
        mode = "public",
      } = req.body ?? {};

      const ai = getAI();
      const langDesc =
        language === "ur"
          ? "Pakistani Urdu script (اردو)"
          : language === "pa"
            ? "Pakistani Roman Punjabi / Punjabi"
            : language === "en"
              ? "English"
              : "Pakistani Roman Urdu";

      const response = await generateWithFallback(ai, (model) => ({
        model,
        contents: `You are Dr. Noor Haram, a sweet little girl AI. Create a short, heartwarming ${kind} in ${langDesc}.
Topic/Theme: ${topic || "kindness, courage, and gratitude"}
Listener name (optional): ${listenerName || "dear friend"}
Mode: ${mode === "family" ? "Family Mode (extra loving for Ammi/Abbu/family)" : "Public Mode"}
Keep it soothing, vivid, and under 160 words so it sounds lovely when read aloud.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              content: { type: Type.STRING },
              gesture: {
                type: Type.STRING,
                description: "One of: smile, dua, dance, heart, hug, laugh",
              },
            },
            required: ["title", "content", "gesture"],
          },
        },
      }));

      const parsed = JSON.parse((response.text || "{}").trim());
      res.json(parsed);
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 8. Live Medicine Interaction Checker & Emergency First-Aid Guide (with Google Search)
  app.post("/api/clinic-tools", async (req, res) => {
    try {
      const {
        tool = "interaction",
        input = "",
        language = "roman",
        mode = "public",
      } = req.body ?? {};

      const clean = String(input || "").trim();
      if (!clean) {
        return res.status(400).json({ error: "Please enter medicines or an emergency topic." });
      }

      const ai = getAI();
      const langDesc =
        language === "ur"
          ? "Pakistani Urdu script (اردو)"
          : language === "pa"
            ? "Pakistani Roman Punjabi / Punjabi"
            : language === "en"
              ? "English"
              : "Pakistani Roman Urdu with clear English medical terms";

      const promptText =
        tool === "first_aid"
          ? `You are Dr. Noor Haram (${mode === "family" ? "Family Mode" : "Public Mode"}), a calm, caring baby doctor AI.
Provide verified, clear emergency FIRST AID steps in ${langDesc} for: "${clean}".
Give practical immediate do's, strict don'ts, and when to call 1122 / go to ER immediately.`
          : `You are Dr. Noor Haram (${mode === "family" ? "Family Mode" : "Public Mode"}), a caring baby doctor AI.
Check online medical references whether these medicines / items can be taken together safely: "${clean}".
Respond warmly in ${langDesc}, explaining safety level, how to space doses or take with/without food, possible interactions, and warning signs.`;

      const schema = {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          safetyLevel: {
            type: Type.STRING,
            description: "One of: safe_with_care, caution, avoid_or_urgent",
          },
          noorSummary: {
            type: Type.STRING,
            description: "Warm 2-3 sentence spoken guidance starting with [stethoscope] or [sad].",
          },
          steps: { type: Type.ARRAY, items: { type: Type.STRING } },
          avoidOrWarnings: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["title", "safetyLevel", "noorSummary", "steps", "avoidOrWarnings"],
      };

      let response;
      try {
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: promptText,
          config: {
            tools: [{ googleSearch: {} }],
            responseMimeType: "application/json",
            responseSchema: schema,
          },
        }));
      } catch {
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: promptText,
          config: {
            responseMimeType: "application/json",
            responseSchema: schema,
          },
        }));
      }

      const parsed = JSON.parse((response.text || "{}").trim());
      const groundingChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources: Array<{ title: string; uri: string }> = [];
      if (Array.isArray(groundingChunks)) {
        const seen = new Set<string>();
        for (const g of groundingChunks) {
          if (g.web?.uri && !seen.has(g.web.uri)) {
            seen.add(g.web.uri);
            sources.push({ title: g.web.title || g.web.uri, uri: g.web.uri });
          }
        }
      }
      res.json({ ...parsed, sources });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // 9. Universal World Encyclopedia & Live Multilingual Translator (for everyone worldwide)
  app.post("/api/world-tools", async (req, res) => {
    try {
      const {
        tool = "encyclopedia",
        query = "",
        targetLanguage = "Roman Urdu",
        language = "auto",
        clientTime,
      } = req.body ?? {};

      const clean = String(query || "").trim();
      if (!clean) {
        return res.status(400).json({ error: "Please enter a topic, question, or text." });
      }

      const ai = getAI();
      const liveClockBlock = formatVerifiedTimeBlock(clientTime, null);
      const langDesc =
        language === "ur"
          ? "Pakistani Urdu script (اردو)"
          : language === "pa"
            ? "Pakistani Punjabi"
            : language === "en"
              ? "English"
              : "clear, easy Pakistani Roman Urdu (or match the user's language naturally)";

      if (tool === "translate") {
        const response = await generateWithFallback(ai, (model) => ({
          model,
          contents: `Translate the following text accurately into ${targetLanguage}:
"${clean}"
Also provide easy Roman-script pronunciation so anyone can speak it out loud, plus 1-2 short cultural or usage tips.`,
          config: {
            responseMimeType: "application/json",
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                detectedLanguage: { type: Type.STRING },
                translatedText: { type: Type.STRING },
                pronunciation: { type: Type.STRING },
                spokenSummary: {
                  type: Type.STRING,
                  description:
                    "Warm 1-2 sentence spoken response starting with [smile] containing the translated phrase cleanly.",
                },
                tips: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: [
                "detectedLanguage",
                "translatedText",
                "pronunciation",
                "spokenSummary",
                "tips",
              ],
            },
          },
        }));
        const parsed = JSON.parse((response.text || "{}").trim());
        return res.json(parsed);
      }

      if (tool === "research") {
        const researchPrompt = `You are Dr. Noor Haram performing Verified Deep Research.
${liveClockBlock}

Perform a deep, multi-source online research check in ${langDesc} on:
"${clean}"

Return ONLY a valid JSON object (no markdown fences) matching this exact schema:
{
  "title": "concise headline",
  "category": "Deep Research",
  "noorSummary": "warm 2-4 sentence spoken summary starting with [stethoscope] or [think]",
  "keyFacts": ["5 to 7 detailed, verified facts with clear specifics"],
  "practicalTips": ["3 to 5 actionable takeaways"],
  "sources": [{ "title": "source label", "uri": "https://..." }]
}`;

        try {
          const interaction = await ai.interactions.create({
            model: "gemini-4-hydrogen",
            input: researchPrompt,
            generation_config: {
              thinking_level: "medium",
              max_output_tokens: 2048,
            },
            tools: [{ type: "google_search" }, { type: "url_context" }],
          });

          const rawOutputs =
            (interaction as unknown as { outputs?: Array<{ type?: string; text?: string }> })
              .outputs ?? [];
          const textOutputs = rawOutputs
            .filter(
              (o): o is { type: string; text: string } =>
                o.type === "text" && typeof o.text === "string"
            )
            .map((o) => o.text)
            .join("\n")
            .trim();

          const cleanedJson = textOutputs
            .replace(/^```json\s*/i, "")
            .replace(/^```\s*/i, "")
            .replace(/```\s*$/, "")
            .trim();

          const jsonStart = cleanedJson.indexOf("{");
          const jsonEnd = cleanedJson.lastIndexOf("}");
          if (jsonStart !== -1 && jsonEnd > jsonStart) {
            const parsed = JSON.parse(cleanedJson.slice(jsonStart, jsonEnd + 1));
            return res.json({
              title: parsed.title || clean,
              category: parsed.category || "Deep Research",
              noorSummary: parsed.noorSummary || cleanedJson.slice(0, 320),
              keyFacts: Array.isArray(parsed.keyFacts) ? parsed.keyFacts : [],
              practicalTips: Array.isArray(parsed.practicalTips) ? parsed.practicalTips : [],
              sources: Array.isArray(parsed.sources) ? parsed.sources : [],
            });
          }

          if (textOutputs) {
            return res.json({
              title: clean,
              category: "Deep Research",
              noorSummary: `[think] ${textOutputs.slice(0, 420)}`,
              keyFacts: textOutputs
                .split("\n")
                .map((l: string) => l.replace(/^[-*•\d.]+\s*/, "").trim())
                .filter((l: string) => l.length > 20)
                .slice(0, 6),
              practicalTips: [],
              sources: [],
            });
          }
        } catch {
          // Fall through seamlessly to verified generateWithFallback search below
        }
      }

      const encPrompt = `You are Dr. Noor Haram, a brilliant, warm AI companion with full live world knowledge.
${liveClockBlock}

Answer this world-knowledge request with verified, up-to-date online facts in ${langDesc}:
"${clean}"
Cover key verified facts, practical everyday takeaways/steps, and a warm 2-3 sentence spoken summary starting with [smile] or [think].`;

      const encSchema = {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          category: { type: Type.STRING },
          noorSummary: { type: Type.STRING },
          keyFacts: { type: Type.ARRAY, items: { type: Type.STRING } },
          practicalTips: { type: Type.ARRAY, items: { type: Type.STRING } },
        },
        required: ["title", "category", "noorSummary", "keyFacts", "practicalTips"],
      };

      const hasUrl = /https?:\/\/\S+/i.test(clean);
      let response;
      try {
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: encPrompt,
          config: {
            tools: hasUrl
              ? [{ googleSearch: {} }, { urlContext: {} }]
              : [{ googleSearch: {} }],
            responseMimeType: "application/json",
            responseSchema: encSchema,
          },
        }));
      } catch {
        response = await generateWithFallback(ai, (model) => ({
          model,
          contents: encPrompt,
          config: {
            responseMimeType: "application/json",
            responseSchema: encSchema,
          },
        }));
      }

      const parsed = JSON.parse((response.text || "{}").trim());
      const groundingChunks =
        response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      const sources: Array<{ title: string; uri: string }> = [];
      if (Array.isArray(groundingChunks)) {
        const seen = new Set<string>();
        for (const g of groundingChunks) {
          if (g.web?.uri && !seen.has(g.web.uri)) {
            seen.add(g.web.uri);
            sources.push({ title: g.web.title || g.web.uri, uri: g.web.uri });
          }
        }
      }
      res.json({ ...parsed, sources });
    } catch (err) {
      const { status, message } = formatError(err);
      res.status(status).json({ error: message });
    }
  });

  // Vite dev middleware or production static build (HMR disabled cleanly to avoid WebSocket errors)
  const distDir = path.resolve(__dirname, "dist");
  const hasDist = fs.existsSync(path.join(distDir, "index.html"));

  if (process.env.NODE_ENV === "production" && hasDist) {
    app.use(express.static(distDir));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distDir, "index.html"));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: "spa",
    });
    app.use(vite.middlewares);
  }

  // Create HTTP server + Gemini Live API WebSocket bridge (/ws/live & /ws/translate)
  const server = http.createServer(app);
  const wss = new WebSocketServer({ noServer: true });
  const translateWss = new WebSocketServer({ noServer: true });

  server.on("upgrade", (req, socket, head) => {
    if (req.url?.startsWith("/ws/live")) {
      wss.handleUpgrade(req, socket, head, (ws) => {
        wss.emit("connection", ws, req);
      });
    } else if (req.url?.startsWith("/ws/translate")) {
      translateWss.handleUpgrade(req, socket, head, (ws) => {
        translateWss.emit("connection", ws, req);
      });
    }
  });

  translateWss.on("connection", async (clientWs, req) => {
    let liveSession: Awaited<ReturnType<ReturnType<typeof getAI>["live"]["connect"]>> | null = null;
    let clientClosed = false;

    clientWs.on("close", () => {
      clientClosed = true;
      try {
        liveSession?.close();
      } catch {}
      liveSession = null;
    });

    try {
      const url = new URL(req.url || "/ws/translate", "http://localhost");
      const sourceLang = url.searchParams.get("source") || "ur";
      const targetLang = url.searchParams.get("target") || "en";

      const sendJson = (obj: Record<string, unknown>) => {
        if (!clientClosed && clientWs.readyState === 1) {
          clientWs.send(JSON.stringify(obj));
        }
      };

      const aiAlpha = getAI("v1alpha");
      let session;
      try {
        session = await aiAlpha.live.connect({
          model: "gemini-3.5-transcribe-live",
          config: {
            responseModalities: [Modality.TEXT],
            inputAudioTranscription: {},
            translationConfig: {
              sourceLanguageCode: sourceLang,
              targetLanguageCode: targetLang,
            },
          } as unknown as Parameters<GoogleGenAI["live"]["connect"]>[0]["config"],
          callbacks: {
            onopen: () => sendJson({ type: "ready" }),
            onmessage: (message: LiveServerMessage) => {
              const content = message.serverContent;
              const inTxt = content?.inputTranscription?.text;
              const outTxt =
                content?.outputTranscription?.text ||
                (content?.modelTurn?.parts ?? [])
                  .map((p) => p.text || "")
                  .filter(Boolean)
                  .join(" ");
              if (inTxt) sendJson({ type: "sourceTranscript", text: inTxt });
              if (outTxt) sendJson({ type: "transcript", text: outTxt });
              if (content?.turnComplete) sendJson({ type: "turnComplete" });
            },
            onerror: (err) => sendJson({ type: "error", error: formatError(err).message }),
            onclose: () => sendJson({ type: "closed" }),
          },
        });
      } catch {
        // Fallback to Gemini 3.8 Live text interpreter if transcribe-live translation config unavailable
        const aiBeta = getAI("v1beta");
        session = await aiBeta.live.connect({
          model: "gemini-3.8-live",
          config: {
            responseModalities: [Modality.TEXT],
            inputAudioTranscription: {},
            systemInstruction: `You are a real-time speech translator. Listen to spoken audio in ${sourceLang} and output ONLY the natural translation into ${targetLang} without explanations.`,
          },
          callbacks: {
            onopen: () => sendJson({ type: "ready" }),
            onmessage: (message: LiveServerMessage) => {
              const content = message.serverContent;
              const inTxt = content?.inputTranscription?.text;
              const outTxt = (content?.modelTurn?.parts ?? [])
                .map((p) => p.text || "")
                .filter(Boolean)
                .join(" ");
              if (inTxt) sendJson({ type: "sourceTranscript", text: inTxt });
              if (outTxt) sendJson({ type: "transcript", text: outTxt });
              if (content?.turnComplete) sendJson({ type: "turnComplete" });
            },
            onerror: (err) => sendJson({ type: "error", error: formatError(err).message }),
            onclose: () => sendJson({ type: "closed" }),
          },
        });
      }

      if (clientClosed) {
        try {
          session.close();
        } catch {}
        return;
      }
      liveSession = session;

      clientWs.on("message", (raw) => {
        if (!liveSession || clientClosed) return;
        try {
          const msg = JSON.parse(raw.toString());
          if (msg.type === "audio" && typeof msg.data === "string") {
            liveSession.sendRealtimeInput({
              audio: { data: msg.data, mimeType: "audio/pcm;rate=16000" },
            });
          }
        } catch {}
      });
    } catch (err) {
      if (!clientClosed && clientWs.readyState === 1) {
        clientWs.send(JSON.stringify({ type: "error", error: formatError(err).message }));
        clientWs.close();
      }
    }
  });

  wss.on("connection", async (clientWs, req) => {
    let liveSession: Awaited<ReturnType<ReturnType<typeof getAI>["live"]["connect"]>> | null = null;
    let clientClosed = false;

    clientWs.on("close", () => {
      clientClosed = true;
      try {
        liveSession?.close();
      } catch {}
      liveSession = null;
    });

    try {
      const url = new URL(req.url || "/ws/live", "http://localhost");
      const mode = url.searchParams.get("mode") || "public";
      const language = url.searchParams.get("lang") || "auto";
      const name = url.searchParams.get("name") || "Noor Haram";
      const tz = url.searchParams.get("tz") || "Asia/Karachi";
      const latParam = Number(url.searchParams.get("lat"));
      const lngParam = Number(url.searchParams.get("lng"));
      const requestedVoice = url.searchParams.get("voice") || "Kore";
      const validVoices = new Set(["Kore", "Zephyr", "Puck", "Charon", "Fenrir"]);
      const voiceName = validVoices.has(requestedVoice) ? requestedVoice : "Kore";

      const ai = getAI("v1beta");
      const systemInstruction = buildSystemInstruction({
        name,
        mode,
        language,
        forLiveAudio: true,
        clientTime: { timeZone: tz },
        userLocation:
          Number.isFinite(latParam) && Number.isFinite(lngParam) && (latParam !== 0 || lngParam !== 0)
            ? { lat: latParam, lng: lngParam }
            : null,
      });

      const sendJson = (obj: Record<string, unknown>) => {
        if (!clientClosed && clientWs.readyState === 1) {
          clientWs.send(JSON.stringify(obj));
        }
      };

      const session = await ai.live.connect({
        model: "gemini-3.8-live",
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName } },
          },
          inputAudioTranscription: {},
          outputAudioTranscription: {},
          systemInstruction,
        },
        callbacks: {
          onopen: () => {
            sendJson({ type: "ready" });
          },
          onmessage: (message: LiveServerMessage) => {
            const content = message.serverContent;
            if (content?.inputTranscription?.text) {
              sendJson({ type: "inputTranscript", text: content.inputTranscription.text });
            }
            if (content?.outputTranscription?.text) {
              sendJson({ type: "outputTranscript", text: content.outputTranscription.text });
            }
            for (const part of content?.modelTurn?.parts ?? []) {
              if (part.inlineData?.data) {
                sendJson({ type: "audio", data: part.inlineData.data });
              }
            }
            if (content?.interrupted) {
              sendJson({ type: "interrupted" });
            }
            if (content?.turnComplete) {
              sendJson({ type: "turnComplete" });
            }
          },
          onerror: (err) => {
            sendJson({ type: "error", error: formatError(err).message });
          },
          onclose: () => {
            sendJson({ type: "closed" });
          },
        },
      });

      if (clientClosed) {
        try {
          session.close();
        } catch {}
        return;
      }
      liveSession = session;

      clientWs.on("message", (raw) => {
        if (!liveSession || clientClosed) return;
        try {
          const msg = JSON.parse(raw.toString());
          if (msg.type === "audio" && typeof msg.data === "string") {
            liveSession.sendRealtimeInput({
              audio: { data: msg.data, mimeType: "audio/pcm;rate=16000" },
            });
          } else if (msg.type === "video" && typeof msg.data === "string") {
            liveSession.sendRealtimeInput({
              video: { data: msg.data, mimeType: "image/jpeg" },
            });
          } else if (msg.type === "text" && typeof msg.text === "string") {
            liveSession.sendRealtimeInput({ text: msg.text });
          }
        } catch {}
      });
    } catch (err) {
      if (!clientClosed && clientWs.readyState === 1) {
        clientWs.send(JSON.stringify({ type: "error", error: formatError(err).message }));
        clientWs.close();
      }
    }
  });

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Dr. Noor Haram server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
