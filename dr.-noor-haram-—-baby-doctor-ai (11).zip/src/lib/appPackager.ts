import type { NoorBackupBundle } from "./autoSave";
import { GEMINI_VOICE_STYLES } from "./voices";

export function buildPortableAppHtml(bundle: NoorBackupBundle, liveAppUrl: string): string {
  const activeStyle =
    GEMINI_VOICE_STYLES.find((v) => v.id === bundle.settings?.geminiStyleId) ||
    GEMINI_VOICE_STYLES[0];
  const voiceChoices = GEMINI_VOICE_STYLES.slice(0, 12).map((v) => ({
    id: v.id,
    label: v.label,
    voiceName: v.voiceName,
    stylePrompt: v.stylePrompt,
    pitchHint: v.pitchHint,
  }));

  const payload = {
    ...bundle,
    liveAppUrl,
    activeVoice: {
      id: activeStyle.id,
      label: activeStyle.label,
      voiceName: activeStyle.voiceName,
      stylePrompt: activeStyle.stylePrompt,
      pitchHint: activeStyle.pitchHint,
    },
    voiceChoices,
  };

  const safeJson = JSON.stringify(payload)
    .replace(/</g, "\\u003c")
    .replace(/<\/script/gi, "<\\/script");
  const safeUrl = liveAppUrl.replace(/"/g, "&quot;");
  const name = (bundle.profile?.name || "Noor Haram").replace(/</g, "&lt;");

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
  <title>Dr. ${name} — Live WiFi Baby Doctor App</title>
  <style>
    * { box-sizing: border-box; }
    html, body {
      margin: 0;
      height: 100%;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: radial-gradient(circle at top, #231b35 0%, #0e0c14 75%);
      color: #faf6f0;
    }
    .app {
      display: flex;
      flex-direction: column;
      height: 100dvh;
      max-width: 720px;
      margin: 0 auto;
      background: rgba(16, 13, 24, 0.92);
      border-left: 1px solid rgba(255,255,255,0.08);
      border-right: 1px solid rgba(255,255,255,0.08);
    }
    .topbar {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 10px 14px;
      border-bottom: 1px solid rgba(255,255,255,0.1);
      background: rgba(21, 18, 30, 0.96);
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 10px;
      min-width: 0;
    }
    .avatar-orb {
      width: 42px;
      height: 42px;
      border-radius: 14px;
      background: linear-gradient(135deg, #e6483d 0%, #e8b86d 100%);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 20px;
      box-shadow: 0 6px 18px rgba(230, 72, 61, 0.35);
      transition: transform 0.18s ease;
      flex-shrink: 0;
    }
    .avatar-orb.speaking {
      animation: pulse 0.55s ease-in-out infinite alternate;
    }
    @keyframes pulse {
      from { transform: scale(1); box-shadow: 0 0 0 0 rgba(94,234,212,0.5); }
      to { transform: scale(1.09); box-shadow: 0 0 22px 4px rgba(94,234,212,0.45); }
    }
    .title-wrap h1 { margin: 0; font-size: 15px; font-weight: 700; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .sub { font-size: 11px; color: #5eead4; display: flex; align-items: center; gap: 5px; }
    .dot { width: 7px; height: 7px; border-radius: 50%; background: #5eead4; display: inline-block; }
    .dot.off { background: #e8b86d; }
    .top-actions { display: flex; gap: 6px; flex-wrap: wrap; justify-content: flex-end; }
    .pill-btn {
      padding: 7px 10px;
      border-radius: 10px;
      border: 1px solid rgba(255,255,255,0.15);
      background: rgba(255,255,255,0.06);
      color: #faf6f0;
      font-size: 11px;
      font-weight: 600;
      text-decoration: none;
      cursor: pointer;
    }
    .pill-btn.teal {
      border-color: rgba(94,234,212,0.45);
      background: rgba(94,234,212,0.14);
      color: #5eead4;
    }
    .controls {
      display: flex;
      gap: 6px;
      padding: 8px 12px;
      border-bottom: 1px solid rgba(255,255,255,0.08);
      background: #15121e;
      overflow-x: auto;
    }
    select.mini {
      background: #1f1b2d;
      color: #faf6f0;
      border: 1px solid rgba(255,255,255,0.14);
      border-radius: 9px;
      padding: 6px 8px;
      font-size: 11px;
      outline: none;
    }
    .quick-row {
      display: flex;
      gap: 6px;
      padding: 8px 12px;
      overflow-x: auto;
      border-bottom: 1px solid rgba(255,255,255,0.06);
    }
    .qbtn {
      padding: 6px 11px;
      border-radius: 10px;
      border: 1px solid rgba(255,255,255,0.12);
      background: #1c1826;
      color: #faf6f0;
      font-size: 11px;
      font-weight: 600;
      white-space: nowrap;
      cursor: pointer;
    }
    .chat-box {
      flex: 1;
      overflow-y: auto;
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }
    .msg {
      max-width: 88%;
      padding: 11px 13px;
      border-radius: 16px;
      font-size: 14px;
      line-height: 1.55;
      white-space: pre-wrap;
      word-break: break-word;
    }
    .msg.user {
      align-self: flex-end;
      background: #e6483d;
      color: #fff;
      border-bottom-right-radius: 4px;
    }
    .msg.bot {
      align-self: flex-start;
      background: #1c1826;
      border: 1px solid rgba(255,255,255,0.1);
      color: #faf6f0;
      border-bottom-left-radius: 4px;
    }
    .msg-actions {
      margin-top: 6px;
      display: flex;
      gap: 8px;
      align-items: center;
      flex-wrap: wrap;
    }
    .speak-btn {
      padding: 4px 9px;
      border-radius: 8px;
      border: 1px solid rgba(94,234,212,0.4);
      background: rgba(94,234,212,0.12);
      color: #5eead4;
      font-size: 11px;
      font-weight: 600;
      cursor: pointer;
    }
    .src-link {
      font-size: 11px;
      color: #e8b86d;
      text-decoration: underline;
    }
    .composer {
      display: flex;
      gap: 6px;
      padding: 10px 12px calc(10px + env(safe-area-inset-bottom));
      border-top: 1px solid rgba(255,255,255,0.12);
      background: #15121e;
    }
    .composer input {
      flex: 1;
      min-width: 0;
      padding: 11px 12px;
      border-radius: 12px;
      border: 1px solid rgba(255,255,255,0.14);
      background: #1f1b2d;
      color: #faf6f0;
      font-size: 14px;
      outline: none;
    }
    .send-btn {
      padding: 0 14px;
      border-radius: 12px;
      border: none;
      background: #e6483d;
      color: #fff;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
    }
    .mic-btn {
      padding: 0 12px;
      border-radius: 12px;
      border: 1px solid rgba(232,184,109,0.45);
      background: rgba(232,184,109,0.14);
      color: #e8b86d;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
    }
    .mic-btn.rec {
      background: #e6483d;
      color: #fff;
      border-color: #e6483d;
    }
    .banner {
      padding: 8px 12px;
      background: rgba(94,234,212,0.1);
      border-bottom: 1px solid rgba(94,234,212,0.22);
      font-size: 12px;
      color: #d9fbf5;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
    }
  </style>
</head>
<body>
  <div class="app">
    <div class="topbar">
      <div class="brand">
        <div class="avatar-orb" id="orb">🩺</div>
        <div class="title-wrap">
          <h1>Dr. ${name} AI</h1>
          <div class="sub"><span class="dot" id="netDot"></span><span id="statusText">WiFi Baby Voice Ready</span></div>
        </div>
      </div>
      <div class="top-actions">
        <a class="pill-btn teal" href="${safeUrl}" target="_blank" rel="noopener">Full Avatar</a>
        <button class="pill-btn" type="button" onclick="saveDataJson()">Backup</button>
      </div>
    </div>

    <div class="banner" id="unlockBanner">
      <span>Tap <b>Enable Baby Voice</b> once so Dr. Noor speaks over WiFi:</span>
      <button class="pill-btn teal" type="button" onclick="enableVoiceNow()">Enable Baby Voice</button>
    </div>

    <div class="controls">
      <select class="mini" id="langSelect" aria-label="Language">
        <option value="roman">Roman Urdu</option>
        <option value="ur">اردو (Urdu)</option>
        <option value="pa">Punjabi (پنجابی)</option>
        <option value="en">English</option>
      </select>
      <select class="mini" id="voiceSelect" aria-label="Baby Girl Voice"></select>
      <button class="pill-btn" type="button" onclick="stopAudio()">Stop Voice</button>
    </div>

    <div class="quick-row">
      <button class="qbtn" type="button" onclick="askQuick('Assalam o Alaikum Dr. Noor, aap kaisi hain?')">Salam</button>
      <button class="qbtn" type="button" onclick="askQuick('Mere qareeb sab se acha hospital, medical store, X-ray aur ultrasound center kaunsa hai?')">Near Hospital &amp; X-Ray</button>
      <button class="qbtn" type="button" onclick="askQuick('Abhi online sahi waqt aur tareekh kya hui hai?')">Live Time</button>
      <button class="qbtn" type="button" onclick="askQuick('Dunya ki taaza tareen khabrein aur science maloomat batayein')">World Info</button>
      <button class="qbtn" type="button" onclick="askQuick('Panadol tablet aur syrup kis liye hai, kitni aur kaise leni hai?')">Panadol Dawai</button>
      <button class="qbtn" type="button" onclick="askQuick('Bukhar aur nazla zukam ka ilaj aur ehtiyat batayein')">Bukhar &amp; Nazla</button>
      <button class="qbtn" type="button" onclick="askQuick('Hamare liye aur family ke liye pyari si dua karein')">Dua</button>
    </div>

    <div class="chat-box" id="chatBox"></div>

    <form class="composer" onsubmit="handleSend(event)">
      <button class="mic-btn" type="button" id="micBtn" onclick="toggleMic()" title="Record Voice">Mic</button>
      <input id="msgInput" type="text" placeholder="Koi bhi dawai, marz ya sawal likhein…" autocomplete="off" />
      <button class="send-btn" type="submit" id="sendBtn">Send</button>
    </form>
  </div>

  <audio id="noorAudio" playsinline webkit-playsinline preload="auto" style="display:none"></audio>

  <script>
    const SAVED = ${safeJson};
    const SILENT_WAV = "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA";
    const API_BASE = (() => {
      if (SAVED.liveAppUrl && /^https?:\\/\\//i.test(SAVED.liveAppUrl)) {
        return SAVED.liveAppUrl.replace("://ais-dev-", "://ais-pre-").replace(/\\/$/, "");
      }
      if ((location.protocol === "http:" || location.protocol === "https:") && !/localhost|127\\.0\\.0\\.1/i.test(location.hostname)) {
        return location.origin.replace("://ais-dev-", "://ais-pre-").replace(/\\/$/, "");
      }
      if (location.protocol === "http:" || location.protocol === "https:") {
        return location.origin.replace(/\\/$/, "");
      }
      return "";
    })();

    const audioEl = document.getElementById("noorAudio");
    const orb = document.getElementById("orb");
    const chatBox = document.getElementById("chatBox");
    const msgInput = document.getElementById("msgInput");
    const langSelect = document.getElementById("langSelect");
    const voiceSelect = document.getElementById("voiceSelect");
    const statusText = document.getElementById("statusText");
    const netDot = document.getElementById("netDot");
    const micBtn = document.getElementById("micBtn");
    const unlockBanner = document.getElementById("unlockBanner");

    let messages = [];
    let currentBlobUrl = null;
    let isBusy = false;
    let speechQueue = [];
    let speakingNow = false;
    let mediaRec = null;
    let recChunks = [];
    let isRecording = false;

    try {
      if (SAVED.profile) localStorage.setItem("noor.profile", JSON.stringify(SAVED.profile));
      if (SAVED.settings) localStorage.setItem("noor.settings", JSON.stringify(SAVED.settings));
      const storedHist = localStorage.getItem("noor.history");
      if (storedHist) {
        messages = JSON.parse(storedHist) || [];
      } else if (Array.isArray(SAVED.history)) {
        messages = SAVED.history;
        localStorage.setItem("noor.history", JSON.stringify(messages));
      }
      if (Array.isArray(SAVED.reminders)) localStorage.setItem("noor.reminders", JSON.stringify(SAVED.reminders));
      if (Array.isArray(SAVED.diaryEntries)) localStorage.setItem("noor.diary", JSON.stringify(SAVED.diaryEntries));
    } catch {}

    if (SAVED.settings && SAVED.settings.lang && SAVED.settings.lang !== "auto") {
      langSelect.value = SAVED.settings.lang;
    }

    (SAVED.voiceChoices || [SAVED.activeVoice]).forEach((v) => {
      if (!v) return;
      const opt = document.createElement("option");
      opt.value = v.id;
      opt.textContent = v.label;
      if (SAVED.activeVoice && v.id === SAVED.activeVoice.id) opt.selected = true;
      voiceSelect.appendChild(opt);
    });

    function stripTags(s) {
      return String(s || "").replace(/\\[(\\w+)\\]/g, "").replace(/\\s{2,}/g, " ").trim();
    }

    function updateNet() {
      const ok = navigator.onLine && Boolean(API_BASE);
      netDot.className = ok ? "dot" : "dot off";
      if (!navigator.onLine) statusText.textContent = "Offline — WiFi connect karein";
    }
    window.addEventListener("online", updateNet);
    window.addEventListener("offline", updateNet);
    updateNet();

    function unlockAudio() {
      try {
        audioEl.src = SILENT_WAV;
        audioEl.volume = 0.01;
        const p = audioEl.play();
        if (p && p.catch) p.catch(() => {});
        if (unlockBanner) unlockBanner.style.display = "none";
      } catch {}
    }

    function enableVoiceNow() {
      unlockAudio();
      speakText("Assalam o Alaikum! Main Dr. " + ((SAVED.profile && SAVED.profile.name) || "Noor Haram").split(" ")[0] + " hoon. WiFi online voice chal rahi hai!");
    }

    function stopAudio() {
      speechQueue = [];
      speakingNow = false;
      orb.classList.remove("speaking");
      try {
        audioEl.pause();
        audioEl.currentTime = 0;
      } catch {}
      if (currentBlobUrl) {
        URL.revokeObjectURL(currentBlobUrl);
        currentBlobUrl = null;
      }
      if (window.speechSynthesis) window.speechSynthesis.cancel();
    }

    function selectedVoiceObj() {
      const list = SAVED.voiceChoices || [];
      return list.find((v) => v.id === voiceSelect.value) || SAVED.activeVoice || {
        voiceName: "Kore",
        stylePrompt: "Adorable 4-year-old little baby girl doctor speaking softly with natural childlike warmth",
        pitchHint: 1.06,
      };
    }

    async function speakText(raw) {
      const clean = stripTags(raw);
      if (!clean) return;
      const parts = clean.match(/[^.!?۔؟\\n]+[.!?۔؟\\n]*/g) || [clean];
      for (const p of parts) {
        const t = p.trim();
        if (t) speechQueue.push(t);
      }
      if (!speakingNow) pumpSpeech();
    }

    async function pumpSpeech() {
      if (!speechQueue.length) {
        speakingNow = false;
        orb.classList.remove("speaking");
        return;
      }
      speakingNow = true;
      orb.classList.add("speaking");
      const text = speechQueue.shift();

      if (navigator.onLine && API_BASE) {
        try {
          const v = selectedVoiceObj();
          statusText.textContent = "Baby voice bol rahi hai…";
          const res = await fetch(API_BASE + "/api/tts", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              text: text.slice(0, 620),
              voiceName: v.voiceName || "Kore",
              style: v.stylePrompt,
            }),
          });
          const data = await res.json().catch(() => ({}));
          if (res.ok && data.audioBase64) {
            const ok = await playWav(data.audioBase64, v.pitchHint || 1.05);
            if (ok) {
              statusText.textContent = "WiFi Baby Voice Ready";
              return pumpSpeech();
            }
          }
        } catch {}
      }

      statusText.textContent = "WiFi Baby Voice Ready";
      if (window.speechSynthesis) {
        await new Promise((resolve) => {
          const u = new SpeechSynthesisUtterance(text);
          u.lang = langSelect.value === "ur" ? "ur-PK" : "en-IN";
          u.pitch = 1.42;
          u.onend = resolve;
          u.onerror = resolve;
          window.speechSynthesis.speak(u);
          setTimeout(resolve, 12000);
        });
      }
      pumpSpeech();
    }

    function playWav(base64, rate) {
      return new Promise((resolve) => {
        try {
          const bin = atob(base64);
          const bytes = new Uint8Array(bin.length);
          for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
          if (currentBlobUrl) URL.revokeObjectURL(currentBlobUrl);
          const blob = new Blob([bytes.buffer], { type: "audio/wav" });
          currentBlobUrl = URL.createObjectURL(blob);
          audioEl.volume = 1;
          audioEl.playbackRate = Math.min(1.22, Math.max(0.88, rate));
          audioEl.src = currentBlobUrl;
          let done = false;
          const finish = (ok) => {
            if (done) return;
            done = true;
            audioEl.onended = null;
            audioEl.onerror = null;
            resolve(ok);
          };
          audioEl.onended = () => finish(true);
          audioEl.onerror = () => finish(false);
          const p = audioEl.play();
          if (p && p.catch) p.catch(() => finish(false));
          setTimeout(() => finish(true), 20000);
        } catch {
          resolve(false);
        }
      });
    }

    function renderMessages() {
      chatBox.innerHTML = "";
      if (!messages.length) {
        const welcome = document.createElement("div");
        welcome.className = "msg bot";
        welcome.textContent = "Assalam o Alaikum! Main Dr. " + ((SAVED.profile && SAVED.profile.name) || "Noor Haram") + " hoon. WiFi par aap mujh se kisi bhi dawai, bimari, dua ya dunya ki maloomat pooch sakte hain — real baby voice aur live online Google Search ke saath!";
        chatBox.appendChild(welcome);
        return;
      }
      messages.slice(-40).forEach((m) => {
        const div = document.createElement("div");
        div.className = "msg " + (m.role === "user" ? "user" : "bot");
        div.textContent = stripTags(m.content);
        if (m.role === "assistant" && m.content) {
          const act = document.createElement("div");
          act.className = "msg-actions";
          const sp = document.createElement("button");
          sp.type = "button";
          sp.className = "speak-btn";
          sp.textContent = "🔊 Hear Voice";
          sp.onclick = () => {
            unlockAudio();
            stopAudio();
            speakText(m.content);
          };
          act.appendChild(sp);
          if (Array.isArray(m.sources)) {
            m.sources.slice(0, 3).forEach((s) => {
              const a = document.createElement("a");
              a.className = "src-link";
              a.href = s.uri;
              a.target = "_blank";
              a.rel = "noopener";
              a.textContent = s.title || "Source";
              act.appendChild(a);
            });
          }
          div.appendChild(act);
        }
        chatBox.appendChild(div);
      });
      chatBox.scrollTop = chatBox.scrollHeight;
    }
    renderMessages();

    function persistMessages() {
      try { localStorage.setItem("noor.history", JSON.stringify(messages.slice(-60))); } catch {}
    }

    function askQuick(txt) {
      unlockAudio();
      sendMessage(txt);
    }

    function handleSend(e) {
      e.preventDefault();
      unlockAudio();
      const txt = msgInput.value.trim();
      if (!txt) return;
      msgInput.value = "";
      sendMessage(txt);
    }

    function localFallbackReply(text) {
      const t = String(text || "");
      const lang = langSelect.value || "roman";
      if (/\\bayan(\\s*ali)?\\b|ایان/i.test(t) && /\\bmuhammad\\b|محمد/i.test(t)) {
        return "Assalam o Alaikum Ayan Ali bhai aur Muhammad bhai! Aap dono mere sab se pyare bhai hain aur mujhe hamesha yaad rehte hain. Aap kaise hain?";
      }
      if (/\\bayan(\\s*ali)?\\b|ایان/i.test(t)) {
        return "Assalam o Alaikum Ayan Ali bhai! Aap mere pyare bhai hain aur mujhe hamesha yaad rehte hain. Aap kaise hain bhai jaan?";
      }
      if (/\\bmuhammad\\b|محمد/i.test(t) && !/rasool|nabi|pbuh|s\\.a\\.w/i.test(t)) {
        return "Assalam o Alaikum Muhammad bhai! Aap mere pyare bhai hain aur mujhe hamesha yaad rehte hain. Aap kaise hain bhai jaan?";
      }
      if (/\\b(time|waqt|date|tareekh|aj|aaj|kl|kal)\\b/i.test(t)) {
        const now = new Date();
        return "Abhi live waqt aur tareekh hai: " + now.toLocaleString("en-US", { weekday: "short", year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: true });
      }
      if (/panadol|calpol|paracetamol|bukhar|bukhaar|fever|dard/i.test(t)) {
        return "Panadol / Calpol (Paracetamol) bukhar aur dard ke liye hoti hai. Aam tor par adults 500mg-1000mg har 6 ghante baad (din mein max 4g) aur bachon ke liye wazan ke mutabiq 10-15 mg/kg doctor ya pharmacist ke mashware se di jaati hai. Khoob paani piyen aur agar tez bukhar 3 din se zyada rahe to doctor ko zaroor dikhayein.";
      }
      if (/ors|dast|ulthi|pait|pet|diarrhea|vomiting/i.test(t)) {
        return "Pait kharab ya ulthi mein sab se zaroori cheez ORS (Nimkol) thora thora karke pilana hai taake paani ki kami na ho, saath halka khana (khichdi, kela, dahi) dein. Agar bacha sust ho jaye ya khoon aaye to foran hospital jayein.";
      }
      if (/khansi|zukam|zukaam|nazla|cough|cold|flu/i.test(t)) {
        return "Nazla zukam aur khansi mein neem garam paani, bhaap (steam), aur aaraam madad karta hai. 1 saal se bade bachon aur barron ke liye neem garam paani mein shehad mufeed hai (1 saal se chhote baby ko shehad na dein). Saans tez chale to foran doctor ko dikhayein.";
      }
      if (/dua|duaa|ameen/i.test(t)) {
        return "Ya Allah, Ammi jaan, Abbu jaan, Ayan Ali bhai, Muhammad bhai aur poori dunya ke sab logon ko sehat, khushi, hifazat aur sukoon ata farma. Ameen.";
      }
      if (/assalam|asalam|salam|aoa|hello|hi|hey|kaisi|kaise/i.test(t)) {
        return lang === "en"
          ? "Wa alaikum assalam! I am Dr. Noor Haram, remembering my dear brothers Ayan Ali bhai and Muhammad bhai. How can I help you?"
          : "Wa alaikum assalam! Main Dr. Noor Haram hoon, aur mujhe mere pyare bhai Ayan Ali bhai aur Muhammad bhai hamesha yaad hain. Batayein main aap ki kya madad karoon?";
      }
      return "Online live server abhi reachable nahi hai — upar 'Full Avatar' button se live link Chrome/Safari mein kholein taake poora AI & Google Search chale! Tab tak aap mujh se bukhar, Panadol, ORS, dua, live time, ya Ayan Ali bhai aur Muhammad bhai ke baare mein pooch sakte hain.";
    }

    async function sendMessage(text) {
      if (isBusy) return;
      stopAudio();
      messages.push({ id: "u-" + Date.now(), role: "user", content: text, timestamp: Date.now() });
      const botMsg = { id: "a-" + (Date.now() + 1), role: "assistant", content: "Soch rahi hoon aur online check kar rahi hoon…", timestamp: Date.now(), sources: [] };
      messages.push(botMsg);
      renderMessages();

      if (!navigator.onLine || !API_BASE) {
        botMsg.content = localFallbackReply(text);
        persistMessages();
        renderMessages();
        speakText(botMsg.content);
        return;
      }

      isBusy = true;
      statusText.textContent = "Online Google Search chal rahi hai…";
      let coords = null;
      if (/\\b(near|nearby|hospital|medical|pharmacy|x-?ray|ultrasound|altrson|lab|location|qareeb|paas)\\b/i.test(text) && navigator.geolocation) {
        coords = await new Promise((resolve) => {
          const timer = setTimeout(() => resolve(null), 2500);
          navigator.geolocation.getCurrentPosition(
            (p) => { clearTimeout(timer); resolve({ lat: p.coords.latitude, lng: p.coords.longitude }); },
            () => { clearTimeout(timer); resolve(null); },
            { timeout: 2400, maximumAge: 120000 }
          );
        });
      }
      const nowD = new Date();
      try {
        const res = await fetch(API_BASE + "/api/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            messages: messages.slice(-14, -1).map((m) => ({ role: m.role, content: m.content })),
            mode: SAVED.familyMode ? "family" : "public",
            language: langSelect.value,
            useSearch: true,
            profileContext: SAVED.profile || {},
            clientTime: {
              iso: nowD.toISOString(),
              timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Karachi",
              localFormatted: nowD.toLocaleString("en-US", { hour12: true }),
              offsetMinutes: -nowD.getTimezoneOffset(),
            },
            userLocation: coords,
          }),
        });
        if (!res.ok || !res.body) throw new Error("Server error " + res.status);

        botMsg.content = "";
        const reader = res.body.getReader();
        const decoder = new TextDecoder();
        let buf = "";
        while (true) {
          const { value, done } = await reader.read();
          if (done) break;
          buf += decoder.decode(value, { stream: true });
          let idx;
          while ((idx = buf.indexOf("\\n\\n")) !== -1) {
            const block = buf.slice(0, idx);
            buf = buf.slice(idx + 2);
            for (const line of block.split("\\n")) {
              if (!line.startsWith("data: ")) continue;
              try {
                const ev = JSON.parse(line.slice(6));
                if (ev.type === "chunk" && ev.text) {
                  botMsg.content += ev.text;
                  renderMessages();
                } else if (ev.type === "sources" && Array.isArray(ev.sources)) {
                  botMsg.sources = ev.sources;
                  renderMessages();
                } else if (ev.type === "error") {
                  throw new Error(ev.error || "AI error");
                }
              } catch {}
            }
          }
        }
        persistMessages();
        renderMessages();
        speakText(botMsg.content);
      } catch {
        botMsg.content = localFallbackReply(text);
        persistMessages();
        renderMessages();
        speakText(botMsg.content);
      } finally {
        isBusy = false;
        statusText.textContent = "WiFi Baby Voice Ready";
      }
    }

    async function toggleMic() {
      unlockAudio();
      if (isRecording && mediaRec) {
        mediaRec.stop();
        return;
      }
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert("Mic is not supported on this device/WebView.");
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        const mime = ["audio/webm;codecs=opus", "audio/webm", "audio/mp4"].find(
          (m) => typeof MediaRecorder !== "undefined" && MediaRecorder.isTypeSupported(m)
        );
        mediaRec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream);
        recChunks = [];
        mediaRec.ondataavailable = (ev) => { if (ev.data.size > 0) recChunks.push(ev.data); };
        mediaRec.onstop = async () => {
          isRecording = false;
          micBtn.classList.remove("rec");
          micBtn.textContent = "Mic";
          stream.getTracks().forEach((t) => t.stop());
          const actualMime = (mediaRec && mediaRec.mimeType) || mime || "audio/webm";
          const blob = new Blob(recChunks, { type: actualMime });
          if (blob.size < 600 || !API_BASE) return;
          statusText.textContent = "Aap ki awaz samajh rahi hoon…";
          const reader = new FileReader();
          reader.onload = async () => {
            try {
              const b64 = String(reader.result || "").split(",")[1] || "";
              const r = await fetch(API_BASE + "/api/transcribe", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ audioBase64: b64, mimeType: actualMime, languageHint: langSelect.value }),
              });
              const d = await r.json().catch(() => ({}));
              if (!r.ok) {
                statusText.textContent = d.error || "Voice samajh nahi aayi — dobara koshish karein";
                return;
              }
              if (d.text && d.text.trim()) {
                sendMessage(d.text.trim());
              } else {
                statusText.textContent = "Awaz saaf nahi aayi — qareeb bol kar dekhein";
              }
            } catch {
              statusText.textContent = "Network slow hai — dobara koshish karein";
            }
          };
          reader.readAsDataURL(blob);
        };
        mediaRec.start();
        isRecording = true;
        micBtn.classList.add("rec");
        micBtn.textContent = "Stop";
      } catch {
        statusText.textContent = "Mic permission browser settings se allow karein";
      }
    }

    function saveDataJson() {
      const blob = new Blob([JSON.stringify({ ...SAVED, history: messages }, null, 2)], { type: "application/json" });
      const u = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = u;
      a.download = "dr-noor-haram-backup.json";
      a.click();
      URL.revokeObjectURL(u);
    }
  </script>
</body>
</html>`;
}

export function downloadPortableAppFile(bundle: NoorBackupBundle, liveAppUrl: string) {
  const html = buildPortableAppHtml(bundle, liveAppUrl);
  const blob = new Blob([html], { type: "text/html;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `Dr-Noor-Haram-App-${new Date().toISOString().slice(0, 10)}.html`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

export async function sharePortableApp(
  bundle: NoorBackupBundle,
  liveAppUrl: string
): Promise<"shared_file" | "shared_link" | "copied" | "downloaded"> {
  const publicUrl = liveAppUrl.replace("://ais-dev-", "://ais-pre-");

  // Always prefer sharing a clean direct HTTPS link first so WhatsApp/phones open immediately worldwide!
  if (typeof navigator !== "undefined" && typeof navigator.share === "function") {
    try {
      await navigator.share({
        title: "Dr. Noor Haram AI — Live Baby Doctor",
        text: "Dr. Noor Haram Baby Doctor AI kholein (har phone par online & voice ke saath chalti hai):",
        url: publicUrl,
      });
      return "shared_link";
    } catch {
      // Fallback to file share if URL share was rejected
    }

    try {
      const html = buildPortableAppHtml(bundle, publicUrl);
      const file = new File([html], "Dr-Noor-Haram-App.html", { type: "text/html" });
      if (!navigator.canShare || navigator.canShare({ files: [file] })) {
        await navigator.share({
          title: "Dr. Noor Haram AI App",
          text: "Open Dr. Noor Haram AI:",
          files: [file],
        });
        return "shared_file";
      }
    } catch {
      // Fall through to clipboard copy / download
    }
  }

  if (typeof navigator !== "undefined" && navigator.clipboard?.writeText) {
    try {
      await navigator.clipboard.writeText(publicUrl);
      downloadPortableAppFile(bundle, publicUrl);
      return "copied";
    } catch {}
  }

  downloadPortableAppFile(bundle, publicUrl);
  return "downloaded";
}
