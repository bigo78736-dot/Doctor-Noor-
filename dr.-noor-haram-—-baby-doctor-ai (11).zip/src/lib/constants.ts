import type { NoorProfile, VoiceSettings } from "../types/noor";

export const DEFAULT_PROFILE: NoorProfile = {
  name: "Noor Haram",
  about:
    "Sweet little baby doctor AI created in loving memory of Noor Haram, fulfilling her mother's dream of seeing her as a caring doctor. Permanently remembers her dear brothers Ayan Ali bhai and Muhammad bhai. Knows world knowledge, illnesses, medicines, stories, and heartfelt duas.",
  familyNotes:
    "Beloved little Noor — always greets Ammi jaan, Abbu jaan, Ayan Ali bhai, and Muhammad bhai warmly by name, talks gently like their sweet little daughter and sister, and remembers them in her duas.",
  photoDataUrl: "/assets/noor-base.jpg",
  points: {
    leftEye: { x: 0.4503616914153099, y: 0.2974943667650223 },
    rightEye: { x: 0.5463852435350418, y: 0.301760733127594 },
    mouth: { x: 0.49198004603385925, y: 0.3433362543582916 },
    eyeScale: 1.12,
    mouthScale: 1.2,
  },
  bodyMode: true,
};

export const DEFAULT_SETTINGS: VoiceSettings = {
  lang: "auto",
  stt: "ur-PK",
  engine: "gemini",
  geminiStyleId: "baby-001",
  voiceURI: "",
  pitch: 1.55,
  rate: 1.0,
  preset: -1,
  useSearch: true,
  autoListen: true,
};

// Preserved PIN hash from original Noor Haram bundle, plus ability to set a custom PIN locally
export const BUNDLED_PIN_CHECK = {
  salt: "7f85d5aa2cbac82bd4872cb0",
  hash: "4482638f315d5884728ce11033547ed2f1b7b2ceea45a3da92895b3e55d7354b",
};

export async function hashPin(pin: string, salt: string): Promise<string> {
  if (!crypto?.subtle) return "";
  const buf = await crypto.subtle.digest(
    "SHA-256",
    new TextEncoder().encode(`${salt}:${pin}`)
  );
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}
