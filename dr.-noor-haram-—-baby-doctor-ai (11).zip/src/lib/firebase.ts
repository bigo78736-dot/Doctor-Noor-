import { getApp, getApps, initializeApp } from "firebase/app";
import { GoogleAuthProvider, getAuth, onAuthStateChanged } from "firebase/auth";
import { doc, getDocFromServer, getFirestore } from "firebase/firestore";
import firebaseConfig from "../../firebase-applet-config.json";

// Suppress noisy Firestore database warnings in console
const originalWarn = console.warn;
console.warn = (...args: any[]) => {
  const msg = typeof args[0] === "string" ? args[0] : "";
  if (msg.includes("Database") && msg.includes("not found")) {
    return;
  }
  originalWarn(...args);
};

const app = getApps().length > 0 ? getApp() : initializeApp(firebaseConfig);

export const WORKSPACE_SCOPES = [
  "https://www.googleapis.com/auth/calendar.events",
] as const;

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
WORKSPACE_SCOPES.forEach((scope) => googleProvider.addScope(scope));

export const db = getFirestore(app, "ai-studio-drnoorharambabyd-1ed39d7c-61c0-457d-a67d-0deec96768ec");

// In-memory only OAuth access token cache (never stored in localStorage/sessionStorage)
let cachedAccessToken: string | null = null;
let isSigningIn = false;
const tokenListeners = new Set<(token: string | null) => void>();

export function setCachedCalendarAccessToken(token: string | null) {
  cachedAccessToken = token;
  tokenListeners.forEach((cb) => cb(token));
}

export function getCachedCalendarAccessToken(): string | null {
  return cachedAccessToken;
}

export function markAuthSigningIn(active: boolean) {
  isSigningIn = active;
}

export function subscribeCalendarAccessToken(
  cb: (token: string | null) => void
): () => void {
  tokenListeners.add(cb);
  cb(cachedAccessToken);
  return () => {
    tokenListeners.delete(cb);
  };
}

onAuthStateChanged(auth, (user) => {
  if (!user && !isSigningIn) {
    setCachedCalendarAccessToken(null);
  }
});

export enum OperationType {
  CREATE = "create",
  UPDATE = "update",
  DELETE = "delete",
  LIST = "list",
  GET = "get",
  WRITE = "write",
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.warn("Firestore Notice: ", JSON.stringify(errInfo));
  throw new Error(error instanceof Error ? error.message : "Please check your Firebase configuration.");
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, "test", "connection"));
  } catch {}
}

void testConnection();

