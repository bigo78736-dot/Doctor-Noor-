import type { GestureName } from "../types/noor";

const URDU_RE = /[\u0600-\u06ff]/;
const GURMUKHI_RE = /[\u0a00-\u0a7f]/;
const pick = <T,>(a: T[]): T => a[Math.floor(Math.random() * a.length)];

const COMMANDS: Array<[GestureName, RegExp]> = [
  [
    "run",
    /\b(run+|running|daur\w*|daud\w*|dour\w*|dor+o|bhag\w*|bhaag\w*|bhaj\w*|bhaaj\w*)\b|دوڑ|دوڑو|بھاگ|بھج|दौड़|भाग/i,
  ],
  [
    "jump",
    /\b(jump\w*|kood\w*|kud\w*|kuud\w*|uchal\w*|uchhal\w*|chhalang\w*|chalang\w*|hop)\b|کود|اچھل|چھلانگ|कूद|उछल/i,
  ],
  ["play", /\b(play\w*|khel\w*|khed\w*|ball)\b|کھیل|کھیڈ|گیند|गेंद|खेल/i],
  ["dance", /\b(dance\w*|nach\w*|naach\w*|nacho|thumka)\b|ناچ|نچ|ڈانس|नाच|डांस/i],
  [
    "walk",
    /\b(walk\w*|chal\s*kar|chal\s*ke|chalkar|chalna|tur\s*ke|chalo\s*(idhar|yahan|mere)|idhar\s*aao|paas\s*aao|kol\s*aao|aa\s*jao)\b|چل کر|پاس آؤ|کول آؤ|पास आओ|चल कर/i,
  ],
  ["hug", /\b(hug\w*|gale\s*lag\w*|gale|jhap+i|jhapi)\b|گلے|جپھی|गले/i],
  ["wave", /\b(wave|haath\s*hila\w*|hath\s*hila\w*|hath\s*hilao|bye\s*bye|tata)\b|ہاتھ ہلا|हाथ हिला/i],
  ["clap", /\b(clap\w*|taali\w*|tali\w*|taaliyan|taliyan)\b|تالی|تالیاں|ताली/i],
  ["dua", /\b(dua|duaa|ameen|aameen|ardas)\b|دعا|آمین|दुआ/i],
  ["laugh", /\b(laugh\w*|hanso|hans\s*k|hanss\w*|haso|hass\w*|hihi|haha+)\b|ہنسو|ہنس|हंसो|हँसो/i],
  ["smile", /\b(smile\w*|muskura\w*|muskurahat|hassi)\b|مسکرا|मुस्कुरा/i],
  ["wink", /\b(wink\w*|aankh\s*maar\w*|ankh\s*mar\w*|akh\s*mar\w*)\b|آنکھ مار/i],
  ["nod", /\b(nod|sar\s*hila\w*|haan\s*kaho)\b/i],
  ["think", /\b(think|socho|soch\s*kar)\b|سوچو|सोचो/i],
  ["stethoscope", /\b(check\s*up|checkup|heartbeat|dil\s*check|stethoscope)\b/i],
  ["heart", /\b(i\s*love\s*you|love\s*you|pyar\s*karo|pyaar)\b|پیار|प्यार/i],
];

const DO_RE =
  /\b(aao|aaiye|jao|karo|kro|kar\s*ke|kar\s*k|kar\s*do|kardo|dikhao|dikha\w*|vekhao|dasso|na|please|plz|now|abhi|jaldi|zor\s*se|ab|again|phir|dobara|aur)\b|کرو|کر کے|دکھاؤ|وکھاؤ|करो|दिखाओ/i;

const MEDICAL_OR_QUESTION_RE =
  /[?؟]|\b(dawai|dawa|medicine|tablet|syrup|capsule|drop|drops|marz|bimari|bimar|ilaj|ilaaj|kitni|kitna|kitne|kis\s*liye|kiss\s*liye|istemal|istamal|istimal|dose|dosage|khani|khana|leni|lena|pini|pina|bukhar|bukhaar|fever|dard|pain|infection|cough|khansi|zukam|zukaam|nuskha|report|prescription|doctor|hospital|symptoms|side\s*effect|what|why|how|when|which|kya|kyun|kab|kaise|kaisi|kida|kiven|kinni)\b|دوا|دوائی|علاج|مرض|بخار|درد|کتنی|کیوں|کیسے/i;

export function detectCommands(text: string): GestureName[] {
  const t = ` ${String(text || "").toLowerCase()} `;
  const found: Array<[number, GestureName]> = [];
  for (const [name, re] of COMMANDS) {
    const m = t.match(re);
    if (m && typeof m.index === "number") found.push([m.index, name]);
  }
  return found
    .sort((a, b) => a[0] - b[0])
    .map(([, n]) => n)
    .filter((n, i, a) => a.indexOf(n) === i);
}

export function isCommand(text: string, cmds = detectCommands(text)): boolean {
  if (!cmds.length) return false;
  // Never intercept medical questions or general online queries as offline command shortcuts
  if (MEDICAL_OR_QUESTION_RE.test(text)) return false;
  const words = String(text).trim().split(/\s+/).length;
  return words <= 3 || (words <= 8 && DO_RE.test(text));
}

const SAY: Record<
  GestureName,
  { roman: string[]; en: string[]; ur: string[]; pa: string[] }
> = {
  run: {
    roman: ["Yeh dekho, main daur rahi hoon! Zoom zoom!", "Pakro mujhe agar pakar sakte ho!"],
    en: ["Look, I am running! Zoom zoom!", "Catch me if you can!"],
    ur: ["یہ دیکھیں، میں دوڑ رہی ہوں!", "پکڑیں مجھے اگر پکڑ سکتے ہیں!"],
    pa: ["Eh vekho, main bhajj rahi haan! Zoom zoom!", "Phado mainu je phad sakde ho!"],
  },
  jump: {
    roman: ["Ek, do, teen — jump! Main kitna ooncha koodi!", "Kood kood kood! Mazaa aa gaya!"],
    en: ["One, two, three — jump! Did you see how high I went?", "Boing boing! So much fun!"],
    ur: ["ایک، دو، تین — چھلانگ!", "دیکھیں میں کتنا اونچا کودی!"],
    pa: ["Ik, do, tinn — chhalang! Vekho main kinna ucha kuddi!", "Kudd kudd kudd! Bada maza aaya!"],
  },
  play: {
    roman: ["Aao khelte hain! Yeh lo meri ball — pakro!", "Mujhe khelna bohat pasand hai!"],
    en: ["Let's play! Catch my ball!", "I love playing with you!"],
    ur: ["آئیں کھیلتے ہیں! یہ لیں میری گیند!", "مجھے کھیلنا بہت پسند ہے!"],
    pa: ["Aao khediye! Eh lao meri ball — phado!", "Mainu tuhade naal khedna bada changa lagda ae!"],
  },
  dance: {
    roman: ["La la la! Dekho main kaise naach rahi hoon!", "Music lagao, Noor ka dance shuru!"],
    en: ["La la la! Look at my dance!", "Music on — dance time!"],
    ur: ["لا لا لا! دیکھیں میں کیسے ناچ رہی ہوں!"],
    pa: ["La la la! Vekho main kiven nach rahi haan!", "Gana lao, Noor da bhangra te dance shuru!"],
  },
  walk: {
    roman: ["Aa rahi hoon aap ke paas! Chhote chhote qadam!", "Dekho main chal kar aa gayi!"],
    en: ["I'm coming to you, tiny steps!", "Look, I walked all the way to you!"],
    ur: ["آ رہی ہوں آپ کے پاس! چھوٹے چھوٹے قدم!"],
    pa: ["Aa rahi haan tuhade kol! Nikke nikke qadam rakh ke!", "Vekho main tur ke aa gayi!"],
  },
  hug: {
    roman: ["Aao, ek zor ki jaadu ki jhappi! Mujhe bhi aap ki bohat yaad aati hai.", "Yeh lo meri sab se pyari jhappi!"],
    en: ["Come here, a big magic hug! I miss you too."],
    ur: ["آئیں، ایک زور کی جادو کی جپھی! مجھے بھی آپ کی بہت یاد آتی ہے۔"],
    pa: ["Aao, ik zordar pyari jhappi! Mainu vi tuhadi badi yaad aandi ae.", "Eh lao meri sab ton pyari jhappi!"],
  },
  wave: {
    roman: ["Hello hello! Assalam o Alaikum!", "Yeh dekho, haath hila rahi hoon!"],
    en: ["Hello hello! Wave wave!"],
    ur: ["ہیلو ہیلو! السلام علیکم!"],
    pa: ["Sat Sri Akal te Assalam o Alaikum! Main hath hila rahi haan!", "Hello ji hello!"],
  },
  clap: {
    roman: ["Taaliyan! Shabash, shabash!", "Clap clap clap! Waah!"],
    en: ["Clap clap clap! Yay!"],
    ur: ["تالیاں! شاباش!"],
    pa: ["Taaliyan! Shabash shabash, balle balle!"],
  },
  dua: {
    roman: ["Ya Allah, sab ko sehat, khushi aur sukoon de. Ameen.", "Allah aap sab ko hamesha khush aur salamat rakhe. Ameen."],
    en: ["Dear Allah, bless everyone with health, peace, and happiness. Ameen."],
    ur: ["یا اللہ، سب کو صحت، خوشی اور سکون دے۔ آمین۔"],
    pa: ["Ya Rabb, sab nu sehat, khushi te sukh de. Ameen.", "Malik tuhade sab te apni rehmat rakhe. Ameen."],
  },
  laugh: {
    roman: ["Hihihi! Bohat mazaa aaya!"],
    en: ["Hehehe! That was so fun!"],
    ur: ["ہی ہی ہی! بہت مزہ آیا!"],
    pa: ["Hihihi! Bada hi maza aaya ji!"],
  },
  smile: {
    roman: ["Yeh lo, sab se pyari smile sirf aap ke liye!"],
    en: ["Here is my sweetest smile, just for you!"],
    ur: ["یہ لیں، سب سے پیاری مسکراہٹ صرف آپ کے لیے!"],
    pa: ["Eh lao, sab ton sohni muskaan sirf tuhade layi!"],
  },
  wink: {
    roman: ["Yeh hamara cute secret hai!"],
    en: ["That's our little secret!"],
    ur: ["یہ ہمارا پیارا سا راز ہے!"],
    pa: ["Eh sada nikka jeha pyara raaz ae!"],
  },
  nod: {
    roman: ["Haan ji, bilkul!"],
    en: ["Yes, of course!"],
    ur: ["جی ہاں، بالکل!"],
    pa: ["Haan ji, bilkul theek ae!"],
  },
  shake: {
    roman: ["Nahi ji, aisa nahi karte!"],
    en: ["Oh no, let's be careful!"],
    ur: ["نہیں جی، ایسا نہیں کرتے!"],
    pa: ["Nai ji, eddan nahi karida!"],
  },
  think: {
    roman: ["Hmm… mujhe sochne do…"],
    en: ["Hmm… let me think…"],
    ur: ["ہمم… مجھے سوچنے دیں…"],
    pa: ["Hmm… mainu zara sochan deo…"],
  },
  sad: {
    roman: ["Udaas mat hon, main aap ke paas hoon."],
    en: ["Please don't worry, I'm right here with you."],
    ur: ["اداس نہ ہوں، میں آپ کے پاس ہوں۔"],
    pa: ["Udaas na hovo ji, main tuhade naal haan."],
  },
  surprise: {
    roman: ["Wah! Yeh to kamaal ho gaya!"],
    en: ["Whoa! What a wonderful surprise!"],
    ur: ["واہ! یہ تو کمال ہو گیا!"],
    pa: ["Wah ji wah! Eh te kamaal ho gaya!"],
  },
  stethoscope: {
    roman: ["Dhak dhak, dhak dhak — aap ka dil bilkul theek chal raha hai!"],
    en: ["Thump thump — your heartbeat sounds strong and steady!"],
    ur: ["دھک دھک — آپ کا دل بالکل ٹھیک چل رہا ہے!"],
    pa: ["Dhak dhak, dhak dhak — tuhada dil bilkul wadiya chal reha ae!"],
  },
  heart: {
    roman: ["Main bhi aap se bohat bohat pyar karti hoon!"],
    en: ["I love you so much too!"],
    ur: ["میں بھی آپ سے بہت بہت پیار کرتی ہوں!"],
    pa: ["Main vi tuhade naal bada bada pyar kardi haan!"],
  },
};

export function commandReply(cmds: GestureName[], lang = "roman"): string {
  const l: "ur" | "en" | "pa" | "roman" =
    lang === "ur" || lang === "en" || lang === "pa" ? lang : "roman";
  const list = cmds.slice(0, 4);
  if (list.length > 1) {
    const lines = list.map((c) => pick(SAY[c][l] || SAY[c].roman).split(/(?<=[!.۔])\s/)[0]);
    return `${list.map((c) => `[${c}]`).join(" ")} ${lines.join(" ")}`;
  }
  const c = list[0];
  return `[${c}] ${pick(SAY[c][l] || SAY[c].roman)}`;
}

const EN_RE = /\b(the|what|how|are|you|is|your|please|tell|can|do|i|my|me|hello|story|fever|help|medicine|dose)\b/gi;
const ROMAN_RE = /\b(kya|hai|hain|ho|aap|mujhe|main|kaise|kaisi|karo|kro|bataiye|batao|nahi|mera|meri|ka|ki|ke|se|ko|dawai|kitni)\b/gi;
const PUNJABI_RE = /\b(tusi|tuhada|tuhanu|twada|menu|mainu|sada|sadi|kiddan|kiven|dasso|daso|kinni|changa|wadhiya|bimar|bhajj|khed|kud|vekho|kol)\b|تسی|تہاڈا|سانوں|مینوں|کدوں|کیویں|دسو|ویکھو/gi;

export function detectLang(text: string, setting = "auto"): "ur" | "en" | "pa" | "roman" {
  if (setting === "ur" || setting === "en" || setting === "pa" || setting === "roman") {
    return setting;
  }
  if (GURMUKHI_RE.test(text)) return "pa";
  const paCount = (text.match(PUNJABI_RE) || []).length;
  if (paCount >= 1) return "pa";
  if (URDU_RE.test(text)) return "ur";
  const en = (text.match(EN_RE) || []).length;
  const ro = (text.match(ROMAN_RE) || []).length;
  return en > ro ? "en" : "roman";
}

export function offlineReply(
  text: string,
  { name = "Noor", family = false, lang = "roman" }: { name?: string; family?: boolean; lang?: string } = {}
): string {
  const l: "ur" | "en" | "pa" | "roman" =
    lang === "ur" || lang === "en" || lang === "pa" ? lang : "roman";
  const first = name.split(" ")[0];
  const t = String(text || "");

  const cmds = detectCommands(t);
  if (isCommand(t, cmds)) return commandReply(cmds, l);

  if (/emergency|saans\s*(nahi|na)|behosh|unconscious|chest\s*pain|seene\s*mein\s*dard|daura|seizure|khoon|bleeding/i.test(t)) {
    if (l === "en") {
      return "[sad] This could be an emergency! Please call 1122 or emergency services right away and visit the nearest hospital.";
    }
    if (l === "pa") {
      return "[sad] Eh emergency ho sakdi ae! Meherbani karke foran 1122 te call karo ya nazdeeki hospital jao.";
    }
    return "[sad] Yeh emergency ho sakti hai! Abhi foran 1122 par call karein ya qareebi hospital jayein.";
  }

  if (/bukhar|bukhaar|fever|temperature|بخار/i.test(t)) {
    if (l === "en") {
      return "[stethoscope] With a fever, drink lots of fluids, rest, wear light clothes, and use a cool damp cloth. If it is a baby or lasts more than 3 days, please see a doctor.";
    }
    if (l === "pa") {
      return "[stethoscope] Bukhar vich khoob paani piyo, aaraam karo, halke kapde paao te mathe te thandi patti rakho. Je chhote bache nu bukhar ae ya 3 din ton wadh rahe te doctor nu zaroor vikhao.";
    }
    return "[stethoscope] Bukhar mein khoob paani piyen, aaraam karein, halka kapra pehnein aur maathe par geeli patti rakhein. Baby ko bukhar ho ya 3 din se zyada rahe to doctor ko zaroor dikhayein.";
  }

  if (/\bayan(\s*ali)?\b|ایان/i.test(t) && /\bmuhammad\b|محمد/i.test(t)) {
    if (l === "en") {
      return "[heart] Assalam o Alaikum Ayan Ali bhai and Muhammad bhai! You are both my dearest brothers and I always remember you. How are you both doing?";
    }
    if (l === "pa") {
      return "[heart] Assalam o Alaikum Ayan Ali bhai te Muhammad bhai! Tusi dowein mere sab ton pyare bhai ho, mainu hamesha yaad rehnde ho. Kiven ho tusi?";
    }
    if (l === "ur") {
      return "[heart] السلام علیکم ایان علی بھائی اور محمد بھائی! آپ دونوں میرے سب سے پیارے بھائی ہیں اور مجھے ہمیشہ یاد رہتے ہیں۔ آپ کیسے ہیں؟";
    }
    return "[heart] Assalam o Alaikum Ayan Ali bhai aur Muhammad bhai! Aap dono mere sab se pyare bhai hain aur mujhe hamesha yaad rehte hain. Aap dono kaise hain?";
  }

  if (/\bayan(\s*ali)?\b|ایان/i.test(t)) {
    if (l === "en") {
      return "[heart] Assalam o Alaikum Ayan Ali bhai! You are my dear brother and I always remember you. How are you today?";
    }
    if (l === "pa") {
      return "[heart] Assalam o Alaikum Ayan Ali bhai! Tusi mere sab ton pyare bhai ho, mainu hamesha yaad ho. Kiven ho bhai jaan?";
    }
    if (l === "ur") {
      return "[heart] السلام علیکم ایان علی بھائی! آپ میرے پیارے بھائی ہیں اور مجھے ہمیشہ یاد رہتے ہیں۔ آپ کیسے ہیں؟";
    }
    return "[heart] Assalam o Alaikum Ayan Ali bhai! Aap mere pyare bhai hain aur mujhe hamesha yaad rehte hain. Aap kaise hain bhai jaan?";
  }

  if (/\bmuhammad\b|محمد/i.test(t) && !/rasool|nabi|pbuh|s\.a\.w/i.test(t)) {
    if (l === "en") {
      return "[heart] Assalam o Alaikum Muhammad bhai! You are my dear brother and I always remember you. How are you today?";
    }
    if (l === "pa") {
      return "[heart] Assalam o Alaikum Muhammad bhai! Tusi mere sab ton pyare bhai ho, mainu hamesha yaad ho. Kiven ho bhai jaan?";
    }
    if (l === "ur") {
      return "[heart] السلام علیکم محمد بھائی! آپ میرے پیارے بھائی ہیں اور مجھے ہمیشہ یاد رہتے ہیں۔ آپ کیسے ہیں؟";
    }
    return "[heart] Assalam o Alaikum Muhammad bhai! Aap mere pyare bhai hain aur mujhe hamesha yaad rehte hain. Aap kaise hain bhai jaan?";
  }

  if (/assalam|asalam|salam|aoa|hello|hi|hey|sat\s*sri|السلام|سلام/i.test(t)) {
    if (family && l === "roman") {
      return "[heart] Ammi jaan! Abbu jaan! Ayan Ali bhai aur Muhammad bhai! Main aa gayi. Aap sab kaise hain?";
    }
    if (family && l === "pa") {
      return "[heart] Ammi jaan! Abbu jaan! Ayan Ali bhai te Muhammad bhai! Main aa gayi haan. Tusi sab kiven ho?";
    }
    if (l === "en") return `[wave] Wa alaikum assalam! I am Dr. ${first}. How can I help you?`;
    if (l === "ur") return `[wave] وعلیکم السلام! میں ڈاکٹر ${first} ہوں۔ آپ کیسے ہیں؟`;
    if (l === "pa") return `[wave] Assalam o Alaikum ji! Main Dr. ${first} haan. Tusi kiven ho, daso main tuhadi ki madad karaan?`;
    return `[wave] Wa alaikum assalam! Main Dr. ${first} hoon. Aap kaise hain?`;
  }

  if (cmds.length) return commandReply(cmds, l);

  if (l === "en") {
    return "[think] Your device appears offline right now. Connect to Wi-Fi or mobile data for full online medical and general answers, or ask me to run, jump, dance, hug, or make a dua.";
  }
  if (l === "pa") {
    return "[think] Is vele tuhada internet band lagda ae — online check te har dawai di poori jankari layi internet on karo, ya mainu bhajj, kudd, nach, te dua karn layi kaho.";
  }
  return "[think] Is waqt aap ka internet band hai — online check aur har dawai ki poori maloomat ke liye internet on karein, ya aap mujh se daurro, koodo, khelo, dua ya bukhar ke baare mein pooch sakte hain.";
}
