import type { FacePoints, GestureName } from "../types/noor";

const clamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const ease = (t: number) => 0.5 - Math.cos(Math.PI * clamp(t, 0, 1)) / 2;
const smooth = (k60: number, dt: number) => 1 - Math.pow(1 - k60, dt * 60);

export const GESTURES: Record<GestureName, number> = {
  smile: 2.6,
  laugh: 2.4,
  wave: 2.8,
  nod: 1.6,
  shake: 1.5,
  jump: 2.8,
  dance: 5.0,
  heart: 2.6,
  think: 2.6,
  sad: 3.0,
  wink: 0.8,
  stethoscope: 3.2,
  walk: 5.2,
  run: 4.4,
  clap: 2.4,
  hug: 3.4,
  dua: 3.8,
  play: 5.6,
  surprise: 1.7,
};

const DEFAULT_POINTS: FacePoints = {
  leftEye: { x: 0.45036, y: 0.29749 },
  rightEye: { x: 0.54638, y: 0.30176 },
  mouth: { x: 0.49198, y: 0.34334 },
  eyeScale: 1.12,
  mouthScale: 1.2,
};

const V_OPEN = "aāáàâäاآعہة";
const V_SPREAD = "eéêëiíîïīyیےيئ";
const V_ROUND = "oóôöuúûüūwوؤ";
const V_CLOSED = "mbpمبپ";
const V_TEETH = "fvف";
const PAUSE_RE = /[\s.,!?;:۔،؟\-—…"']/;

function viseme(ch: string | undefined): [number, number] {
  if (!ch) return [0, 0.5];
  if (V_OPEN.includes(ch)) return [0.92, 0.62];
  if (V_SPREAD.includes(ch)) return [0.48, 0.95];
  if (V_ROUND.includes(ch)) return [0.6, 0.12];
  if (V_CLOSED.includes(ch)) return [0, 0.48];
  if (V_TEETH.includes(ch)) return [0.14, 0.62];
  if (PAUSE_RE.test(ch)) return [0.03, 0.5];
  if (/[0-9]/.test(ch)) return [0.5, 0.6];
  return [0.3, 0.55];
}

interface ComputedFace {
  L: { x: number; y: number };
  R: { x: number; y: number };
  M: { x: number; y: number };
  d: number;
  eyeScale: number;
  mouthScale: number;
  lidColor: [string, string];
}

interface LimbPose {
  lArmRot: number;
  rArmRot: number;
  lElbowRot: number;
  rElbowRot: number;
  lArmTx: number;
  rArmTx: number;
  lArmTy: number;
  rArmTy: number;
  lLegTy: number;
  rLegTy: number;
  lLegTx: number;
  rLegTx: number;
  lLegRot: number;
  rLegRot: number;
  lLegSc: number;
  rLegSc: number;
  headRot: number;
  headTx: number;
  headTy: number;
  torsoRot: number;
  torsoSy: number;
  bgShiftX: number;
}

const ZERO_LIMB: LimbPose = {
  lArmRot: 0,
  rArmRot: 0,
  lElbowRot: 0,
  rElbowRot: 0,
  lArmTx: 0,
  rArmTx: 0,
  lArmTy: 0,
  rArmTy: 0,
  lLegTy: 0,
  rLegTy: 0,
  lLegTx: 0,
  rLegTx: 0,
  lLegRot: 0,
  rLegRot: 0,
  lLegSc: 1,
  rLegSc: 1,
  headRot: 0,
  headTx: 0,
  headTy: 0,
  torsoRot: 0,
  torsoSy: 1,
  bgShiftX: 0,
};

interface PuppetLayers {
  baseClean: HTMLCanvasElement;
  torso: HTMLCanvasElement;
  head: HTMLCanvasElement;
  leftUpperArm: HTMLCanvasElement;
  leftForearm: HTMLCanvasElement;
  rightUpperArm: HTMLCanvasElement;
  rightForearm: HTMLCanvasElement;
  leftLeg: HTMLCanvasElement;
  rightLeg: HTMLCanvasElement;
  // Normalized anchor pivots in W x H pixel space
  headPivot: { x: number; y: number };
  torsoPivot: { x: number; y: number };
  lShoulder: { x: number; y: number };
  lElbow: { x: number; y: number };
  rShoulder: { x: number; y: number };
  rElbow: { x: number; y: number };
  lHip: { x: number; y: number };
  rHip: { x: number; y: number };
}

async function loadImage(src: string): Promise<HTMLImageElement> {
  const img = new Image();
  img.decoding = "async";
  if (!/^(data|blob):/.test(src)) img.crossOrigin = "anonymous";
  img.src = src;
  await img.decode();
  return img;
}

function shade(rgb: string, amt: number): string {
  const m = rgb.match(/\d+/g);
  if (!m) return rgb;
  const [r, g, b] = m.map((v) => clamp(+v + amt, 0, 255) | 0);
  return `rgb(${r},${g},${b})`;
}

function makeFeatheredCutout(
  src: HTMLImageElement,
  W: number,
  H: number,
  nx: number,
  ny: number,
  nw: number,
  nh: number,
  featherX = 0.18,
  featherY = 0.14
): HTMLCanvasElement {
  const c = document.createElement("canvas");
  c.width = W;
  c.height = H;
  const ctx = c.getContext("2d")!;
  const x = nx * W;
  const y = ny * H;
  const w = nw * W;
  const h = nh * H;

  // Draw region directly into matching full-size layer so pivot coordinates remain exact
  ctx.drawImage(src, x, y, w, h, x, y, w, h);

  // Soft edge feathering mask
  ctx.globalCompositeOperation = "destination-in";
  const fx = w * featherX;
  const fy = h * featherY;

  const hGrad = ctx.createLinearGradient(x, 0, x + w, 0);
  hGrad.addColorStop(0, "rgba(0,0,0,0)");
  hGrad.addColorStop(clamp(fx / w, 0.02, 0.45), "rgba(0,0,0,1)");
  hGrad.addColorStop(clamp(1 - fx / w, 0.55, 0.98), "rgba(0,0,0,1)");
  hGrad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = hGrad;
  ctx.fillRect(x, y, w, h);

  const vGrad = ctx.createLinearGradient(0, y, 0, y + h);
  vGrad.addColorStop(0, "rgba(0,0,0,0)");
  vGrad.addColorStop(clamp(fy / h, 0.02, 0.45), "rgba(0,0,0,1)");
  vGrad.addColorStop(clamp(1 - fy / h, 0.55, 0.98), "rgba(0,0,0,1)");
  vGrad.addColorStop(1, "rgba(0,0,0,0)");
  ctx.fillStyle = vGrad;
  ctx.fillRect(x, y, w, h);

  ctx.globalCompositeOperation = "source-over";
  return c;
}

function buildNoorPuppet(img: HTMLImageElement): PuppetLayers {
  const W = img.naturalWidth;
  const H = img.naturalHeight;

  // 1. Create clean torso/background plate with soft marble/backdrop inpainting under arms & shoes
  const baseClean = document.createElement("canvas");
  baseClean.width = W;
  baseClean.height = H;
  const bc = baseClean.getContext("2d")!;
  bc.drawImage(img, 0, 0, W, H);

  const inpaintPatch = (
    srcX: number,
    srcY: number,
    srcW: number,
    srcH: number,
    dstX: number,
    dstY: number,
    dstW: number,
    dstH: number
  ) => {
    const tmp = document.createElement("canvas");
    tmp.width = Math.max(4, Math.round(dstW * W));
    tmp.height = Math.max(4, Math.round(dstH * H));
    const tc = tmp.getContext("2d")!;
    tc.drawImage(
      img,
      srcX * W,
      srcY * H,
      srcW * W,
      srcH * H,
      0,
      0,
      tmp.width,
      tmp.height
    );
    tc.globalCompositeOperation = "destination-in";
    const g = tc.createRadialGradient(
      tmp.width * 0.5,
      tmp.height * 0.5,
      tmp.width * 0.18,
      tmp.width * 0.5,
      tmp.height * 0.5,
      Math.max(tmp.width, tmp.height) * 0.55
    );
    g.addColorStop(0, "rgba(0,0,0,1)");
    g.addColorStop(0.62, "rgba(0,0,0,0.92)");
    g.addColorStop(1, "rgba(0,0,0,0)");
    tc.fillStyle = g;
    tc.fillRect(0, 0, tmp.width, tmp.height);
    bc.drawImage(tmp, dstX * W, dstY * H);
  };

  // Inpaint outer left arm zone from adjacent clean marble/crowd on far left
  inpaintPatch(0.05, 0.39, 0.14, 0.31, 0.18, 0.39, 0.17, 0.31);
  // Inpaint outer right arm zone from adjacent clean marble/crowd on far right
  inpaintPatch(0.82, 0.39, 0.14, 0.31, 0.65, 0.39, 0.17, 0.31);
  // Inpaint left & right shoe floor zones cleanly from exact row-aligned marble tiles
  inpaintPatch(0.06, 0.78, 0.16, 0.155, 0.255, 0.78, 0.21, 0.155);
  inpaintPatch(0.78, 0.78, 0.16, 0.155, 0.545, 0.78, 0.21, 0.155);
  // Clean center gap between shoes
  inpaintPatch(0.08, 0.79, 0.12, 0.135, 0.43, 0.79, 0.15, 0.135);

  // 2. Cut clean multi-joint articulated sprites calibrated to public/assets/noor-base.jpg (714x1280)
  const head = makeFeatheredCutout(img, W, H, 0.30, 0.16, 0.45, 0.23, 0.11, 0.08);
  const torso = makeFeatheredCutout(img, W, H, 0.305, 0.36, 0.39, 0.505, 0.08, 0.05);

  const leftUpperArm = makeFeatheredCutout(img, W, H, 0.235, 0.38, 0.14, 0.155, 0.16, 0.14);
  const leftForearm = makeFeatheredCutout(img, W, H, 0.195, 0.485, 0.15, 0.20, 0.14, 0.12);

  const rightUpperArm = makeFeatheredCutout(img, W, H, 0.625, 0.38, 0.145, 0.155, 0.16, 0.14);
  const rightForearm = makeFeatheredCutout(img, W, H, 0.65, 0.485, 0.16, 0.20, 0.14, 0.12);

  const leftLeg = makeFeatheredCutout(img, W, H, 0.27, 0.785, 0.185, 0.145, 0.14, 0.12);
  const rightLeg = makeFeatheredCutout(img, W, H, 0.555, 0.785, 0.19, 0.145, 0.14, 0.12);

  return {
    baseClean,
    torso,
    head,
    leftUpperArm,
    leftForearm,
    rightUpperArm,
    rightForearm,
    leftLeg,
    rightLeg,
    headPivot: { x: 0.5 * W, y: 0.37 * H },
    torsoPivot: { x: 0.5 * W, y: 0.78 * H },
    lShoulder: { x: 0.345 * W, y: 0.415 * H },
    lElbow: { x: 0.285 * W, y: 0.505 * H },
    rShoulder: { x: 0.655 * W, y: 0.415 * H },
    rElbow: { x: 0.715 * W, y: 0.505 * H },
    lHip: { x: 0.365 * W, y: 0.805 * H },
    rHip: { x: 0.645 * W, y: 0.805 * H },
  };
}

export class AvatarEngine {
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  onEffect: (name: GestureName) => void;
  fit: "contain" | "cover";
  body = true;
  zoom = false;
  W = 1;
  H = 1;
  img: HTMLImageElement | null = null;
  puppet: PuppetLayers | null = null;
  face: ComputedFace | null = null;
  view: { s: number; x: number; y: number } | null = null;
  pivot = { x: 0, y: 0 };

  speaking = false;
  listening = false;
  audioEnergy = 0;
  mouthOpen = 0;
  mouthWide = 0.5;
  mouthTarget = 0;
  wideTarget = 0.5;
  nextSyllable = 0;
  lip: { text: string; syncIdx: number; syncT: number; cps: number } | null = null;
  emph = 0;
  tilt = 0;
  tiltTarget = 0;
  brow = 0;
  browTarget = 0;
  browUntil = 0;
  smile = 0.22;
  smileTarget = 0.22;
  blink = 0;
  blinkL = 0;
  blinkR = 0;
  nextBlink = performance.now() + 1400;
  blinkStart = -1e9;
  winkStart = -1e9;
  look = { x: 0, y: 0, tx: 0, ty: 0, next: 0, mx: 0, my: 0, mnext: 0 };
  follow = { x: 0, y: 0, until: 0 };
  gesture: { name: GestureName; start: number; dur: number } | null = null;
  queue: GestureName[] = [];
  T = { rot: 0, tx: 0, ty: 0, sc: 1, sy: 1 };
  L: LimbPose = { ...ZERO_LIMB };
  last = performance.now();

  patch: HTMLCanvasElement;
  patchCtx: CanvasRenderingContext2D;
  bg: HTMLCanvasElement;
  running = false;
  rafId = 0;

  constructor(
    canvas: HTMLCanvasElement,
    opts: { onEffect?: (name: GestureName) => void; fit?: "contain" | "cover"; body?: boolean } = {}
  ) {
    this.canvas = canvas;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("2D context unavailable");
    this.ctx = ctx;
    this.onEffect = opts.onEffect || (() => {});
    this.fit = opts.fit || "contain";
    this.body = opts.body ?? true;
    this.patch = document.createElement("canvas");
    const pctx = this.patch.getContext("2d");
    if (!pctx) throw new Error("Patch 2D context unavailable");
    this.patchCtx = pctx;
    this.bg = document.createElement("canvas");

    this._loop = this._loop.bind(this);
    this._resize = this._resize.bind(this);
    window.addEventListener("resize", this._resize);
  }

  async load(src: string, points: FacePoints, body = true) {
    const img = await loadImage(src);
    this.img = img;
    this.W = img.naturalWidth;
    this.H = img.naturalHeight;
    this.body = body;
    // Enable full articulated puppet rig for Noor's portrait when bodyMode is enabled
    const isNoorPortrait = /noor-base\.jpg/i.test(src);
    this.puppet = body && isNoorPortrait ? buildNoorPuppet(img) : null;
    this.setPoints(points);
    if (!this.running) {
      this.running = true;
      this.last = performance.now();
      this.rafId = requestAnimationFrame(this._loop);
    }
  }

  setPoints(points: FacePoints) {
    if (!this.img) return;
    const p = points || DEFAULT_POINTS;
    const L = { x: p.leftEye.x * this.W, y: p.leftEye.y * this.H };
    const R = { x: p.rightEye.x * this.W, y: p.rightEye.y * this.H };
    const M = { x: p.mouth.x * this.W, y: p.mouth.y * this.H };
    const d = Math.hypot(R.x - L.x, R.y - L.y) || this.W * 0.1;
    this.face = {
      L,
      R,
      M,
      d,
      eyeScale: p.eyeScale || 1,
      mouthScale: p.mouthScale || 1,
      lidColor: this._sampleLid(this.img, L, R, d),
    };
    this._resize();
  }

  setZoom(on: boolean) {
    this.zoom = on;
    this._resize();
  }

  lookAt(clientX: number, clientY: number) {
    const f = this.getFace();
    if (!f) return;
    const nx = clamp((clientX - f.x) / (f.d * 3), -1, 1);
    const ny = clamp((clientY - f.y) / (f.d * 3), -1, 1);
    this.follow = { x: nx, y: ny, until: performance.now() + 2000 };
  }

  setSpeaking(on: boolean) {
    this.speaking = on;
    if (!on) {
      this.mouthTarget = 0;
      this.wideTarget = 0.5;
      this.audioEnergy = 0;
      this.lip = null;
      this.tiltTarget = 0;
    }
  }

  setListening(on: boolean) {
    this.listening = on;
  }

  setAudioEnergy(rms: number) {
    this.audioEnergy = clamp(rms, 0, 1);
  }

  speakText(text: string, rate = 1) {
    const now = performance.now();
    const t = String(text || "").toLowerCase();
    this.lip = { text: t, syncIdx: 0, syncT: now, cps: 13.5 * rate };
    const question =
      /[?؟]\s*$/.test(t) ||
      /^(kya|kia|kaun|kab|kahan|kaise|kyun|what|why|how|who|where|when)\b/.test(t);
    const excited = /!\s*$/.test(t);
    this.tiltTarget = question ? (Math.random() < 0.5 ? -1 : 1) : 0;
    if (question || excited) this.liftBrows(question ? 0.9 : 0.65);

    const L = this.look;
    if (Math.random() < 0.25) {
      L.tx = (Math.random() < 0.5 ? -1 : 1) * 0.55;
      L.ty = -0.4;
      L.next = now + 500;
    } else {
      L.tx = 0;
      L.ty = 0;
      L.next = now + 1200 + Math.random() * 1400;
    }
  }

  wordBoundary(charIndex: number, charLength = 0) {
    const now = performance.now();
    const L = this.lip;
    if (!L) {
      this.mouthTarget = 0.72 + Math.random() * 0.25;
      this.nextSyllable = now + 110;
      return;
    }
    if (Number.isFinite(charIndex)) {
      if (charIndex > L.syncIdx && now - L.syncT > 80) {
        const measured = (charIndex - L.syncIdx) / ((now - L.syncT) / 1000);
        L.cps = clamp(lerp(L.cps, measured, 0.35), 6, 28);
      }
      L.syncIdx = charIndex;
      L.syncT = now;
    }
    if (charLength >= 5 || Math.random() < 0.25) this.emph = Math.min(1, this.emph + 0.7);
    if (charLength >= 7 && Math.random() < 0.3) this.liftBrows(0.4);
  }

  liftBrows(amount = 0.7) {
    this.browTarget = Math.max(this.browTarget, amount);
    this.browUntil = performance.now() + 450 + amount * 380;
  }

  play(name: GestureName) {
    if (!GESTURES[name]) return;
    this.queue = [];
    this._start(name);
  }

  enqueue(names: GestureName[]) {
    const list = names.filter((n) => GESTURES[n]);
    if (!list.length) return;
    if (!this.gesture) this._start(list.shift()!);
    this.queue.push(...list);
  }

  private _start(name: GestureName) {
    const now = performance.now();
    this.gesture = { name, start: now, dur: GESTURES[name] * 1000 };
    if (name === "wink") this.winkStart = now;
    if (["jump", "surprise", "laugh", "wave", "play", "clap"].includes(name)) {
      this.liftBrows(name === "surprise" ? 1 : 0.75);
    }
    this.onEffect(name);
  }

  getFace() {
    if (!this.view || !this.face) return null;
    const rect = this.canvas.getBoundingClientRect();
    const dpr = this.canvas.width / (rect.width || 1);
    const { s, x, y } = this.view;
    const f = this.face;
    return {
      x: (x + f.M.x * s) / dpr,
      y: (y + ((f.L.y + f.R.y) / 2) * s) / dpr,
      mouthY: (y + f.M.y * s) / dpr,
      d: Math.max((f.d * s) / dpr, 55),
      feetY: (y + this.H * 0.94 * s) / dpr,
    };
  }

  private _sampleLid(
    src: HTMLImageElement,
    L: { x: number; y: number },
    R: { x: number; y: number },
    d: number
  ): [string, string] {
    try {
      const c = document.createElement("canvas");
      c.width = c.height = 6;
      const x = c.getContext("2d", { willReadFrequently: true });
      if (!x) return ["rgb(224,180,150)", "rgb(224,180,150)"];
      const avg: string[] = [];
      for (const E of [L, R]) {
        const s = d * 0.12;
        x.clearRect(0, 0, 6, 6);
        x.drawImage(src, E.x - s, E.y - d * 0.2 - s / 2, s * 2, s, 0, 0, 6, 6);
        const data = x.getImageData(0, 0, 6, 6).data;
        let r = 0,
          g = 0,
          b = 0;
        for (let i = 0; i < data.length; i += 4) {
          r += data[i];
          g += data[i + 1];
          b += data[i + 2];
        }
        const n = data.length / 4;
        avg.push(`rgb(${(r / n) | 0},${(g / n) | 0},${(b / n) | 0})`);
      }
      return [avg[0], avg[1]];
    } catch {
      return ["rgb(224,180,150)", "rgb(224,180,150)"];
    }
  }

  resize() {
    this._resize();
  }

  private _resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const rect = this.canvas.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    this.canvas.width = Math.max(1, Math.round(rect.width * dpr));
    this.canvas.height = Math.max(1, Math.round(rect.height * dpr));
    if (!this.img || !this.face) return;

    const cw = this.canvas.width;
    const ch = this.canvas.height;
    const W = this.W;
    const H = this.H;
    const contain = Math.min(cw / W, ch / H);
    const cover = Math.max(cw / W, ch / H);

    let s: number;
    if (this.body) {
      s = this.zoom ? Math.max(cover, contain * 2.05) : contain * 1.0;
    } else {
      s = this.fit === "cover" ? cover : Math.min(cover, contain * 1.15);
    }

    const f = this.face;
    let x = (cw - W * s) / 2;
    let y = (ch - H * s) / 2;
    if (this.body && !this.zoom) {
      y = ch - H * s - ch * 0.01;
    }
    const focusY = this.body && this.zoom ? f.M.y + f.d * 1.4 : f.M.y;
    if (H * s > ch) y = clamp(ch * (this.body ? 0.36 : 0.45) - focusY * s, ch - H * s, 0);
    if (W * s > cw) x = clamp(cw * 0.5 - f.M.x * s, cw - W * s, 0);

    this.view = { s, x, y };
    this.pivot = this.body ? { x: W / 2, y: H * 0.94 } : { x: f.M.x, y: f.M.y + f.d * 0.9 };

    this.bg.width = Math.max(1, cw >> 2);
    this.bg.height = Math.max(1, ch >> 2);
    const b = this.bg.getContext("2d");
    if (b) {
      b.filter = "blur(14px) brightness(0.42) saturate(1.18)";
      const bs = Math.max(this.bg.width / W, this.bg.height / H) * 1.18;
      b.drawImage(
        this.img,
        (this.bg.width - W * bs) / 2,
        (this.bg.height - H * bs) / 2,
        W * bs,
        H * bs
      );
    }
  }

  destroy() {
    this.running = false;
    cancelAnimationFrame(this.rafId);
    window.removeEventListener("resize", this._resize);
  }

  private _loop(now: number) {
    if (!this.running) return;
    const dt = clamp((now - this.last) / 1000, 0, 0.1);
    this.last = now;
    this._update(now, dt);
    this._draw(now, dt);
    this.rafId = requestAnimationFrame(this._loop);
  }

  private _update(now: number, dt: number) {
    const g = this.gesture;
    const gp = g ? (now - g.start) / g.dur : 1;
    if (g && gp >= 1) {
      this.gesture = null;
      if (this.queue.length) this._start(this.queue.shift()!);
    }
    const gname = this.gesture?.name;

    const happy =
      gname &&
      [
        "smile",
        "laugh",
        "heart",
        "wave",
        "dance",
        "jump",
        "wink",
        "walk",
        "run",
        "clap",
        "hug",
        "play",
      ].includes(gname);

    this.smileTarget =
      gname === "sad"
        ? -0.35
        : gname === "dua"
          ? 0.28
          : gname === "surprise"
            ? 0.1
            : happy
              ? 1
              : this.speaking
                ? 0.42
                : 0.22;
    this.smile = lerp(this.smile, this.smileTarget, smooth(0.09, dt));

    // Real-time lip & jaw sync: audio RMS waveform first, then syllable viseme fallback
    if (gname === "laugh") {
      this.mouthTarget = 0.55 + 0.45 * Math.abs(Math.sin(now / 68));
      this.wideTarget = 0.84;
    } else if (gname === "surprise") {
      this.mouthTarget = 0.72;
      this.wideTarget = 0.12;
    } else if (this.speaking && this.audioEnergy > 0.008) {
      const wave = clamp(this.audioEnergy * 2.25, 0.04, 1);
      const lipW = 0.46 + 0.42 * Math.sin(now / 110) * 0.5;
      this.mouthTarget = wave;
      this.wideTarget = lipW;
      if (wave > 0.65 && Math.random() < 0.08) this.emph = Math.min(1, this.emph + 0.38);
    } else if (this.speaking && this.lip) {
      const L = this.lip;
      const idx = L.syncIdx + ((now - L.syncT) / 1000) * L.cps;
      const i = Math.floor(idx);
      if (i >= L.text.length) {
        this.mouthTarget = 0.02;
        this.wideTarget = 0.5;
      } else {
        const [o, w] = viseme(L.text[i]);
        const [o2, w2] = viseme(L.text[i + 1]);
        const f = idx - i;
        const vary = 0.85 + 0.3 * Math.sin(now / 97 + i);
        this.mouthTarget = clamp(lerp(o, o2, f * 0.45) * vary, 0, 1);
        this.wideTarget = lerp(w, w2, f * 0.45);
      }
    } else if (this.speaking) {
      if (now > this.nextSyllable) {
        const r = Math.random();
        this.mouthTarget = r < 0.15 ? 0.05 : 0.35 + Math.random() * 0.65;
        this.wideTarget = 0.3 + Math.random() * 0.6;
        this.nextSyllable = now + 85 + Math.random() * 110;
      }
    } else {
      this.mouthTarget = 0;
      this.wideTarget = 0.5;
    }

    const mk = this.speaking || gname === "laugh" ? 0.48 : 0.22;
    this.mouthOpen = lerp(this.mouthOpen, this.mouthTarget, smooth(mk, dt));
    this.mouthWide = lerp(this.mouthWide, this.wideTarget, smooth(0.35, dt));

    this.emph = Math.max(0, this.emph - dt * 3.2);
    this.tilt = lerp(this.tilt, this.tiltTarget, smooth(0.06, dt));

    if (now > this.browUntil) this.browTarget = 0;
    this.brow = lerp(
      this.brow,
      this.browTarget,
      smooth(this.browTarget > this.brow ? 0.26 : 0.09, dt)
    );

    if (now > this.nextBlink) {
      this.blinkStart = now;
      // 22% chance of realistic rapid double-blink
      const doubleBlink = Math.random() < 0.22;
      this.nextBlink = doubleBlink ? now + 260 : now + 2000 + Math.random() * 3400;
    }
    const bt = now - this.blinkStart;
    this.blink =
      bt < 0
        ? 0
        : bt < 60
          ? ease(bt / 60)
          : bt < 85
            ? 1
            : bt < 235
              ? 1 - ease((bt - 85) / 150)
              : 0;
    if (gname === "laugh") this.blink = Math.max(this.blink, 0.55);
    const wt = (now - this.winkStart) / 600;
    const wink = wt >= 0 && wt <= 1 ? Math.sin(wt * Math.PI) : 0;

    const Lk = this.look;
    if (now > Lk.next) {
      const thinking = gname === "think";
      const ox = Lk.tx;
      const oy = Lk.ty;
      if (thinking) {
        Lk.tx = 0.65;
        Lk.ty = -0.65;
      } else if (this.speaking) {
        if (Math.random() < 0.72) {
          Lk.tx = 0;
          Lk.ty = 0;
        } else {
          Lk.tx = (Math.random() - 0.5) * 0.72;
          Lk.ty = (Math.random() - 0.58) * 0.36;
        }
      } else {
        Lk.tx = (Math.random() - 0.5) * 0.85;
        Lk.ty = (Math.random() - 0.5) * 0.4;
        if (Math.random() < 0.48) {
          Lk.tx = 0;
          Lk.ty = 0;
        }
      }
      if (
        Math.hypot(Lk.tx - ox, Lk.ty - oy) > 0.45 &&
        Math.random() < 0.4 &&
        now - this.blinkStart > 550
      ) {
        this.blinkStart = now;
      }
      Lk.next = now + 700 + Math.random() * 2300;
    }
    if (now > Lk.mnext) {
      // Crisp physiologic ocular micro-saccades
      Lk.mx = (Math.random() - 0.5) * 0.16;
      Lk.my = (Math.random() - 0.5) * 0.11;
      Lk.mnext = now + 180 + Math.random() * 380;
    }
    let tx = Lk.tx + Lk.mx;
    let ty = Lk.ty + Lk.my;
    if (now < this.follow.until && gname !== "think") {
      tx = this.follow.x;
      ty = this.follow.y * 0.8;
    }
    if (gname === "dua") {
      tx = 0;
      ty = 0.55;
    }
    Lk.x = lerp(Lk.x, tx, smooth(0.35, dt));
    Lk.y = lerp(Lk.y, ty, smooth(0.35, dt));

    const lidBase =
      clamp(Lk.y * 0.28, 0, 0.3) +
      Math.max(0, this.smile - 0.55) * 0.35 +
      (gname === "dua" ? 0.28 : 0) -
      this.brow * 0.05;
    this.blinkL = Math.max(this.blink, lidBase);
    this.blinkR = Math.max(this.blink, wink, lidBase);
  }

  private _computeChoreography(now: number): {
    body: { rot: number; tx: number; ty: number; sc: number; sy: number };
    limbs: LimbPose;
  } {
    const t = now / 1000;
    const d = this.body ? this.H * 0.05 : this.face?.d || 80;
    const r = this.body ? 0.45 : 1;
    const breath = Math.sin(t * 1.55);
    const sway = Math.sin(t * 0.52);
    const weightShift = Math.sin(t * 0.65);
    const armAmp = 0.048; // Continuous organic arm sway

    let rot =
      (sway * 0.007 +
        Math.sin(t * 0.23 + 1.3) * 0.005 +
        Math.sin(t * 1.13) * 0.002) *
      r;
    let tx = (weightShift * 0.022 + Math.sin(t * 0.21 + 2) * 0.008) * d;
    let ty = breath * d * 0.016;
    let sc = 1 + breath * 0.009;
    let sy = 1 + breath * 0.004;

    const limbs: LimbPose = {
      ...ZERO_LIMB,
      // Natural shoulder & elbow counter-sway + breath rise
      lArmRot: breath * armAmp + weightShift * 0.028 + 0.022,
      rArmRot: -breath * armAmp + weightShift * 0.028 - 0.022,
      lElbowRot: Math.sin(t * 1.55 + 0.7) * 0.078 - 0.03,
      rElbowRot: -Math.sin(t * 1.55 + 0.7) * 0.078 + 0.03,
      lArmTy: -breath * d * 0.03,
      rArmTy: -breath * d * 0.03,
      // Subtle grounded weight-shift & toddler balance in feet/hips
      lLegTx: weightShift * d * 0.032,
      rLegTx: weightShift * d * 0.032,
      lLegTy: Math.max(0, Math.sin(t * 0.65)) * -d * 0.034,
      rLegTy: Math.max(0, -Math.sin(t * 0.65)) * -d * 0.034,
      lLegRot: weightShift * 0.022,
      rLegRot: weightShift * 0.022,
      // Natural neck/head curiosity & torso posture
      headRot: Math.sin(t * 0.85) * 0.04 + Math.cos(t * 0.43) * 0.022,
      headTx: Math.sin(t * 0.52) * d * 0.022,
      headTy: breath * d * 0.04,
      torsoRot: weightShift * 0.018,
      torsoSy: 1 + breath * 0.016,
    };

    // Attentive listening mode: leans gently forward, curious tilt & subtle micro-nods
    if (this.listening && !this.speaking && !this.gesture) {
      const nodPulse = Math.max(0, Math.sin(t * 2.2)) * 0.025;
      sc += 0.016;
      limbs.headRot += 0.055 + Math.sin(t * 1.4) * 0.02;
      limbs.headTy += nodPulse * d * 0.9;
      limbs.torsoRot += 0.012;
      limbs.lElbowRot -= 0.065;
      limbs.rElbowRot += 0.065;
      limbs.lArmTy -= d * 0.03;
      limbs.rArmTy -= d * 0.03;
    }

    // Conversational natural hand, elbow, shoulder, torso & foot balance when speaking
    if (this.speaking) {
      const energy = clamp(this.audioEnergy * 2.4, 0.28, 1);
      const talkBeat = Math.sin(t * 3.4);
      const talkOpp = Math.cos(t * 3.1);
      rot += Math.sin(t * 2.1) * 0.01 * r;
      ty += this.emph * d * 0.048;
      sc += 0.014 * energy;
      limbs.headRot += this.tilt * 0.072 + talkBeat * 0.045 * energy;
      limbs.headTy += Math.sin(t * 4.6) * d * 0.042 * energy;
      limbs.headTx += talkOpp * d * 0.024 * energy;
      limbs.torsoRot += talkBeat * 0.025 * energy;
      limbs.lArmRot += (0.14 + Math.sin(t * 3.8) * 0.16) * energy;
      limbs.rArmRot -= (0.14 + Math.cos(t * 3.4) * 0.16) * energy;
      limbs.lElbowRot += (0.24 + Math.sin(t * 4.2 + 0.5) * 0.24) * energy;
      limbs.rElbowRot -= (0.24 + Math.cos(t * 3.9 + 0.5) * 0.24) * energy;
      limbs.lArmTx += d * 0.03 * energy;
      limbs.rArmTx -= d * 0.03 * energy;
      limbs.lArmTy -= d * (0.06 + Math.abs(talkBeat) * 0.04) * energy;
      limbs.rArmTy -= d * (0.06 + Math.abs(talkOpp) * 0.04) * energy;
      limbs.lLegTx += talkBeat * d * 0.03 * energy;
      limbs.rLegTx += talkBeat * d * 0.03 * energy;
    }

    const g = this.gesture;
    if (g) {
      const p = clamp((now - g.start) / g.dur, 0, 1);
      const env = Math.sin(Math.PI * p);
      const el = (now - g.start) / 1000;
      const B = this.body ? 1 : 0.3;

      switch (g.name) {
        case "nod":
          limbs.headTy += Math.sin(p * Math.PI * 6) * d * 0.18 * env;
          limbs.headRot += Math.sin(p * Math.PI * 6) * 0.065 * env;
          limbs.torsoRot += Math.sin(p * Math.PI * 6) * 0.015 * env;
          break;

        case "shake":
          limbs.headTx += Math.sin(p * Math.PI * 7) * d * 0.18 * env;
          limbs.headRot += Math.sin(p * Math.PI * 7) * 0.11 * env;
          break;

        case "wave":
          // Cheerful full-body wave: shoulder + forearm + joyful hip bounce
          limbs.rArmRot = -0.92 * env;
          limbs.rElbowRot = -0.62 * env + Math.sin(el * 11.5) * 0.48 * env;
          limbs.rArmTy = -d * 0.16 * env;
          limbs.lArmRot = (0.18 + Math.sin(el * 5) * 0.06) * env;
          limbs.lElbowRot = -0.14 * env;
          limbs.headRot += 0.08 * env + Math.sin(el * 5) * 0.04 * env;
          limbs.torsoRot += Math.sin(el * 5) * 0.028 * env;
          limbs.rLegTy -= Math.max(0, Math.sin(el * 5.5)) * d * 0.12 * env;
          rot += Math.sin(p * Math.PI * 8) * 0.022 * env * r;
          break;

        case "dua":
          // Both upper arms rise & elbows fold hands gracefully while gently bowing head
          limbs.lArmRot = -0.38 * env;
          limbs.rArmRot = 0.38 * env;
          limbs.lElbowRot = -0.84 * env;
          limbs.rElbowRot = 0.84 * env;
          limbs.lArmTx = d * 0.24 * env;
          limbs.rArmTx = -d * 0.24 * env;
          limbs.lArmTy = -d * 0.24 * env;
          limbs.rArmTy = -d * 0.24 * env;
          limbs.headRot = 0.045 * env;
          limbs.headTy += d * 0.11 * env;
          limbs.torsoSy += 0.018 * env;
          break;

        case "hug":
          sc += 0.18 * env;
          limbs.lArmRot = p < 0.42 ? 0.58 * env : -0.38 * env;
          limbs.rArmRot = p < 0.42 ? -0.58 * env : 0.38 * env;
          limbs.lElbowRot = p < 0.42 ? 0.32 * env : -0.64 * env;
          limbs.rElbowRot = p < 0.42 ? -0.32 * env : 0.64 * env;
          limbs.lArmTx = p < 0.42 ? -d * 0.12 * env : d * 0.36 * env;
          limbs.rArmTx = p < 0.42 ? d * 0.12 * env : -d * 0.36 * env;
          limbs.lArmTy = -d * 0.18 * env;
          limbs.rArmTy = -d * 0.18 * env;
          limbs.torsoRot = Math.sin(el * 3.5) * 0.03 * env;
          limbs.headRot = Math.sin(el * 3.5) * 0.07 * env;
          break;

        case "clap": {
          const beat = Math.abs(Math.sin(el * Math.PI * 3.8));
          limbs.lArmRot = -0.28 * env;
          limbs.rArmRot = 0.28 * env;
          limbs.lElbowRot = (-0.52 - beat * 0.56) * env;
          limbs.rElbowRot = (0.52 + beat * 0.56) * env;
          limbs.lArmTx = d * (0.24 + beat * 0.32) * env;
          limbs.rArmTx = -d * (0.24 + beat * 0.32) * env;
          limbs.lArmTy = -d * 0.2 * env;
          limbs.rArmTy = -d * 0.2 * env;
          limbs.lLegTy = -beat * d * 0.14 * env;
          limbs.rLegTy = -beat * d * 0.14 * env;
          ty -= beat * d * 0.14 * env;
          limbs.headTy -= beat * d * 0.08 * env;
          break;
        }

        case "walk": {
          const walking = p < 0.82;
          const ph = el * Math.PI * 4.6;
          const w = walking ? ease(Math.min(1, p / 0.1)) : 0;
          const swing = Math.sin(ph);
          const lLift = Math.max(0, -swing);
          const rLift = Math.max(0, swing);
          limbs.lLegTy = -lLift * d * 0.64 * w;
          limbs.rLegTy = -rLift * d * 0.64 * w;
          limbs.lLegTx = -swing * d * 0.22 * w;
          limbs.rLegTx = swing * d * 0.22 * w;
          limbs.lLegRot = -swing * 0.17 * w;
          limbs.rLegRot = swing * 0.17 * w;
          limbs.lLegSc = 1 + -swing * 0.095 * w;
          limbs.rLegSc = 1 + swing * 0.095 * w;
          limbs.lArmRot = swing * 0.34 * w;
          limbs.rArmRot = -swing * 0.34 * w;
          limbs.lElbowRot = Math.max(0, -swing) * 0.4 * w;
          limbs.rElbowRot = -Math.max(0, swing) * 0.4 * w;
          limbs.headRot += swing * 0.025 * w;
          limbs.torsoRot = swing * 0.042 * w;
          ty -= Math.abs(swing) * d * 0.16 * w * B;
          tx += Math.cos(ph) * d * 0.12 * w;
          const approach =
            p < 0.75 ? ease(p / 0.75) : p < 0.88 ? 1 : 1 - ease((p - 0.88) / 0.12);
          sc += 0.18 * approach;
          ty += approach * d * 0.16 * B;
          break;
        }

        case "run": {
          const ph = el * Math.PI * 8.2;
          const on = p < 0.06 ? p / 0.06 : p > 0.88 ? (1 - p) / 0.12 : 1;
          const swing = Math.sin(ph);
          const flight = Math.abs(swing);
          const lLift = Math.max(0, -swing);
          const rLift = Math.max(0, swing);
          limbs.lLegTy = -lLift * d * 0.94 * on;
          limbs.rLegTy = -rLift * d * 0.94 * on;
          limbs.lLegTx = -swing * d * 0.38 * on;
          limbs.rLegTx = swing * d * 0.38 * on;
          limbs.lLegRot = -swing * 0.28 * on;
          limbs.rLegRot = swing * 0.28 * on;
          limbs.lLegSc = 1 + -swing * 0.14 * on;
          limbs.rLegSc = 1 + swing * 0.14 * on;
          limbs.lArmRot = (swing * 0.58 + 0.16) * on;
          limbs.rArmRot = (-swing * 0.58 - 0.16) * on;
          limbs.lElbowRot = (-0.48 + swing * 0.36) * on;
          limbs.rElbowRot = (0.48 + swing * 0.36) * on;
          limbs.lArmTy = -d * 0.14 * on;
          limbs.rArmTy = -d * 0.14 * on;
          limbs.torsoRot = swing * 0.056 * on;
          limbs.headRot = swing * 0.035 * on;
          ty -= flight * d * 0.6 * on * B;
          sy += (flight < 0.15 ? -0.05 : 0.03) * on;
          rot += (swing * 0.026 + 0.01) * on * r;
          const travel = Math.sin(p * Math.PI * 2);
          tx += travel * d * (this.body ? 1.85 : 0.85) * on;
          limbs.bgShiftX = -travel * d * 0.5 * on;
          sc += Math.sin(p * Math.PI) * 0.14 * on;
          break;
        }

        case "jump": {
          const ph = (el / 1.35) % 1;
          const H = d * (this.body ? 2.35 : 0.48);
          if (ph < 0.28) {
            const k = ease(ph / 0.28);
            ty += k * d * 0.2 * B;
            sy -= k * 0.08;
            limbs.lArmRot = -0.26 * k;
            limbs.rArmRot = 0.26 * k;
            limbs.lElbowRot = -0.34 * k;
            limbs.rElbowRot = 0.34 * k;
          } else if (ph < 0.84) {
            const k = (ph - 0.28) / 0.56;
            const air = 4 * k * (1 - k);
            ty -= H * air;
            sy += 0.045 * air;
            limbs.lArmRot = 0.92 * air;
            limbs.rArmRot = -0.92 * air;
            limbs.lElbowRot = 0.45 * air;
            limbs.rElbowRot = -0.45 * air;
            limbs.lLegTy = -d * 0.74 * air;
            limbs.rLegTy = -d * 0.74 * air;
            limbs.lLegRot = 0.22 * air;
            limbs.rLegRot = -0.22 * air;
            limbs.headRot = -0.04 * air;
          } else {
            const k = (ph - 0.84) / 0.16;
            const sq = Math.sin(k * Math.PI);
            sy -= 0.09 * sq;
            ty += sq * d * 0.14 * B;
          }
          break;
        }

        case "play": {
          const beat = el * 4.0;
          const kickPhase = el % 1.4;
          const kicking = kickPhase > 0.7 && kickPhase < 1.1;
          const kickAmt = kicking ? Math.sin(((kickPhase - 0.7) / 0.4) * Math.PI) : 0;
          limbs.lArmRot = (Math.sin(beat) * 0.44 + 0.22) * env;
          limbs.rArmRot = (-Math.sin(beat) * 0.44 - 0.22) * env;
          limbs.lElbowRot = Math.cos(beat) * 0.42 * env;
          limbs.rElbowRot = -Math.cos(beat) * 0.42 * env;
          limbs.rLegTy = -kickAmt * d * 0.82 * env;
          limbs.rLegTx = -kickAmt * d * 0.28 * env;
          limbs.rLegRot = -kickAmt * 0.32 * env;
          limbs.rLegSc = 1 + kickAmt * 0.15 * env;
          limbs.lLegTy = -Math.max(0, Math.cos(beat)) * d * 0.36 * env;
          limbs.torsoRot = Math.sin(beat) * 0.05 * env;
          limbs.headRot = Math.sin(beat * 0.5) * 0.06 * env;
          ty -= Math.abs(Math.sin(beat)) * d * 0.24 * env * B;
          tx += Math.sin(el * 1.5) * d * 0.65 * env;
          rot += Math.sin(beat * 0.5) * 0.035 * env * r;
          break;
        }

        case "dance": {
          const beat = el / 0.32;
          const s = Math.sin(beat * Math.PI);
          limbs.lArmRot = (0.5 + s * 0.42) * env;
          limbs.rArmRot = (-0.5 + s * 0.42) * env;
          limbs.lElbowRot = (0.4 + Math.cos(beat * Math.PI) * 0.4) * env;
          limbs.rElbowRot = (-0.4 + Math.cos(beat * Math.PI) * 0.4) * env;
          limbs.lArmTy = -d * 0.18 * env;
          limbs.rArmTy = -d * 0.18 * env;
          limbs.lLegTy = -Math.max(0, s) * d * 0.5 * env;
          limbs.rLegTy = -Math.max(0, -s) * d * 0.5 * env;
          limbs.lLegRot = s * 0.12 * env;
          limbs.rLegRot = -s * 0.12 * env;
          limbs.torsoRot = s * 0.058 * env;
          limbs.headRot = s * 0.095 * env;
          rot += s * 0.065 * env * r;
          tx += s * d * 0.26 * env;
          ty -= Math.abs(s) * d * 0.28 * env;
          break;
        }

        case "stethoscope":
          sc += 0.055 * env;
          limbs.rArmRot = 0.26 * env;
          limbs.rElbowRot = 0.74 * env;
          limbs.rArmTx = -d * 0.26 * env;
          limbs.rArmTy = -d * 0.22 * env;
          limbs.lArmRot = -0.14 * env;
          limbs.headRot = 0.065 * env;
          limbs.torsoRot = 0.022 * env;
          break;

        case "think":
          limbs.headRot = 0.11 * env;
          limbs.rArmRot = 0.28 * env;
          limbs.rElbowRot = 0.78 * env;
          limbs.rArmTx = -d * 0.24 * env;
          limbs.rArmTy = -d * 0.36 * env;
          limbs.lArmRot = -0.1 * env;
          break;

        case "laugh":
          ty += Math.abs(Math.sin(p * Math.PI * 14)) * d * 0.055 * env;
          limbs.headRot = -0.06 * env + Math.sin(el * 18) * 0.032 * env;
          limbs.lArmRot = Math.abs(Math.sin(el * 12)) * 0.25 * env;
          limbs.rArmRot = -Math.abs(Math.sin(el * 12)) * 0.25 * env;
          limbs.lElbowRot = Math.abs(Math.sin(el * 12)) * 0.3 * env;
          limbs.rElbowRot = -Math.abs(Math.sin(el * 12)) * 0.3 * env;
          limbs.torsoRot = Math.sin(el * 14) * 0.025 * env;
          break;

        case "surprise": {
          const k = p < 0.15 ? ease(p / 0.15) : 1 - ease((p - 0.15) / 0.85);
          ty -= k * d * 0.28 * B;
          sy += 0.035 * k;
          limbs.lArmRot = 0.48 * k;
          limbs.rArmRot = -0.48 * k;
          limbs.lElbowRot = 0.4 * k;
          limbs.rElbowRot = -0.4 * k;
          break;
        }

        case "sad":
          ty += d * 0.06 * env;
          limbs.headRot = -0.065 * env;
          limbs.headTy = d * 0.095 * env;
          limbs.torsoRot = -0.02 * env;
          break;

        case "heart":
        case "smile":
          sc += 0.028 * env;
          limbs.headRot = 0.055 * env;
          limbs.lArmRot = -0.18 * env;
          limbs.rArmRot = 0.18 * env;
          limbs.lElbowRot = -0.26 * env;
          limbs.rElbowRot = 0.26 * env;
          limbs.torsoRot = Math.sin(el * 3) * 0.02 * env;
          break;

        case "wink":
          limbs.headRot = 0.075 * env;
          limbs.rArmRot = 0.12 * env;
          break;
      }
    }

    return { body: { rot, tx, ty, sc, sy }, limbs };
  }

  private _draw(now: number, dt: number) {
    const { ctx, canvas, view, img, face } = this;
    if (!img || !view || !face) return;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.globalAlpha = 1;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(this.bg, 0, 0, canvas.width, canvas.height);

    // Subtle warm golden/crimson aura during dua, hug, or heart
    if (
      this.gesture &&
      (this.gesture.name === "dua" ||
        this.gesture.name === "heart" ||
        this.gesture.name === "hug")
    ) {
      const p = clamp((now - this.gesture.start) / this.gesture.dur, 0, 1);
      const aura = Math.sin(Math.PI * p) * 0.26;
      const cx = view.x + face.M.x * view.s;
      const cy = view.y + face.M.y * view.s;
      const rad = Math.max(canvas.width, canvas.height) * 0.48;
      const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, rad);
      g.addColorStop(
        0,
        this.gesture.name === "dua"
          ? `rgba(232,184,109,${aura})`
          : `rgba(230,72,61,${aura})`
      );
      g.addColorStop(1, "rgba(0,0,0,0)");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    const { body: target, limbs: targetLimbs } = this._computeChoreography(now);
    const T = this.T;
    const k = smooth(0.32, dt);
    const kf = smooth(0.6, dt);
    T.rot = lerp(T.rot, target.rot, k);
    T.tx = lerp(T.tx, target.tx, k);
    T.sc = lerp(T.sc, target.sc, k);
    T.ty = lerp(T.ty, target.ty, kf);
    T.sy = lerp(T.sy, target.sy, kf);

    // Smoothly interpolate all articulated limbs
    const L = this.L;
    const kl = smooth(0.36, dt);
    L.lArmRot = lerp(L.lArmRot, targetLimbs.lArmRot, kl);
    L.rArmRot = lerp(L.rArmRot, targetLimbs.rArmRot, kl);
    L.lElbowRot = lerp(L.lElbowRot, targetLimbs.lElbowRot, kl);
    L.rElbowRot = lerp(L.rElbowRot, targetLimbs.rElbowRot, kl);
    L.lArmTx = lerp(L.lArmTx, targetLimbs.lArmTx, kl);
    L.rArmTx = lerp(L.rArmTx, targetLimbs.rArmTx, kl);
    L.lArmTy = lerp(L.lArmTy, targetLimbs.lArmTy, kl);
    L.rArmTy = lerp(L.rArmTy, targetLimbs.rArmTy, kl);
    L.lLegTy = lerp(L.lLegTy, targetLimbs.lLegTy, kf);
    L.rLegTy = lerp(L.rLegTy, targetLimbs.rLegTy, kf);
    L.lLegTx = lerp(L.lLegTx, targetLimbs.lLegTx, kf);
    L.rLegTx = lerp(L.rLegTx, targetLimbs.rLegTx, kf);
    L.lLegRot = lerp(L.lLegRot, targetLimbs.lLegRot, kf);
    L.rLegRot = lerp(L.rLegRot, targetLimbs.rLegRot, kf);
    L.lLegSc = lerp(L.lLegSc, targetLimbs.lLegSc, kf);
    L.rLegSc = lerp(L.rLegSc, targetLimbs.rLegSc, kf);
    L.headRot = lerp(L.headRot, targetLimbs.headRot, kl);
    L.headTx = lerp(L.headTx, targetLimbs.headTx, kl);
    L.headTy = lerp(L.headTy, targetLimbs.headTy, kl);
    L.torsoRot = lerp(L.torsoRot, targetLimbs.torsoRot, kl);
    L.torsoSy = lerp(L.torsoSy, targetLimbs.torsoSy, kl);
    L.bgShiftX = lerp(L.bgShiftX, targetLimbs.bgShiftX, kl);

    const pv = this.pivot;
    ctx.save();
    ctx.translate(view.x, view.y);
    ctx.scale(view.s, view.s);

    if (this.puppet) {
      const P = this.puppet;

      // 1. Grounded clean background plate with subtle stride parallax
      ctx.save();
      ctx.translate(L.bgShiftX, 0);
      ctx.drawImage(P.baseClean, 0, 0, this.W, this.H);
      ctx.restore();

      // Dynamic per-foot floor shadows on marble floor
      const drawFootShadow = (hipX: number, footTx: number, footTy: number) => {
        const lift = clamp((-T.ty - footTy) / (this.H * 0.1), 0, 1);
        const sx = hipX + T.tx + footTx;
        const sy0 = this.H * 0.92;
        const rw = this.W * 0.11 * T.sc * (1 - lift * 0.45);
        ctx.save();
        ctx.globalAlpha = 0.34 * (1 - lift * 0.65);
        const grd = ctx.createRadialGradient(sx, sy0, 0, sx, sy0, rw);
        grd.addColorStop(0, "rgba(0,0,0,0.85)");
        grd.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = grd;
        ctx.beginPath();
        ctx.ellipse(sx, sy0, rw, rw * 0.24, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      };
      drawFootShadow(P.lHip.x, L.lLegTx, L.lLegTy);
      drawFootShadow(P.rHip.x, L.rLegTx, L.rLegTy);

      // Apply whole-body jump / approach transform
      ctx.translate(pv.x + T.tx, pv.y + T.ty);
      ctx.rotate(T.rot);
      ctx.scale(T.sc, T.sc * T.sy);
      ctx.translate(-pv.x, -pv.y);

      // 2. Articulated Left & Right Shoes/Legs drawn UNDER her red coat hem so feet kick cleanly!
      ctx.save();
      ctx.translate(P.lHip.x + L.lLegTx, P.lHip.y + L.lLegTy);
      ctx.rotate(L.lLegRot);
      ctx.scale(L.lLegSc, L.lLegSc);
      ctx.translate(-P.lHip.x, -P.lHip.y);
      ctx.drawImage(P.leftLeg, 0, 0, this.W, this.H);
      ctx.restore();

      ctx.save();
      ctx.translate(P.rHip.x + L.rLegTx, P.rHip.y + L.rLegTy);
      ctx.rotate(L.rLegRot);
      ctx.scale(L.rLegSc, L.rLegSc);
      ctx.translate(-P.rHip.x, -P.rHip.y);
      ctx.drawImage(P.rightLeg, 0, 0, this.W, this.H);
      ctx.restore();

      // 3. Torso / Coat skirt breathing & subtle sway over upper legs
      ctx.save();
      ctx.translate(P.torsoPivot.x, P.torsoPivot.y);
      ctx.rotate(L.torsoRot);
      ctx.scale(1, L.torsoSy);
      ctx.translate(-P.torsoPivot.x, -P.torsoPivot.y);
      ctx.drawImage(P.torso, 0, 0, this.W, this.H);
      ctx.restore();

      // 4. Two-Joint Left Arm (Shoulder -> Elbow -> Hand)
      ctx.save();
      ctx.translate(P.lShoulder.x + L.lArmTx, P.lShoulder.y + L.lArmTy);
      ctx.rotate(L.lArmRot);
      ctx.translate(-P.lShoulder.x, -P.lShoulder.y);
      ctx.drawImage(P.leftUpperArm, 0, 0, this.W, this.H);
      ctx.save();
      ctx.translate(P.lElbow.x, P.lElbow.y);
      ctx.rotate(L.lElbowRot);
      ctx.translate(-P.lElbow.x, -P.lElbow.y);
      ctx.drawImage(P.leftForearm, 0, 0, this.W, this.H);
      ctx.restore();
      ctx.restore();

      // 5. Two-Joint Right Arm (Shoulder -> Elbow -> Hand)
      ctx.save();
      ctx.translate(P.rShoulder.x + L.rArmTx, P.rShoulder.y + L.rArmTy);
      ctx.rotate(L.rArmRot);
      ctx.translate(-P.rShoulder.x, -P.rShoulder.y);
      ctx.drawImage(P.rightUpperArm, 0, 0, this.W, this.H);
      ctx.save();
      ctx.translate(P.rElbow.x, P.rElbow.y);
      ctx.rotate(L.rElbowRot);
      ctx.translate(-P.rElbow.x, -P.rElbow.y);
      ctx.drawImage(P.rightForearm, 0, 0, this.W, this.H);
      ctx.restore();
      ctx.restore();

      // 6. Articulated Head + Face features pivoted at neck
      ctx.save();
      ctx.translate(P.headPivot.x + L.headTx, P.headPivot.y + L.headTy);
      ctx.rotate(L.headRot);
      ctx.translate(-P.headPivot.x, -P.headPivot.y);
      ctx.drawImage(P.head, 0, 0, this.W, this.H);
      this._drawBrows(img, face);
      this._drawEyes(img, face);
      this._drawCheeks(face);
      this._drawMouth(img, face);
      ctx.restore();
    } else {
      ctx.translate(pv.x + T.tx, pv.y + T.ty);
      ctx.rotate(T.rot);
      ctx.scale(T.sc, T.sc * T.sy);
      ctx.translate(-pv.x, -pv.y);
      ctx.drawImage(img, 0, 0, this.W, this.H);
      this._drawBrows(img, face);
      this._drawEyes(img, face);
      this._drawCheeks(face);
      this._drawMouth(img, face);
    }

    ctx.restore();
    ctx.globalAlpha = 1;
  }

  private _drawCheeks(face: ComputedFace) {
    const blush = clamp((this.smile - 0.3) * 0.16, 0, 0.14);
    if (blush <= 0.01) return;
    const { ctx } = this;
    const d = face.d;
    const spots = [
      { x: face.L.x - d * 0.12, y: face.L.y + d * 0.36 },
      { x: face.R.x + d * 0.12, y: face.R.y + d * 0.36 },
    ];
    for (const s of spots) {
      const r = d * 0.24;
      const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, r);
      g.addColorStop(0, `rgba(240,108,118,${blush})`);
      g.addColorStop(1, "rgba(240,108,118,0)");
      ctx.fillStyle = g;
      ctx.beginPath();
      ctx.ellipse(s.x, s.y, r, r * 0.72, 0, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  private _softPatch(
    src: HTMLImageElement,
    sx: number,
    sy: number,
    sw: number,
    sh: number,
    dx: number,
    dy: number,
    dw: number,
    dh: number,
    cx = 0.5,
    cy = 0.5,
    inner = 0.55
  ) {
    const p = this.patch;
    const pc = this.patchCtx;
    const w = Math.max(2, Math.ceil(sw));
    const h = Math.max(2, Math.ceil(sh));
    if (p.width < w || p.height < h) {
      p.width = Math.max(p.width, w);
      p.height = Math.max(p.height, h);
    }
    pc.globalCompositeOperation = "source-over";
    pc.clearRect(0, 0, p.width, p.height);
    pc.drawImage(src, sx, sy, sw, sh, 0, 0, w, h);
    pc.globalCompositeOperation = "destination-in";
    pc.save();
    pc.translate(w * cx, h * cy);
    pc.scale(w / 2, h / 2);
    const grad = pc.createRadialGradient(0, 0, 0, 0, 0, 1);
    grad.addColorStop(0, "rgba(0,0,0,1)");
    grad.addColorStop(inner, "rgba(0,0,0,1)");
    grad.addColorStop(1, "rgba(0,0,0,0)");
    pc.fillStyle = grad;
    pc.fillRect(-4, -4, 8, 8);
    pc.restore();
    this.ctx.drawImage(p, 0, 0, w, h, dx, dy, dw, dh);
  }

  private _drawBrows(img: HTMLImageElement, face: ComputedFace) {
    if (this.brow < 0.03) return;
    const d = face.d;
    const es = face.eyeScale;
    const ew = d * 0.46 * es;
    const eh = d * 0.26 * es;
    const lift = d * 0.048 * this.brow;
    for (const E of [face.L, face.R]) {
      const sw = ew * 1.5;
      const sh = eh * 1.5;
      const sx = E.x - sw / 2;
      const sy = E.y - eh * 0.75 - sh;
      this._softPatch(img, sx, sy, sw, sh, sx, sy - lift, sw, sh, 0.5, 0.55, 0.35);
    }
  }

  private _drawEyes(img: HTMLImageElement, face: ComputedFace) {
    const { ctx } = this;
    const d = face.d;
    const es = face.eyeScale;
    const ew = d * 0.46 * es;
    const eh = d * 0.26 * es;
    const squint =
      Math.max(0, this.smile - 0.4) * 0.6 + (this.gesture?.name === "laugh" ? 0.3 : 0);

    [face.L, face.R].forEach((E, i) => {
      const gx = this.look.x * d * 0.042;
      const gy = this.look.y * d * 0.022;
      if (Math.abs(gx) + Math.abs(gy) > 0.2 * (d / 100)) {
        const sw = ew * 0.82;
        const sh = eh * 0.82;
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(E.x, E.y, ew * 0.48, eh * 0.5, 0, 0, Math.PI * 2);
        ctx.clip();
        this._softPatch(
          img,
          E.x - sw / 2,
          E.y - sh / 2,
          sw,
          sh,
          E.x - sw / 2 + gx,
          E.y - sh / 2 + gy,
          sw,
          sh,
          0.5,
          0.5,
          0.35
        );
        ctx.restore();
      }
      // Specular dual-dot catchlight + subtle expressive brightness when speaking/listening
      const bCur = i === 0 ? this.blinkL : this.blinkR;
      if (bCur < 0.45) {
        const spark = this.speaking || this.listening ? 0.52 : 0.4;
        ctx.save();
        ctx.fillStyle = `rgba(255,252,245,${spark})`;
        ctx.beginPath();
        ctx.arc(
          E.x - d * 0.032 + gx * 0.95,
          E.y - d * 0.028 + gy * 0.95,
          Math.max(1.3, d * 0.019),
          0,
          Math.PI * 2
        );
        ctx.fill();
        ctx.fillStyle = `rgba(255,252,245,${spark * 0.55})`;
        ctx.beginPath();
        ctx.arc(
          E.x + d * 0.024 + gx * 0.95,
          E.y + d * 0.018 + gy * 0.95,
          Math.max(0.8, d * 0.01),
          0,
          Math.PI * 2
        );
        ctx.fill();
        ctx.restore();
      }
      if (squint > 0.03) {
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(E.x, E.y, ew / 2, eh / 2, 0, 0, Math.PI * 2);
        ctx.clip();
        const bot = E.y + eh / 2;
        const top = bot - eh * 0.28 * squint;
        const g2 = ctx.createLinearGradient(0, top, 0, bot);
        g2.addColorStop(0, "rgba(0,0,0,0)");
        g2.addColorStop(0.35, face.lidColor[i]);
        g2.addColorStop(1, face.lidColor[i]);
        ctx.globalAlpha *= 0.85;
        ctx.fillStyle = g2;
        ctx.fillRect(E.x - ew, top - eh * 0.1, ew * 2, bot - top + eh * 0.2);
        ctx.restore();
      }
      const b = i === 0 ? this.blinkL : this.blinkR;
      if (b > 0.02) {
        ctx.save();
        ctx.beginPath();
        ctx.ellipse(E.x, E.y, ew / 2, eh / 2, 0, 0, Math.PI * 2);
        ctx.clip();
        const top = E.y - eh / 2;
        const lidY = top + eh * b;
        const grad = ctx.createLinearGradient(0, top, 0, lidY);
        grad.addColorStop(0, face.lidColor[i]);
        grad.addColorStop(1, shade(face.lidColor[i], -18));
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(E.x - ew, top - 2);
        ctx.lineTo(E.x + ew, top - 2);
        ctx.lineTo(E.x + ew, lidY);
        ctx.quadraticCurveTo(E.x, lidY + eh * 0.18 * b, E.x - ew, lidY);
        ctx.closePath();
        ctx.fill();
        ctx.strokeStyle = "rgba(40,22,18,0.85)";
        ctx.lineWidth = Math.max(0.8, d * 0.014);
        ctx.beginPath();
        ctx.moveTo(E.x - ew / 2, lidY - eh * 0.05);
        ctx.quadraticCurveTo(E.x, lidY + eh * 0.18 * b, E.x + ew / 2, lidY - eh * 0.05);
        ctx.stroke();
        ctx.restore();
      }
    });
  }

  private _drawMouth(img: HTMLImageElement, face: ComputedFace) {
    const { ctx } = this;
    const { M, d } = face;
    const ms = face.mouthScale;
    const open = this.mouthOpen;
    const smile = this.smile;
    const wide = this.mouthWide;
    const shapeK = this.speaking || open > 0.05 ? (wide - 0.5) * 0.16 : 0;

    // Co-articulated upper lip flare & mouth corner pull for rounded 'O'/'U' and wide 'E'/'A' visemes
    const roundPucker = Math.max(0, 0.45 - wide) * (0.4 + open * 0.8);
    if (Math.abs(smile) > 0.03 || Math.abs(shapeK) > 0.01 || roundPucker > 0.02) {
      const sw = d * 0.95 * ms;
      const sh = d * 0.5 * ms;
      const k = smile * 0.075 + shapeK - roundPucker * 0.14;
      const dw = sw * (1 + k);
      const dh = sh * (1 - Math.max(0, k) * 0.3 + Math.max(0, -shapeK) * 0.28 + roundPucker * 0.16);
      const upperLift = d * 0.02 * smile + d * 0.028 * open * (1 - roundPucker);
      this._softPatch(
        img,
        M.x - sw / 2,
        M.y - sh / 2,
        sw,
        sh,
        M.x - dw / 2,
        M.y - dh / 2 - upperLift,
        dw,
        dh,
        0.5,
        0.5,
        0.3
      );
    }

    if (open > 0.02) {
      const gap = d * 0.135 * open * ms;
      const mw = d * 0.5 * ms * (1 + Math.max(0, smile) * 0.12);
      const rx = mw * 0.36 * (0.62 + 0.7 * wide);
      const ry = gap * 0.62 + 0.3;

      ctx.save();
      ctx.beginPath();
      ctx.ellipse(M.x, M.y + gap * 0.45, rx, ry, 0, 0, Math.PI * 2);
      const g = ctx.createRadialGradient(
        M.x,
        M.y + gap * 0.6,
        0,
        M.x,
        M.y + gap * 0.45,
        Math.max(rx, ry) * 1.1
      );
      g.addColorStop(0, "#a3404a");
      g.addColorStop(0.45, "#5a1c22");
      g.addColorStop(1, "#2a0b0e");
      ctx.fillStyle = g;
      ctx.fill();
      ctx.clip();
      if (open > 0.35 && wide > 0.45) {
        ctx.fillStyle = "rgba(250,245,240,0.58)";
        ctx.beginPath();
        ctx.ellipse(M.x, M.y + gap * 0.45 - ry * 0.75, rx * 0.68, ry * 0.34, 0, 0, Math.PI * 2);
        ctx.fill();
      }
      if (open > 0.55) {
        ctx.fillStyle = "rgba(214,104,118,0.78)";
        ctx.beginPath();
        ctx.ellipse(
          M.x,
          M.y + gap * 0.45 + ry * 0.75,
          rx * 0.6,
          ry * 0.45,
          0,
          0,
          Math.PI * 2
        );
        ctx.fill();
      }
      ctx.restore();

      const jw = d * 1.15 * ms;
      const jh = d * 0.85 * ms;
      this._softPatch(
        img,
        M.x - jw / 2,
        M.y,
        jw,
        jh,
        M.x - jw / 2,
        M.y + gap,
        jw,
        jh,
        0.5,
        0.18,
        0.5
      );
    }
  }
}
