import { float32ToInt16Base64, startMicPcmPipeline, type MicPipelineHandle } from "./audioCapture";
import type { AvatarEngine } from "./avatarEngine";
import { detectCommands } from "./brain";

function base64Int16ToFloat32(base64: string): Float32Array {
  const bin = atob(base64);
  const len = bin.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
  const int16 = new Int16Array(bytes.buffer);
  const out = new Float32Array(int16.length);
  for (let i = 0; i < int16.length; i++) {
    out[i] = int16[i] / 32768;
  }
  return out;
}

export interface LiveCallCallbacks {
  onStatus: (status: "connecting" | "connected" | "ended") => void;
  onInputTranscript: (text: string) => void;
  onOutputTranscript: (text: string) => void;
  onSpeakingChange: (speaking: boolean) => void;
  onError: (msg: string) => void;
}

export class LiveCallClient {
  private ws: WebSocket | null = null;
  private inputCtx: AudioContext | null = null;
  private outputCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private stream: MediaStream | null = null;
  private micHandle: MicPipelineHandle | null = null;
  private videoTimer: ReturnType<typeof setInterval> | null = null;
  private activeSources = new Set<AudioBufferSourceNode>();
  private nextStartTime = 0;
  private rafId = 0;
  private avatar: AvatarEngine | null = null;
  private callbacks: LiveCallCallbacks;
  private outBuffer = "";
  private inBuffer = "";
  private pcmChunkAccumulator: Float32Array[] = [];
  private pcmSampleCount = 0;

  constructor(callbacks: LiveCallCallbacks, avatar: AvatarEngine | null) {
    this.callbacks = callbacks;
    this.avatar = avatar;
  }

  attachAvatar(avatar: AvatarEngine | null) {
    this.avatar = avatar;
  }

  async start(opts: {
    mode: string;
    lang: string;
    voiceName: string;
    name: string;
    coords?: { lat: number; lng: number } | null;
  }) {
    this.callbacks.onStatus("connecting");

    try {
      this.stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
    } catch {
      try {
        this.stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch {
        this.callbacks.onError("Microphone permission is needed for Live Call.");
        this.callbacks.onStatus("ended");
        return;
      }
    }

    const AC =
      window.AudioContext ||
      (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;

    this.inputCtx = new AC({ sampleRate: 16000 });
    this.outputCtx = new AC({ sampleRate: 24000 });
    if (this.inputCtx.state === "suspended") await this.inputCtx.resume().catch(() => {});
    if (this.outputCtx.state === "suspended") await this.outputCtx.resume().catch(() => {});

    this.analyser = this.outputCtx.createAnalyser();
    this.analyser.fftSize = 256;
    this.analyser.connect(this.outputCtx.destination);

    const proto = location.protocol === "https:" ? "wss:" : "ws:";
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Karachi";
    const params = new URLSearchParams({
      mode: opts.mode,
      lang: opts.lang,
      voice: opts.voiceName,
      name: opts.name,
      tz,
    });
    if (opts.coords) {
      params.set("lat", String(opts.coords.lat));
      params.set("lng", String(opts.coords.lng));
    }
    const ws = new WebSocket(`${proto}//${location.host}/ws/live?${params.toString()}`);
    this.ws = ws;

    ws.onopen = () => {
      void this.startMicPump();
      this.startEnergyLoop();
    };

    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === "ready") {
          this.callbacks.onStatus("connected");
          this.avatar?.play("wave");
          ws.send(
            JSON.stringify({
              type: "text",
              text: "Assalam o Alaikum! Say a short warm greeting to start our live call.",
            })
          );
        } else if (msg.type === "audio" && msg.data) {
          this.schedulePcmChunk(msg.data);
        } else if (msg.type === "inputTranscript" && msg.text) {
          this.inBuffer += msg.text;
          this.callbacks.onInputTranscript(this.inBuffer.trim());
          const cmds = detectCommands(msg.text);
          if (cmds.length) this.avatar?.play(cmds[0]);
        } else if (msg.type === "outputTranscript" && msg.text) {
          this.outBuffer += msg.text;
          this.callbacks.onOutputTranscript(this.outBuffer.trim());
          const cmds = detectCommands(msg.text);
          if (cmds.length && !this.avatar?.gesture) this.avatar?.play(cmds[0]);
        } else if (msg.type === "interrupted") {
          this.clearPlayback();
          this.outBuffer = "";
        } else if (msg.type === "turnComplete") {
          this.inBuffer = "";
          this.outBuffer = "";
        } else if (msg.type === "error") {
          this.callbacks.onError(msg.error || "Live call connection error.");
        } else if (msg.type === "closed") {
          this.stop();
        }
      } catch {}
    };

    ws.onerror = () => {
      this.callbacks.onError("Could not connect live voice call.");
      this.stop();
    };

    ws.onclose = () => {
      this.stop();
    };
  }

  private async startMicPump() {
    if (!this.inputCtx || !this.stream || !this.ws) return;
    this.pcmChunkAccumulator = [];
    this.pcmSampleCount = 0;

    this.micHandle = await startMicPcmPipeline(this.inputCtx, this.stream, (pcm16k) => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      this.pcmChunkAccumulator.push(pcm16k);
      this.pcmSampleCount += pcm16k.length;
      // Send ~100ms (1600 samples at 16kHz) packets cleanly
      if (this.pcmSampleCount >= 1600) {
        const merged = new Float32Array(this.pcmSampleCount);
        let offset = 0;
        for (const c of this.pcmChunkAccumulator) {
          merged.set(c, offset);
          offset += c.length;
        }
        this.pcmChunkAccumulator = [];
        this.pcmSampleCount = 0;
        const base64 = float32ToInt16Base64(merged);
        this.ws.send(JSON.stringify({ type: "audio", data: base64 }));
      }
    });
  }

  private schedulePcmChunk(base64: string) {
    if (!this.outputCtx || !this.analyser) return;
    const float32 = base64Int16ToFloat32(base64);
    const buf = this.outputCtx.createBuffer(1, float32.length, 24000);
    buf.getChannelData(0).set(float32);

    const src = this.outputCtx.createBufferSource();
    src.buffer = buf;
    src.connect(this.analyser);

    const now = this.outputCtx.currentTime;
    const startAt = Math.max(now + 0.02, this.nextStartTime);
    this.nextStartTime = startAt + buf.duration;

    this.activeSources.add(src);
    this.callbacks.onSpeakingChange(true);
    this.avatar?.setSpeaking(true);

    src.onended = () => {
      this.activeSources.delete(src);
      if (this.activeSources.size === 0) {
        this.callbacks.onSpeakingChange(false);
        this.avatar?.setSpeaking(false);
        this.avatar?.setAudioEnergy(0);
      }
    };
    src.start(startAt);
  }

  private startEnergyLoop() {
    if (!this.analyser) return;
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    const tick = () => {
      if (!this.analyser) return;
      if (this.activeSources.size > 0) {
        this.analyser.getByteTimeDomainData(data);
        let sum = 0;
        for (let i = 0; i < data.length; i++) {
          const v = (data[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / data.length);
        this.avatar?.setAudioEnergy(rms * 2.5);
      }
      this.rafId = requestAnimationFrame(tick);
    };
    this.rafId = requestAnimationFrame(tick);
  }

  private clearPlayback() {
    for (const src of this.activeSources) {
      try {
        src.stop();
      } catch {}
    }
    this.activeSources.clear();
    this.nextStartTime = 0;
    this.callbacks.onSpeakingChange(false);
    this.avatar?.setSpeaking(false);
    this.avatar?.setAudioEnergy(0);
  }

  attachVideoElement(video: HTMLVideoElement | null) {
    if (this.videoTimer) {
      clearInterval(this.videoTimer);
      this.videoTimer = null;
    }
    if (!video) return;
    const canvas = document.createElement("canvas");
    canvas.width = 480;
    canvas.height = 360;
    const ctx = canvas.getContext("2d");
    this.videoTimer = setInterval(() => {
      if (!this.ws || this.ws.readyState !== WebSocket.OPEN) return;
      if (video.readyState < 2 || !ctx) return;
      ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL("image/jpeg", 0.7);
      const base64 = dataUrl.split(",")[1];
      if (base64) {
        this.ws.send(JSON.stringify({ type: "video", data: base64 }));
      }
    }, 1000);
  }

  stop() {
    if (this.videoTimer) {
      clearInterval(this.videoTimer);
      this.videoTimer = null;
    }
    cancelAnimationFrame(this.rafId);
    this.clearPlayback();
    this.micHandle?.stop();
    this.micHandle = null;
    this.pcmChunkAccumulator = [];
    this.pcmSampleCount = 0;
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    try {
      this.inputCtx?.close();
      this.outputCtx?.close();
    } catch {}
    this.inputCtx = null;
    this.outputCtx = null;
    this.analyser = null;
    try {
      if (this.ws && this.ws.readyState <= WebSocket.OPEN) this.ws.close();
    } catch {}
    this.ws = null;
    this.callbacks.onStatus("ended");
  }
}
