import {
  GoogleAuthProvider,
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  type User,
} from "firebase/auth";
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  onSnapshot,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where,
} from "firebase/firestore";
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  markAuthSigningIn,
  OperationType,
  setCachedCalendarAccessToken,
} from "./firebase";
import type {
  ChatMessage,
  DiaryEntry,
  FamilyRoomConfig,
  MedReminder,
  MedicalReportRecord,
  NoorProfile,
  VitalRecord,
  VoiceSettings,
} from "../types/noor";

function safeDocId(raw: string): string {
  const cleaned = raw.replace(/[^a-zA-Z0-9_-]/g, "_").slice(0, 120);
  return cleaned || `id_${Date.now()}`;
}

export function normalizeRoomCode(raw: string): string {
  return raw
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9_-]/g, "")
    .slice(0, 32);
}

export function generateRoomCode(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "NOOR-";
  for (let i = 0; i < 6; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

export function generateRoomPasscode(): string {
  return String(Math.floor(100000 + Math.random() * 900000));
}

export type FamilyChannelId = "chat" | "reminders" | "diary" | "vitals" | "reports";

export interface CloudWorkspaceData {
  name: string;
  about: string;
  familyNotes?: string;
  bodyMode: boolean;
  lang: VoiceSettings["lang"];
  stt: VoiceSettings["stt"];
  geminiStyleId: string;
}

export async function signInCloudSync(): Promise<User> {
  markAuthSigningIn(true);
  try {
    const res = await signInWithPopup(auth, googleProvider);
    const credential = GoogleAuthProvider.credentialFromResult(res);
    setCachedCalendarAccessToken(credential?.accessToken || null);
    return res.user;
  } finally {
    markAuthSigningIn(false);
  }
}

export async function signOutCloudSync(): Promise<void> {
  setCachedCalendarAccessToken(null);
  await signOut(auth);
}

export function subscribeAuthUser(cb: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, cb);
}

export async function ensureCloudWorkspace(
  uid: string,
  profile: NoorProfile,
  settings: VoiceSettings
): Promise<CloudWorkspaceData | null> {
  const userId = safeDocId(uid);
  const path = `users/${userId}`;
  const ref = doc(db, "users", userId);

  let snap;
  try {
    snap = await getDoc(ref);
  } catch (err) {
    handleFirestoreError(err, OperationType.GET, path);
  }

  if (snap.exists()) {
    return snap.data() as CloudWorkspaceData;
  }

  const payload = {
    uid: userId,
    name: profile.name.slice(0, 80) || "Noor Haram",
    about: profile.about.slice(0, 2000),
    familyNotes: (profile.familyNotes || "").slice(0, 4000),
    bodyMode: Boolean(profile.bodyMode),
    lang: settings.lang,
    stt: settings.stt,
    geminiStyleId: settings.geminiStyleId.slice(0, 64),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    await setDoc(ref, payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }

  return null;
}

export async function syncWorkspaceToCloud(
  uid: string,
  profile: NoorProfile,
  settings: VoiceSettings
): Promise<void> {
  const userId = safeDocId(uid);
  const path = `users/${userId}`;
  const ref = doc(db, "users", userId);
  try {
    await updateDoc(ref, {
      name: profile.name.slice(0, 80) || "Noor Haram",
      about: profile.about.slice(0, 2000),
      familyNotes: (profile.familyNotes || "").slice(0, 4000),
      bodyMode: Boolean(profile.bodyMode),
      lang: settings.lang,
      stt: settings.stt,
      geminiStyleId: settings.geminiStyleId.slice(0, 64),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.UPDATE, path);
  }
}

export async function pushCloudMessage(uid: string, msg: ChatMessage): Promise<void> {
  if (!msg.content.trim()) return;
  const userId = safeDocId(uid);
  const msgId = safeDocId(msg.id);
  const path = `users/${userId}/messages/${msgId}`;
  try {
    await setDoc(doc(db, "users", userId, "messages", msgId), {
      ownerUid: userId,
      role: msg.role,
      content: msg.content.slice(0, 16000),
      clientTimestamp: Number(msg.timestamp) || Date.now(),
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function clearCloudMessages(uid: string): Promise<void> {
  const userId = safeDocId(uid);
  const path = `users/${userId}/messages`;
  try {
    const q = query(collection(db, "users", userId, "messages"), where("ownerUid", "==", userId));
    const snap = await getDocs(q);
    await Promise.all(
      snap.docs.map((d) =>
        deleteDoc(d.ref).catch((err) => handleFirestoreError(err, OperationType.DELETE, `${path}/${d.id}`))
      )
    );
  } catch (err) {
    handleFirestoreError(err, OperationType.LIST, path);
  }
}

export async function saveCloudReminder(uid: string, rem: MedReminder, isNew: boolean): Promise<void> {
  const userId = safeDocId(uid);
  const remId = safeDocId(rem.id);
  const path = `users/${userId}/reminders/${remId}`;
  const ref = doc(db, "users", userId, "reminders", remId);
  try {
    if (isNew) {
      await setDoc(ref, {
        ownerUid: userId,
        title: rem.title.slice(0, 160),
        time: /^\d{2}:\d{2}$/.test(rem.time) ? rem.time : "09:00",
        note: (rem.note || "").slice(0, 400),
        enabled: Boolean(rem.enabled),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    } else {
      await updateDoc(ref, {
        title: rem.title.slice(0, 160),
        time: /^\d{2}:\d{2}$/.test(rem.time) ? rem.time : "09:00",
        note: (rem.note || "").slice(0, 400),
        enabled: Boolean(rem.enabled),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (err) {
    handleFirestoreError(err, isNew ? OperationType.CREATE : OperationType.UPDATE, path);
  }
}

export async function deleteCloudReminder(uid: string, id: string): Promise<void> {
  const userId = safeDocId(uid);
  const remId = safeDocId(id);
  const path = `users/${userId}/reminders/${remId}`;
  try {
    await deleteDoc(doc(db, "users", userId, "reminders", remId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function saveCloudDiaryEntry(uid: string, entry: DiaryEntry): Promise<void> {
  const userId = safeDocId(uid);
  const entryId = safeDocId(entry.id);
  const path = `users/${userId}/diary/${entryId}`;
  try {
    await setDoc(doc(db, "users", userId, "diary", entryId), {
      ownerUid: userId,
      kind: entry.kind,
      title: entry.title.slice(0, 160),
      notes: (entry.notes || "").slice(0, 6000),
      clientTimestamp: Number(entry.createdAt) || Date.now(),
      createdAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function deleteCloudDiaryEntry(uid: string, id: string): Promise<void> {
  const userId = safeDocId(uid);
  const entryId = safeDocId(id);
  const path = `users/${userId}/diary/${entryId}`;
  try {
    await deleteDoc(doc(db, "users", userId, "diary", entryId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function saveCloudVital(uid: string, vital: VitalRecord): Promise<void> {
  const userId = safeDocId(uid);
  const vitalId = safeDocId(vital.id);
  const path = `users/${userId}/vitals/${vitalId}`;
  const payload: Record<string, unknown> = {
    ownerUid: userId,
    clientTimestamp: Number(vital.createdAt) || Date.now(),
    createdAt: serverTimestamp(),
  };
  if (typeof vital.tempF === "number" && vital.tempF >= 85 && vital.tempF <= 115) payload.tempF = vital.tempF;
  if (typeof vital.bpSys === "number" && vital.bpSys >= 40 && vital.bpSys <= 300) payload.bpSys = vital.bpSys;
  if (typeof vital.bpDia === "number" && vital.bpDia >= 20 && vital.bpDia <= 200) payload.bpDia = vital.bpDia;
  if (typeof vital.sugarMgDl === "number" && vital.sugarMgDl >= 20 && vital.sugarMgDl <= 900) {
    payload.sugarMgDl = vital.sugarMgDl;
  }
  if (typeof vital.spo2 === "number" && vital.spo2 >= 40 && vital.spo2 <= 100) payload.spo2 = vital.spo2;
  if (typeof vital.heartRate === "number" && vital.heartRate >= 25 && vital.heartRate <= 260) {
    payload.heartRate = vital.heartRate;
  }
  if (vital.note?.trim()) payload.note = vital.note.trim().slice(0, 400);

  try {
    await setDoc(doc(db, "users", userId, "vitals", vitalId), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function deleteCloudVital(uid: string, id: string): Promise<void> {
  const userId = safeDocId(uid);
  const vitalId = safeDocId(id);
  const path = `users/${userId}/vitals/${vitalId}`;
  try {
    await deleteDoc(doc(db, "users", userId, "vitals", vitalId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export async function saveCloudReport(uid: string, report: MedicalReportRecord): Promise<void> {
  const userId = safeDocId(uid);
  const reportId = safeDocId(report.id);
  const path = `users/${userId}/reports/${reportId}`;
  const detailsJson = JSON.stringify({
    keyFindings: (report.keyFindings || []).slice(0, 15),
    careSteps: (report.careSteps || []).slice(0, 15),
    redFlags: (report.redFlags || []).slice(0, 15),
  }).slice(0, 16000);

  const payload: Record<string, unknown> = {
    ownerUid: userId,
    title: (report.title || "Medical Scan").slice(0, 200),
    urgency: report.urgency,
    noorReply: (report.noorReply || "Scan analyzed.").slice(0, 8000),
    detailsJson,
    clientTimestamp: Number(report.createdAt) || Date.now(),
    createdAt: serverTimestamp(),
  };
  if (report.fileName) payload.fileName = report.fileName.slice(0, 160);
  if (report.mimeType) payload.mimeType = report.mimeType.slice(0, 64);

  try {
    await setDoc(doc(db, "users", userId, "reports", reportId), payload);
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, path);
  }
}

export async function deleteCloudReport(uid: string, id: string): Promise<void> {
  const userId = safeDocId(uid);
  const reportId = safeDocId(id);
  const path = `users/${userId}/reports/${reportId}`;
  try {
    await deleteDoc(doc(db, "users", userId, "reports", reportId));
  } catch (err) {
    handleFirestoreError(err, OperationType.DELETE, path);
  }
}

export function subscribeCloudWorkspace(
  uid: string,
  callbacks: {
    onWorkspace: (data: CloudWorkspaceData) => void;
    onMessages: (msgs: ChatMessage[]) => void;
    onReminders: (rems: MedReminder[]) => void;
    onDiary: (entries: DiaryEntry[]) => void;
    onVitals?: (vitals: VitalRecord[]) => void;
    onReports?: (reports: MedicalReportRecord[]) => void;
  }
): () => void {
  const userId = safeDocId(uid);

  const unsubUser = onSnapshot(
    doc(db, "users", userId),
    (snap) => {
      if (snap.exists()) {
        callbacks.onWorkspace(snap.data() as CloudWorkspaceData);
      }
    },
    (err) => {
      console.warn("Firestore sync notice:", err instanceof Error ? err.message : err);
    }
  );

  const msgsPath = `users/${userId}/messages`;
  const unsubMsgs = onSnapshot(
    query(collection(db, "users", userId, "messages"), where("ownerUid", "==", userId)),
    (snap) => {
      const list: ChatMessage[] = snap.docs
        .map((d) => {
          const data = d.data();
          return {
            id: d.id,
            role: data.role === "assistant" ? ("assistant" as const) : ("user" as const),
            content: String(data.content || ""),
            timestamp: Number(data.clientTimestamp || Date.now()),
          };
        })
        .sort((a, b) => a.timestamp - b.timestamp)
        .slice(-80);
      callbacks.onMessages(list);
    },
    (err) => {
      console.warn("Firestore sync notice:", err instanceof Error ? err.message : err);
    }
  );

  const remPath = `users/${userId}/reminders`;
  const unsubRems = onSnapshot(
    query(collection(db, "users", userId, "reminders"), where("ownerUid", "==", userId)),
    (snap) => {
      const list: MedReminder[] = snap.docs.map((d) => {
        const data = d.data();
        return {
          id: d.id,
          title: String(data.title || ""),
          time: String(data.time || "09:00"),
          note: String(data.note || ""),
          enabled: Boolean(data.enabled),
        };
      });
      callbacks.onReminders(list);
    },
    (err) => {
      // Quietly handled offline state
    }
  );

  const diaryPath = `users/${userId}/diary`;
  const unsubDiary = onSnapshot(
    query(collection(db, "users", userId, "diary"), where("ownerUid", "==", userId)),
    (snap) => {
      const list: DiaryEntry[] = snap.docs
        .map((d) => {
          const data = d.data();
          return {
            id: d.id,
            kind: data.kind === "memory" ? ("memory" as const) : ("health" as const),
            title: String(data.title || ""),
            notes: String(data.notes || ""),
            createdAt: Number(data.clientTimestamp || Date.now()),
          };
        })
        .sort((a, b) => b.createdAt - a.createdAt)
        .slice(0, 100);
      callbacks.onDiary(list);
    },
    (err) => {
      // Quietly handled offline state
    }
  );

  const vitalsPath = `users/${userId}/vitals`;
  const unsubVitals = onSnapshot(
    query(collection(db, "users", userId, "vitals"), where("ownerUid", "==", userId)),
    (snap) => {
      const list: VitalRecord[] = snap.docs
        .map((d) => {
          const data = d.data();
          return {
            id: d.id,
            tempF: typeof data.tempF === "number" ? data.tempF : undefined,
            bpSys: typeof data.bpSys === "number" ? data.bpSys : undefined,
            bpDia: typeof data.bpDia === "number" ? data.bpDia : undefined,
            sugarMgDl: typeof data.sugarMgDl === "number" ? data.sugarMgDl : undefined,
            spo2: typeof data.spo2 === "number" ? data.spo2 : undefined,
            heartRate: typeof data.heartRate === "number" ? data.heartRate : undefined,
            note: typeof data.note === "string" ? data.note : undefined,
            createdAt: Number(data.clientTimestamp || Date.now()),
          };
        })
        .sort((a, b) => b.createdAt - a.createdAt)
        .slice(0, 100);
      callbacks.onVitals?.(list);
    },
    (err) => {
      // Quietly handled offline state
    }
  );

  const reportsPath = `users/${userId}/reports`;
  const unsubReports = onSnapshot(
    query(collection(db, "users", userId, "reports"), where("ownerUid", "==", userId)),
    (snap) => {
      const list: MedicalReportRecord[] = snap.docs
        .map((d) => {
          const data = d.data();
          let parsedDetails: {
            keyFindings?: string[];
            careSteps?: string[];
            redFlags?: string[];
          } = {};
          try {
            parsedDetails = JSON.parse(String(data.detailsJson || "{}"));
          } catch {}
          return {
            id: d.id,
            title: String(data.title || "Medical Report"),
            urgency:
              data.urgency === "urgent" || data.urgency === "consult_soon"
                ? data.urgency
                : ("routine" as const),
            noorReply: String(data.noorReply || ""),
            keyFindings: Array.isArray(parsedDetails.keyFindings) ? parsedDetails.keyFindings : [],
            careSteps: Array.isArray(parsedDetails.careSteps) ? parsedDetails.careSteps : [],
            redFlags: Array.isArray(parsedDetails.redFlags) ? parsedDetails.redFlags : [],
            fileName: typeof data.fileName === "string" ? data.fileName : undefined,
            mimeType: typeof data.mimeType === "string" ? data.mimeType : undefined,
            createdAt: Number(data.clientTimestamp || Date.now()),
          };
        })
        .sort((a, b) => b.createdAt - a.createdAt)
        .slice(0, 50);
      callbacks.onReports?.(list);
    },
    (err) => {
      // Quietly handled offline state
    }
  );

  return () => {
    unsubUser();
    unsubMsgs();
    unsubRems();
    unsubDiary();
    unsubVitals();
    unsubReports();
  };
}

// =========================================================================
// Feature 1: Multi-Phone Shared Family Room Sync (Zero-List O(1) Pattern)
// =========================================================================

function serializeChannelItems(items: unknown[]): string {
  const capped = [...items];
  let json = JSON.stringify(capped);
  while (json.length > 110000 && capped.length > 1) {
    capped.pop();
    json = JSON.stringify(capped);
  }
  return json.slice(0, 118000);
}

export async function createFamilyRoom(
  uid: string,
  displayName: string,
  roomName: string,
  passcodeInput?: string,
  initialData?: {
    chat?: ChatMessage[];
    reminders?: MedReminder[];
    diary?: DiaryEntry[];
    vitals?: VitalRecord[];
    reports?: MedicalReportRecord[];
  }
): Promise<FamilyRoomConfig> {
  const userId = safeDocId(uid);
  const roomCode = generateRoomCode();
  const passcode = (passcodeInput || generateRoomPasscode()).trim().slice(0, 32);
  const safePass = passcode.length >= 4 ? passcode : generateRoomPasscode();
  const cleanRoomName = roomName.trim().slice(0, 80) || "Family Room";
  const cleanMemberName = (displayName || "Family Owner").trim().slice(0, 80);

  const roomPath = `rooms/${roomCode}`;
  const memberPath = `rooms/${roomCode}/members/${userId}`;

  try {
    await setDoc(doc(db, "rooms", roomCode), {
      roomCode,
      roomName: cleanRoomName,
      passcode: safePass,
      ownerUid: userId,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, roomPath);
  }

  try {
    await setDoc(doc(db, "rooms", roomCode, "members", userId), {
      roomCode,
      memberUid: userId,
      displayName: cleanMemberName,
      role: "owner",
      passcode: safePass,
      joinedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, memberPath);
  }

  if (initialData) {
    const channelEntries: Array<[FamilyChannelId, unknown[]]> = [
      ["chat", (initialData.chat || []).slice(-50)],
      ["reminders", (initialData.reminders || []).slice(0, 60)],
      ["diary", (initialData.diary || []).slice(0, 60)],
      ["vitals", (initialData.vitals || []).slice(0, 60)],
      ["reports", (initialData.reports || []).slice(0, 30)],
    ];
    await Promise.all(
      channelEntries.map(([channelId, arr]) =>
        setDoc(doc(db, "rooms", roomCode, "channels", channelId), {
          roomCode,
          channelId,
          updatedByUid: userId,
          updatedByName: cleanMemberName,
          itemsJson: serializeChannelItems(arr),
          updatedAt: serverTimestamp(),
        }).catch(() => {})
      )
    );
  }

  return {
    roomCode,
    passcode: safePass,
    roomName: cleanRoomName,
    role: "owner",
  };
}

export async function joinFamilyRoom(
  uid: string,
  displayName: string,
  rawRoomCode: string,
  rawPasscode: string
): Promise<FamilyRoomConfig> {
  const userId = safeDocId(uid);
  const roomCode = normalizeRoomCode(rawRoomCode);
  const passcode = rawPasscode.trim().slice(0, 32);
  if (!roomCode || passcode.length < 4) {
    throw new Error("Enter a valid Room Code and 4+ digit Passcode.");
  }

  const cleanMemberName = (displayName || "Family Member").trim().slice(0, 80);
  const memberPath = `rooms/${roomCode}/members/${userId}`;

  // Step 1: Join membership document (Firestore rules verify room exists & passcode matches server-side)
  try {
    await setDoc(doc(db, "rooms", roomCode, "members", userId), {
      roomCode,
      memberUid: userId,
      displayName: cleanMemberName,
      role: "member",
      passcode,
      joinedAt: serverTimestamp(),
    });
  } catch (err) {
    handleFirestoreError(err, OperationType.CREATE, memberPath);
  }

  // Step 2: Now that caller is a verified member, read room metadata
  let roomName = "Family Room";
  let role: "owner" | "member" = "member";
  try {
    const snap = await getDoc(doc(db, "rooms", roomCode));
    if (snap.exists()) {
      const d = snap.data();
      roomName = String(d.roomName || roomName);
      if (d.ownerUid === userId) role = "owner";
    }
  } catch {
    // Non-fatal; channel subscriptions still work
  }

  return {
    roomCode,
    passcode,
    roomName,
    role,
  };
}

export async function leaveFamilyRoom(uid: string, roomCode: string): Promise<void> {
  const userId = safeDocId(uid);
  const cleanCode = normalizeRoomCode(roomCode);
  if (!cleanCode) return;
  try {
    await deleteDoc(doc(db, "rooms", cleanCode, "members", userId));
  } catch {
    // Ignore if already removed
  }
}

export async function syncRoomChannel(
  uid: string,
  displayName: string,
  roomCode: string,
  channelId: FamilyChannelId,
  items: unknown[]
): Promise<void> {
  const userId = safeDocId(uid);
  const cleanCode = normalizeRoomCode(roomCode);
  if (!cleanCode) return;

  const ref = doc(db, "rooms", cleanCode, "channels", channelId);
  const path = `rooms/${cleanCode}/channels/${channelId}`;
  const cleanMemberName = (displayName || "Family Member").trim().slice(0, 80);
  const itemsJson = serializeChannelItems(items);

  try {
    await updateDoc(ref, {
      updatedByUid: userId,
      updatedByName: cleanMemberName,
      itemsJson,
      updatedAt: serverTimestamp(),
    });
  } catch {
    try {
      await setDoc(ref, {
        roomCode: cleanCode,
        channelId,
        updatedByUid: userId,
        updatedByName: cleanMemberName,
        itemsJson,
        updatedAt: serverTimestamp(),
      });
    } catch (err) {
      handleFirestoreError(err, OperationType.WRITE, path);
    }
  }
}

export function subscribeFamilyRoom(
  roomCode: string,
  currentUid: string,
  callbacks: {
    onChat: (msgs: ChatMessage[], updatedByUid: string) => void;
    onReminders: (rems: MedReminder[], updatedByUid: string) => void;
    onDiary: (entries: DiaryEntry[], updatedByUid: string) => void;
    onVitals: (vitals: VitalRecord[], updatedByUid: string) => void;
    onReports: (reports: MedicalReportRecord[], updatedByUid: string) => void;
    onError?: (err: unknown) => void;
  }
): () => void {
  const cleanCode = normalizeRoomCode(roomCode);
  if (!cleanCode) return () => {};

  const channels: FamilyChannelId[] = ["chat", "reminders", "diary", "vitals", "reports"];
  const unsubs = channels.map((ch) =>
    onSnapshot(
      doc(db, "rooms", cleanCode, "channels", ch),
      (snap) => {
        if (!snap.exists()) return;
        const data = snap.data();
        const updatedByUid = String(data.updatedByUid || "");
        if (updatedByUid === safeDocId(currentUid)) return;
        let parsed: unknown[] = [];
        try {
          const raw = JSON.parse(String(data.itemsJson || "[]"));
          if (Array.isArray(raw)) parsed = raw;
        } catch {
          return;
        }
        if (ch === "chat") callbacks.onChat(parsed as ChatMessage[], updatedByUid);
        else if (ch === "reminders") callbacks.onReminders(parsed as MedReminder[], updatedByUid);
        else if (ch === "diary") callbacks.onDiary(parsed as DiaryEntry[], updatedByUid);
        else if (ch === "vitals") callbacks.onVitals(parsed as VitalRecord[], updatedByUid);
        else if (ch === "reports") callbacks.onReports(parsed as MedicalReportRecord[], updatedByUid);
      },
      (err) => {
        callbacks.onError?.(err);
      }
    )
  );

  return () => {
    unsubs.forEach((u) => u());
  };
}
