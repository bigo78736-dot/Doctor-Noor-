import type { CalendarAlarmEvent, MedReminder } from "../types/noor";

const CALENDAR_API_BASE = "https://www.googleapis.com/calendar/v3/calendars/primary/events";

function getLocalTimeZone(): string {
  try {
    return Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Karachi";
  } catch {
    return "Asia/Karachi";
  }
}

function formatOffsetDateTime(hhmm: string): { startIso: string; endIso: string; timeZone: string } {
  const match = /^(\d{2}):(\d{2})$/.exec(hhmm || "09:00");
  const hh = match ? Number(match[1]) : 9;
  const mm = match ? Number(match[2]) : 0;

  const start = new Date();
  start.setHours(hh, mm, 0, 0);
  // If already passed today, schedule first occurrence tomorrow
  if (start.getTime() < Date.now() - 60000) {
    start.setDate(start.getDate() + 1);
  }
  const end = new Date(start.getTime() + 15 * 60 * 1000);

  const toLocalIso = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(
      d.getHours()
    )}:${pad(d.getMinutes())}:00`;
  };

  return {
    startIso: toLocalIso(start),
    endIso: toLocalIso(end),
    timeZone: getLocalTimeZone(),
  };
}

function buildEventPayload(reminder: MedReminder, noorName = "Noor Haram") {
  const { startIso, endIso, timeZone } = formatOffsetDateTime(reminder.time);
  const summary = `💊 ${reminder.title} (Dr. ${noorName})`;
  const description = [
    reminder.note ? `Note: ${reminder.note}` : "",
    `Scheduled by Dr. ${noorName} AI Medicine & Health Reminder.`,
  ]
    .filter(Boolean)
    .join("\n");

  return {
    summary: summary.slice(0, 220),
    description,
    start: {
      dateTime: startIso,
      timeZone,
    },
    end: {
      dateTime: endIso,
      timeZone,
    },
    recurrence: ["RRULE:FREQ=DAILY"],
    reminders: {
      useDefault: false,
      overrides: [
        { method: "popup", minutes: 0 },
        { method: "popup", minutes: 10 },
      ],
    },
    extendedProperties: {
      private: {
        noorReminderId: reminder.id,
        noorApp: "dr-noor-haram",
      },
    },
  };
}

async function parseCalendarError(res: Response): Promise<string> {
  const txt = await res.text().catch(() => "");
  try {
    const parsed = JSON.parse(txt);
    const msg = parsed?.error?.message;
    if (res.status === 401) {
      return "Google Calendar session expired — tap Sign in with Google again.";
    }
    if (res.status === 403) {
      return "Calendar access not granted yet. Tap Sign in with Google and allow Google Calendar.";
    }
    if (msg) return String(msg);
  } catch {}
  return `Google Calendar request failed (${res.status})`;
}

export async function listMedicineCalendarEvents(
  accessToken: string
): Promise<CalendarAlarmEvent[]> {
  const params = new URLSearchParams({
    maxResults: "25",
    q: "Dr.",
    singleEvents: "false",
  });
  const res = await fetch(`${CALENDAR_API_BASE}?${params.toString()}`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });
  if (!res.ok) {
    throw new Error(await parseCalendarError(res));
  }
  const data = (await res.json()) as {
    items?: Array<{
      id?: string;
      summary?: string;
      htmlLink?: string;
      status?: string;
      start?: { dateTime?: string; date?: string };
      extendedProperties?: { private?: { noorReminderId?: string; noorApp?: string } };
    }>;
  };

  const items = Array.isArray(data.items) ? data.items : [];
  return items
    .filter((ev) => ev.id && ev.status !== "cancelled")
    .map((ev) => {
      const rawStart = ev.start?.dateTime || ev.start?.date || "";
      let timeLabel = "Daily";
      if (rawStart) {
        const d = new Date(rawStart);
        if (!Number.isNaN(d.getTime())) {
          timeLabel = d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
        }
      }
      return {
        id: String(ev.id),
        summary: String(ev.summary || "Medicine Alarm"),
        timeLabel,
        htmlLink: ev.htmlLink,
        noorReminderId: ev.extendedProperties?.private?.noorReminderId,
      };
    });
}

export async function createMedicineCalendarEvent(
  accessToken: string,
  reminder: MedReminder,
  noorName = "Noor Haram"
): Promise<{ eventId: string; htmlLink?: string }> {
  const res = await fetch(CALENDAR_API_BASE, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(buildEventPayload(reminder, noorName)),
  });
  if (!res.ok) {
    throw new Error(await parseCalendarError(res));
  }
  const created = (await res.json()) as { id?: string; htmlLink?: string };
  if (!created.id) {
    throw new Error("Calendar did not return an event ID.");
  }
  return {
    eventId: created.id,
    htmlLink: created.htmlLink,
  };
}

export async function updateMedicineCalendarEvent(
  accessToken: string,
  eventId: string,
  reminder: MedReminder,
  noorName = "Noor Haram"
): Promise<{ eventId: string; htmlLink?: string }> {
  const res = await fetch(`${CALENDAR_API_BASE}/${encodeURIComponent(eventId)}`, {
    method: "PATCH",
    headers: {
      Authorization: `Bearer ${accessToken}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(buildEventPayload(reminder, noorName)),
  });
  if (!res.ok) {
    throw new Error(await parseCalendarError(res));
  }
  const updated = (await res.json()) as { id?: string; htmlLink?: string };
  return {
    eventId: updated.id || eventId,
    htmlLink: updated.htmlLink,
  };
}

export async function deleteMedicineCalendarEvent(
  accessToken: string,
  eventId: string
): Promise<void> {
  const res = await fetch(`${CALENDAR_API_BASE}/${encodeURIComponent(eventId)}`, {
    method: "DELETE",
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });
  // 404/410 means already deleted on Calendar
  if (!res.ok && res.status !== 404 && res.status !== 410) {
    throw new Error(await parseCalendarError(res));
  }
}
