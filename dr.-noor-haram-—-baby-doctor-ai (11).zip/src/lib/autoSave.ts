import type {
  ChatMessage,
  DiaryEntry,
  MedReminder,
  MedicalReportRecord,
  NoorProfile,
  VitalRecord,
  VoiceSettings,
} from "../types/noor";

const DB_NAME = "noor-haram-autosave";
const STORE_NAME = "snapshots";

export interface NoorBackupBundle {
  version: number;
  exportedAt: string;
  profile: NoorProfile;
  settings: VoiceSettings;
  history: ChatMessage[];
  reminders: MedReminder[];
  diaryEntries: DiaryEntry[];
  vitals?: VitalRecord[];
  reports?: MedicalReportRecord[];
  familyMode: boolean;
}

function openAutoSaveDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof indexedDB === "undefined") {
      reject(new Error("IndexedDB unavailable"));
      return;
    }
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME);
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveSnapshotToDb(key: string, value: unknown): Promise<void> {
  try {
    const db = await openAutoSaveDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(value, key);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // localStorage remains primary synchronous persistence
  }
}

export async function loadSnapshotFromDb<T>(key: string): Promise<T | null> {
  try {
    const db = await openAutoSaveDb();
    return await new Promise<T | null>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readonly");
      const req = tx.objectStore(STORE_NAME).get(key);
      req.onsuccess = () => resolve((req.result as T) ?? null);
      req.onerror = () => reject(req.error);
    });
  } catch {
    return null;
  }
}

export function downloadAutoSaveBackup(bundle: NoorBackupBundle) {
  const json = JSON.stringify(bundle, null, 2);
  const blob = new Blob([json], { type: "application/json;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `dr-noor-haram-autosave-${new Date().toISOString().slice(0, 10)}.json`;
  a.click();
  URL.revokeObjectURL(url);
}
