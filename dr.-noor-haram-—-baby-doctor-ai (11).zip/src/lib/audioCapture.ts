// High-reliability 16kHz PCM WAV encoder & AudioWorklet capture engine
// Includes automatic quiet-mic gain normalization, iOS/Android AudioContext unlock,
// and silent-frame watchdog fallback to ScriptProcessorNode.

const WORKLET_CODE = `
class NoorMicProcessor extends AudioWorkletProcessor {
  process(inputs) {
    const input = inputs[0];
    if (input && input[0] && input[0].length > 0) {
      const ch = input[0];
      const copy = new Float32Array(ch.length);
      copy.set(ch);
      this.port.postMessage(copy, [copy.buffer]);
    }
    return true;
  }
}
registerProcessor("noor-mic-processor", NoorMicProcessor);
`;

export function getSharedAudioCtxCtor(): typeof AudioContext {
  return (
    window.AudioContext ||
    (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
  );
}

export function downsampleTo16k(input: Float32Array, inputRate: number): Float32Array {
  if (inputRate === 16000) return input;
  const ratio = inputRate / 16000;
  const outLen = Math.max(1, Math.round(input.length / ratio));
  const out = new Float32Array(outLen);
  for (let i = 0; i < outLen; i++) {
    const start = Math.floor(i * ratio);
    const end = Math.min(input.length, Math.floor((i + 1) * ratio));
    let sum = 0;
    let count = 0;
    for (let j = start; j < end; j++) {
      sum += input[j];
      count++;
    }
    out[i] = count > 0 ? sum / count : input[Math.min(start, input.length - 1)] || 0;
  }
  return out;
}

export function float32ToInt16Base64(input: Float32Array): string {
  const buf = new Int16Array(input.length);
  for (let i = 0; i < input.length; i++) {
    const s = Math.max(-1, Math.min(1, input[i]));
    buf[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
  }
  const bytes = new Uint8Array(buf.buffer);
  let bin = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    bin += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
  }
  return btoa(bin);
}

export function encodePcm16kChunksToWavBase64(chunks: Float32Array[]): string {
  let totalSamples = 0;
  let maxPeak = 0;
  for (const c of chunks) {
    totalSamples += c.length;
    for (let i = 0; i < c.length; i++) {
      const a = Math.abs(c[i]);
      if (a > maxPeak) maxPeak = a;
    }
  }
  if (totalSamples === 0) return "";

  // Gentle automatic gain normalization for soft/distant phone microphones (capped at 7.5x)
  const gain = maxPeak > 0.002 && maxPeak < 0.55 ? Math.min(7.5, 0.62 / maxPeak) : 1;

  const pcmBytesLen = totalSamples * 2;
  const buffer = new ArrayBuffer(44 + pcmBytesLen);
  const view = new DataView(buffer);

  const writeStr = (offset: number, s: string) => {
    for (let i = 0; i < s.length; i++) view.setUint8(offset + i, s.charCodeAt(i));
  };

  writeStr(0, "RIFF");
  view.setUint32(4, 36 + pcmBytesLen, true);
  writeStr(8, "WAVE");
  writeStr(12, "fmt ");
  view.setUint32(16, 16, true);
  view.setUint16(20, 1, true); // PCM
  view.setUint16(22, 1, true); // mono
  view.setUint32(24, 16000, true);
  view.setUint32(28, 32000, true);
  view.setUint16(32, 2, true);
  view.setUint16(34, 16, true);
  writeStr(36, "data");
  view.setUint32(40, pcmBytesLen, true);

  let offset = 44;
  for (const chunk of chunks) {
    for (let i = 0; i < chunk.length; i++) {
      const s = Math.max(-1, Math.min(1, chunk[i] * gain));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7fff, true);
      offset += 2;
    }
  }

  const bytes = new Uint8Array(buffer);
  let bin = "";
  const step = 0x8000;
  for (let i = 0; i < bytes.length; i += step) {
    bin += String.fromCharCode(...bytes.subarray(i, i + step));
  }
  return btoa(bin);
}

export interface MicPipelineHandle {
  stop: () => void;
}

export async function startMicPcmPipeline(
  ctx: AudioContext,
  stream: MediaStream,
  onPcm16k: (pcm16k: Float32Array, rms: number) => void
): Promise<MicPipelineHandle> {
  if (ctx.state === "suspended") {
    await ctx.resume().catch(() => {});
  }

  const source = ctx.createMediaStreamSource(stream);
  const sampleRate = ctx.sampleRate || 48000;

  let activeCleanup: (() => void) | null = null;
  let stopped = false;

  const startScriptProcessor = () => {
    if (stopped) return;
    const proc = ctx.createScriptProcessor(2048, 1, 1);
    const silentGain = ctx.createGain();
    silentGain.gain.value = 0;

    proc.onaudioprocess = (ev) => {
      if (stopped) return;
      const raw = ev.inputBuffer.getChannelData(0);
      if (!raw || raw.length === 0) return;
      let sum = 0;
      for (let i = 0; i < raw.length; i++) sum += raw[i] * raw[i];
      const rms = Math.sqrt(sum / raw.length);
      onPcm16k(downsampleTo16k(raw, sampleRate), rms);
    };

    source.connect(proc);
    proc.connect(silentGain);
    silentGain.connect(ctx.destination);

    activeCleanup = () => {
      try {
        proc.onaudioprocess = null;
        proc.disconnect();
        silentGain.disconnect();
        source.disconnect();
      } catch {}
    };
  };

  if (typeof AudioWorkletNode !== "undefined" && ctx.audioWorklet) {
    try {
      const blob = new Blob([WORKLET_CODE], { type: "application/javascript" });
      const blobUrl = URL.createObjectURL(blob);
      try {
        await ctx.audioWorklet.addModule(blobUrl);
      } finally {
        URL.revokeObjectURL(blobUrl);
      }

      if (stopped) {
        return { stop: () => {} };
      }

      const worklet = new AudioWorkletNode(ctx, "noor-mic-processor");
      const silentGain = ctx.createGain();
      silentGain.gain.value = 0;

      let receivedFrames = 0;

      worklet.port.onmessage = (ev: MessageEvent<Float32Array>) => {
        if (stopped) return;
        const raw = ev.data;
        if (!raw || raw.length === 0) return;
        receivedFrames++;
        let sum = 0;
        for (let i = 0; i < raw.length; i++) sum += raw[i] * raw[i];
        const rms = Math.sqrt(sum / raw.length);
        onPcm16k(downsampleTo16k(raw, sampleRate), rms);
      };

      source.connect(worklet);
      worklet.connect(silentGain);
      silentGain.connect(ctx.destination);

      const cleanupWorklet = () => {
        try {
          worklet.port.onmessage = null;
          worklet.disconnect();
          silentGain.disconnect();
        } catch {}
      };

      activeCleanup = () => {
        cleanupWorklet();
        try {
          source.disconnect();
        } catch {}
      };

      // Watchdog: if mobile WebView/browser leaves AudioWorklet silent for 850ms, fall back to ScriptProcessor
      const watchdog = setTimeout(() => {
        if (!stopped && receivedFrames === 0) {
          cleanupWorklet();
          startScriptProcessor();
        }
      }, 850);

      return {
        stop: () => {
          stopped = true;
          clearTimeout(watchdog);
          activeCleanup?.();
          activeCleanup = null;
        },
      };
    } catch {
      // Fall back cleanly to ScriptProcessorNode below
    }
  }

  startScriptProcessor();
  return {
    stop: () => {
      stopped = true;
      activeCleanup?.();
      activeCleanup = null;
    },
  };
}
