import type { GestureName, VoiceSettings } from "../types/noor";
import { AvatarEngine, GESTURES } from "./avatarEngine";
import { GEMINI_VOICE_STYLES, VOICE_PRESETS, presetVoice } from "./voices";

const URDU_RE = /[\u0600-\u06ff]/;
const TAG_RE = /\[(\w+)\]/g;

export function stripTags(s: string): string {
  return s
    .replace(TAG_RE, "")
    .replace(/\*\*(.*?)\*\*/g, "$1")
    .replace(/[*_`~]+/g, "")
    .replace(/\s{2,}/g, " ")
    .trim();
}

export function extractTags(s: string): GestureName[] {
  const tags: GestureName[] = [];
  s.replace(TAG_RE, (_, t) => {
    const k = t.toLowerCase() as GestureName;
    if (GESTURES[k]) tags.push(k);
    return "";
  });
  return tags;
}

interface SpeechItem {
  text: string;
  tags: GestureName[];
  audioPromise?: Promise<{ base64: string | null; error?: string }>;
}

// 0.05s silent 8kHz mono PCM WAV used to unlock mobile WebView / PWA <audio> autoplay on first tap
const SILENT_WAV_URI =
  "data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA";

export class SpeechController {
  avatar: AvatarEngine | null = null;
  settings: VoiceSettings;
  onSpeakingChange: (on: boolean) => void;
  onIdle?: () => void;
  onTtsNotice?: (msg: string) => void;

  queue: SpeechItem[] = [];
  active = false;
  fresh = true;
  gapTimer: ReturnType<typeof setTimeout> | null = null;
  cancelled = false;
  noticeShown = false;

  audioCtx: AudioContext | null = null;
  currentSource: AudioBufferSourceNode | null = null;
  analyser: AnalyserNode | null = null;
  audioEl: HTMLAudioElement | null = null;
  activeBlobUrl: string | null = null;
  energyRaf = 0;

  constructor(
    settings: VoiceSettings,
    onSpeakingChange: (on: boolean) => void,
    onTtsNotice?: (msg: string) => void
  ) {
    this.settings = settings;
    this.onSpeakingChange = onSpeakingChange;
    this.onTtsNotice = onTtsNotice;
    if (typeof window !== "undefined" && window.speechSynthesis) {
      try {
        window.speechSynthesis.onvoiceschanged = () => {
          window.speechSynthesis.getVoices();
        };
        window.speechSynthesis.getVoices();
      } catch {}
    }
  }

  attachAvatar(avatar: AvatarEngine | null) {
    this.avatar = avatar;
  }

  updateSettings(settings: VoiceSettings) {
    this.settings = settings;
    this.noticeShown = false;
  }

  unlockAudio() {
    if (!this.audioCtx) {
      const AC =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AC) this.audioCtx = new AC();
    }
    if (this.audioCtx && this.audioCtx.state === "suspended") {
      this.audioCtx.resume().catch(() => {});
    }
    if (typeof Audio !== "undefined") {
      try {
        if (!this.audioEl) {
          this.audioEl = new Audio();
          this.audioEl.preload = "auto";
          this.audioEl.setAttribute("playsinline", "true");
        }
        if (!this.activeBlobUrl && this.audioEl.paused) {
          this.audioEl.src = SILENT_WAV_URI;
          this.audioEl.volume = 0.01;
          this.audioEl.play().catch(() => {});
        }
      } catch {}
    }
    if (window.speechSynthesis) {
      try {
        const u = new SpeechSynthesisUtterance(" ");
        u.volume = 0;
        window.speechSynthesis.speak(u);
      } catch {}
    }
  }

  playTags(tags: GestureName[], interrupt: boolean) {
    if (!this.avatar || !tags.length) return;
    if (interrupt || this.avatar.gesture?.name === "think") {
      this.avatar.play(tags[0]);
      this.avatar.enqueue(tags.slice(1));
    } else {
      this.avatar.enqueue(tags);
    }
  }

  push(text: string, tags: GestureName[]) {
    this.cancelled = false;
    const item: SpeechItem = { text, tags };
    // Start synthesis right away only if queue is nearly empty (current + 1 lookahead)
    if (text && this.settings.engine === "gemini" && this.queue.length < 2) {
      item.audioPromise = this.fetchGeminiTTS(text);
    }
    this.queue.push(item);
    if (!this.active) this.next();
  }

  private async fetchGeminiTTS(
    text: string
  ): Promise<{ base64: string | null; error?: string }> {
    const style =
      GEMINI_VOICE_STYLES.find((s) => s.id === this.settings.geminiStyleId) ||
      GEMINI_VOICE_STYLES[0];

    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        const res = await fetch("/api/tts", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            text,
            voiceName: style.voiceName,
            style: style.stylePrompt,
          }),
        });
        const data = await res.json().catch(() => ({}));
        if (res.ok && data.audioBase64) {
          return { base64: data.audioBase64 };
        }
        if (res.ok && data.fallback === "device") {
          return { base64: null };
        }
        if (attempt === 0 && (res.status === 429 || res.status >= 500)) {
          await new Promise((r) => setTimeout(r, 260));
          continue;
        }
        return {
          base64: null,
          error: data.error || `Voice service error (${res.status})`,
        };
      } catch {
        if (attempt === 0) {
          await new Promise((r) => setTimeout(r, 260));
          continue;
        }
        return { base64: null, error: "Could not reach Gemini HD voice service." };
      }
    }
    return { base64: null, error: "Voice service temporarily busy." };
  }

  private async next() {
    if (this.gapTimer) clearTimeout(this.gapTimer);
    if (this.cancelled) return;

    const item = this.queue.shift();
    if (!item) {
      this.active = false;
      this.setSpeaking(false);
      this.onIdle?.();
      return;
    }

    this.active = true;
    this.playTags(item.tags, this.fresh);
    if (item.tags.length) this.fresh = false;
    if (!item.text) {
      this.next();
      return;
    }
    this.fresh = false;

    if (this.settings.engine === "gemini") {
      if (!item.audioPromise) {
        item.audioPromise = this.fetchGeminiTTS(item.text);
      }
      // Look ahead one sentence in the queue while current plays
      const nextItem = this.queue.find((q) => q.text && !q.audioPromise);
      if (nextItem) {
        nextItem.audioPromise = this.fetchGeminiTTS(nextItem.text);
      }
    }

    if (item.audioPromise) {
      const res = await item.audioPromise;
      if (this.cancelled) return;
      if (res.base64) {
        const ok = await this.playWavBase64(res.base64, item.text);
        if (ok) {
          if (!this.cancelled) {
            this.gapTimer = setTimeout(() => this.next(), 65);
          }
          return;
        }
      } else if (res.error && !this.noticeShown) {
        this.noticeShown = true;
        this.onTtsNotice?.(`${res.error} Using backup device voice.`);
      }
    }

    this.playDeviceSpeech(item.text);
  }

  private async playWavBase64(base64: string, text: string): Promise<boolean> {
    const bin = atob(base64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);

    const style =
      GEMINI_VOICE_STYLES.find((s) => s.id === this.settings.geminiStyleId) ||
      GEMINI_VOICE_STYLES[0];
    const userRate = clampRate(this.settings.rate || 1);
    const targetRate = clampRate(userRate * (style.pitchHint || 1.04));

    try {
      if (!this.audioCtx) {
        const AC =
          window.AudioContext ||
          (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AC) this.audioCtx = new AC();
      }
      if (this.audioCtx && this.audioCtx.state === "suspended") {
        await Promise.race([
          this.audioCtx.resume().catch(() => {}),
          new Promise<void>((r) => setTimeout(r, 600)),
        ]);
      }

      if (this.audioCtx && this.audioCtx.state === "running") {
        const audioBuf = await this.audioCtx.decodeAudioData(bytes.buffer.slice(0));
        if (this.cancelled) return true;

        const src = this.audioCtx.createBufferSource();
        src.buffer = audioBuf;
        src.playbackRate.value = targetRate;

        const brightness = this.audioCtx.createBiquadFilter();
        brightness.type = "highshelf";
        brightness.frequency.value = 3200;
        brightness.gain.value = 2.2;

        const analyser = this.audioCtx.createAnalyser();
        analyser.fftSize = 256;
        src.connect(brightness);
        brightness.connect(analyser);
        analyser.connect(this.audioCtx.destination);

        this.currentSource = src;
        this.analyser = analyser;

        const dataArray = new Uint8Array(analyser.frequencyBinCount);
        const tickEnergy = () => {
          if (!this.analyser || this.cancelled) return;
          this.analyser.getByteTimeDomainData(dataArray);
          let sum = 0;
          for (let i = 0; i < dataArray.length; i++) {
            const v = (dataArray[i] - 128) / 128;
            sum += v * v;
          }
          const rms = Math.sqrt(sum / dataArray.length);
          this.avatar?.setAudioEnergy(rms * 2.5);
          this.energyRaf = requestAnimationFrame(tickEnergy);
        };

        this.setSpeaking(true);
        this.avatar?.speakText(text, src.playbackRate.value);
        this.energyRaf = requestAnimationFrame(tickEnergy);

        return await new Promise<boolean>((resolve) => {
          src.onended = () => {
            cancelAnimationFrame(this.energyRaf);
            this.avatar?.setAudioEnergy(0);
            this.currentSource = null;
            this.analyser = null;
            resolve(true);
          };
          src.start(0);
        });
      }
    } catch {
      cancelAnimationFrame(this.energyRaf);
    }

    // Reliable fallback for Android APK / WebView / iOS standalone PWA when AudioContext is suspended
    return await this.playViaAudioElement(bytes, text, targetRate);
  }

  private async playViaAudioElement(
    bytes: Uint8Array,
    text: string,
    rate: number
  ): Promise<boolean> {
    if (typeof Audio === "undefined") return false;
    try {
      if (this.activeBlobUrl) {
        URL.revokeObjectURL(this.activeBlobUrl);
        this.activeBlobUrl = null;
      }
      const blob = new Blob([bytes.buffer as ArrayBuffer], { type: "audio/wav" });
      const url = URL.createObjectURL(blob);
      this.activeBlobUrl = url;

      if (!this.audioEl) {
        this.audioEl = new Audio();
        this.audioEl.setAttribute("playsinline", "true");
      }
      const el = this.audioEl;
      el.volume = 1;
      el.playbackRate = rate;
      el.src = url;

      const t0 = performance.now();
      const pulse = () => {
        if (this.cancelled || el.paused || el.ended) return;
        const dt = (performance.now() - t0) * 0.012;
        const e = 0.25 + 0.35 * Math.abs(Math.sin(dt) * Math.cos(dt * 0.63));
        this.avatar?.setAudioEnergy(e);
        this.energyRaf = requestAnimationFrame(pulse);
      };

      this.setSpeaking(true);
      this.avatar?.speakText(text, rate);

      return await new Promise<boolean>((resolve) => {
        let settled = false;
        const done = (ok: boolean) => {
          if (settled) return;
          settled = true;
          cancelAnimationFrame(this.energyRaf);
          this.avatar?.setAudioEnergy(0);
          el.onended = null;
          el.onerror = null;
          if (this.activeBlobUrl === url) {
            URL.revokeObjectURL(url);
            this.activeBlobUrl = null;
          }
          resolve(ok);
        };
        const guard = setTimeout(() => done(true), 22000);
        el.onended = () => {
          clearTimeout(guard);
          done(true);
        };
        el.onerror = () => {
          clearTimeout(guard);
          done(false);
        };
        el.play()
          .then(() => {
            this.energyRaf = requestAnimationFrame(pulse);
          })
          .catch(() => {
            clearTimeout(guard);
            done(false);
          });
      });
    } catch {
      return false;
    }
  }

  private playDeviceSpeech(text: string) {
    const synth = window.speechSynthesis;
    if (!synth) {
      this.setSpeaking(true);
      this.avatar?.speakText(text, 1);
      this.gapTimer = setTimeout(() => this.next(), 450 + text.length * 55);
      return;
    }

    const voices = synth.getVoices();
    const u = new SpeechSynthesisUtterance(text);
    const v = this.pickDeviceVoice(text, voices);
    if (v) {
      u.voice = v;
      u.lang = v.lang;
    } else {
      u.lang = URDU_RE.test(text) ? "ur-PK" : "en-IN";
    }

    const childHint = /\bana\b|maisie|child|kid|girl/i;
    let pitch =
      u.voice && childHint.test(u.voice.name)
        ? Math.max(1, this.settings.pitch - 0.35)
        : this.settings.pitch;
    let rate = this.settings.rate;
    const preset = VOICE_PRESETS[this.settings.preset];
    const expr = preset?.expr ?? 1;
    const q = /[?؟]\s*$/.test(text);
    const ex = /!\s*$/.test(text);
    pitch *=
      1 + (Math.random() - 0.5) * 0.07 * expr + (q ? 0.05 : 0) + (ex ? 0.04 * expr : 0);
    rate *= 1 + (Math.random() - 0.5) * 0.06 * expr + (ex ? 0.03 : 0);
    u.pitch = Math.max(0.5, Math.min(2, pitch));
    u.rate = Math.max(0.5, Math.min(1.6, rate));

    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(guard);
      if (!this.cancelled) {
        this.gapTimer = setTimeout(() => this.next(), 100 + Math.random() * 140);
      }
    };
    const guard = setTimeout(finish, 1500 + text.length * 140);

    u.onstart = () => {
      this.setSpeaking(true);
      this.avatar?.speakText(text, u.rate);
    };
    u.onboundary = (e) => {
      if (e.name !== "sentence") this.avatar?.wordBoundary(e.charIndex, e.charLength);
    };
    u.onend = finish;
    u.onerror = finish;

    this.setSpeaking(true);
    this.avatar?.speakText(text, u.rate);
    synth.speak(u);
  }

  private pickDeviceVoice(
    text: string,
    voices: SpeechSynthesisVoice[]
  ): SpeechSynthesisVoice | null {
    if (this.settings.voiceURI) {
      const exact = voices.find((x) => x.voiceURI === this.settings.voiceURI);
      if (exact) return exact;
    }
    const urdu = URDU_RE.test(text);
    const hasUrdu = voices.some((v) => v.lang.toLowerCase().startsWith("ur"));
    const preset = VOICE_PRESETS[this.settings.preset];
    if (preset) {
      const pv = presetVoice(preset, voices);
      if (pv && !(urdu && hasUrdu && !/^(ur|hi)/i.test(pv.lang))) return pv;
    }
    const ok = voices.filter((v) => /^(ur|hi|en)/i.test(v.lang));
    if (!ok.length) return null;
    const score = (v: SpeechSynthesisVoice) => {
      const l = v.lang.toLowerCase();
      const langPts = urdu
        ? l.startsWith("ur")
          ? 40
          : l.startsWith("hi")
            ? 20
            : 0
        : l.startsWith("ur")
          ? 30
          : l.startsWith("en")
            ? 26
            : l.startsWith("hi")
              ? 22
              : 0;
      const natural = /natural|neural|online|premium|enhanced|wavenet|google/i.test(v.name)
        ? 12
        : 0;
      const child = /\bana\b|maisie|child|kid|girl/i.test(v.name) ? 10 : 0;
      const female =
        /female|woman|girl|child|kid|ana\b|zira|samantha|heera|swara|neerja|uzma|salma|aria|jenny/i.test(
          v.name
        )
          ? 6
          : 0;
      return langPts + natural + child + female;
    };
    return ok.sort((a, b) => score(b) - score(a))[0];
  }

  private setSpeaking(on: boolean) {
    this.avatar?.setSpeaking(on);
    this.onSpeakingChange(on);
  }

  stop() {
    this.cancelled = true;
    this.queue = [];
    if (this.gapTimer) clearTimeout(this.gapTimer);
    cancelAnimationFrame(this.energyRaf);
    try {
      this.currentSource?.stop();
    } catch {}
    this.currentSource = null;
    this.analyser = null;
    if (this.audioEl) {
      try {
        this.audioEl.pause();
        this.audioEl.currentTime = 0;
      } catch {}
    }
    if (this.activeBlobUrl) {
      URL.revokeObjectURL(this.activeBlobUrl);
      this.activeBlobUrl = null;
    }
    window.speechSynthesis?.cancel();
    this.active = false;
    this.fresh = true;
    this.setSpeaking(false);
  }
}

function clampRate(v: number): number {
  return Math.min(1.28, Math.max(0.8, v));
}

export function createSentenceStreamer(speech: SpeechController) {
  let pending = "";
  let pendingTags: GestureName[] = [];

  const emit = (chunk: string) => {
    const tags = [...pendingTags, ...extractTags(chunk)];
    pendingTags = [];
    const clean = stripTags(chunk);
    if (!clean && tags.length) {
      pendingTags.push(...tags);
      return;
    }
    speech.push(clean, tags.slice(0, 4));
  };

  return {
    feed(piece: string, final = false) {
      pending += piece;
      const re = /^([\s\S]*?[.!?۔؟\n]+)(\s+)/;
      let m: RegExpMatchArray | null;
      while ((m = pending.match(re))) {
        emit(m[1]);
        pending = pending.slice(m[0].length);
      }
      if (final) {
        if (pending.trim()) emit(pending);
        pending = "";
        if (pendingTags.length) speech.push("", pendingTags);
        pendingTags = [];
      }
    },
  };
}
