import type { GeminiVoiceStyle, VoicePreset } from "../types/noor";

const BABY_GIRL_NAMES = [
  "Noor", "Haram", "Aiza", "Hoorain", "Anaya", "Fatima", "Maryam", "Ayesha", "Hania", "Inaya",
  "Zara", "Mahnoor", "Zoya", "Alishba", "Eman", "Haya", "Minahil", "Rida", "Areeba", "Iqra",
  "Laiba", "Sana", "Mehak", "Pari", "Gul", "Rania", "Dua", "Abeeha", "Aleena", "Amna",
  "Arwa", "Hiba", "Hoor", "Jannat", "Khadija", "Kinza", "Manahil", "Mishal", "Nimra", "Rumaisa",
  "Sara", "Shanzay", "Sidra", "Sumaira", "Tooba", "Umama", "Wajeeha", "Yusra", "Zainab", "Zunaira",
];

const BABY_PERSONAS: Array<{
  tag: string;
  category: string;
  voiceName: "Kore" | "Zephyr" | "Puck";
  prompt: string;
  desc: string;
  pitchHint: number;
}> = [
  {
    tag: "Nanhi Doctor",
    category: "Sweet Care",
    voiceName: "Kore",
    prompt:
      "Adorable, tender 4-year-old baby girl doctor speaking softly with natural childlike innocence, gentle smile, warm breathing, and natural Urdu and English pronunciation, never robotic",
    desc: "Warm, gentle 4-year-old baby doctor voice for everyday care",
    pitchHint: 1.04,
  },
  {
    tag: "Meethi Pari",
    category: "Affectionate",
    voiceName: "Zephyr",
    prompt:
      "Very sweet, bright, affectionate 5-year-old little girl with a crystal-clear airy child voice, smiling happily and speaking lovingly to her parents and family",
    desc: "Sweet, bright, loving child tone for family moments",
    pitchHint: 1.06,
  },
  {
    tag: "Chulbuli",
    category: "Playful",
    voiceName: "Zephyr",
    prompt:
      "Cheerful, bubbly, playful 4-year-old little girl giggling lightly with joyful high-spirited child energy and lively inflection",
    desc: "Bubbly & cheerful voice for playtime, games, and dancing",
    pitchHint: 1.07,
  },
  {
    tag: "Masoom",
    category: "Gentle & Pure",
    voiceName: "Kore",
    prompt:
      "Innocent, soft-spoken, heartfelt 4-year-old little girl speaking tenderly with sincerity, gentle pauses, and soothing childlike warmth",
    desc: "Soft, innocent tone for comforting moments",
    pitchHint: 1.03,
  },
  {
    tag: "Dua & Lori",
    category: "Bedtime & Dua",
    voiceName: "Kore",
    prompt:
      "Calm, soothing, sleepy-sweet 5-year-old little girl gently reciting a loving prayer or bedtime story with peaceful softness",
    desc: "Peaceful, tender tone for duas and bedtime stories",
    pitchHint: 1.01,
  },
  {
    tag: "Hoshiyar Clinic",
    category: "Doctor Checkup",
    voiceName: "Puck",
    prompt:
      "Bright, expressive, caring 5-year-old girl pretending to be a helpful little pediatrician checking a heartbeat, clear articulation, warm encouraging smile",
    desc: "Clear & caring voice for medicine and health checkups",
    pitchHint: 1.04,
  },
  {
    tag: "Gudiya",
    category: "Cuddly",
    voiceName: "Zephyr",
    prompt:
      "Tiny, cute, affectionate 4-year-old girl with a cozy, soft, hugging tone, full of love and warmth",
    desc: "Cozy, cuddly little-girl voice",
    pitchHint: 1.08,
  },
  {
    tag: "Khushbu",
    category: "Joyful",
    voiceName: "Puck",
    prompt:
      "Happy, sparkling, smiling 5-year-old little girl full of curiosity and kindness, speaking expressively and naturally",
    desc: "Bright, curious, happy voice",
    pitchHint: 1.05,
  },
  {
    tag: "Sitara",
    category: "Storyteller",
    voiceName: "Kore",
    prompt:
      "Wonder-filled, expressive 5-year-old little girl narrating an exciting story with gentle musical rhythm and expressive childlike charm",
    desc: "Expressive storyteller tone",
    pitchHint: 1.03,
  },
  {
    tag: "Pyari Noor",
    category: "Heartfelt",
    voiceName: "Zephyr",
    prompt:
      "Deeply loving, sincere, warm 4-year-old baby girl speaking directly from the heart to her Ammi and Abbu with natural human emotion and softness",
    desc: "Deeply affectionate family-heart voice",
    pitchHint: 1.05,
  },
];

// 100 curated real baby-girl expressive styles powered by Gemini 3.8 Flash TTS
export const GEMINI_VOICE_STYLES: GeminiVoiceStyle[] = Array.from({ length: 100 }, (_, i) => {
  const persona = BABY_PERSONAS[i % BABY_PERSONAS.length];
  const girlName = BABY_GIRL_NAMES[Math.floor(i / BABY_PERSONAS.length) * 5 + (i % 5)] ||
    BABY_GIRL_NAMES[i % BABY_GIRL_NAMES.length];
  const nuance =
    i < 10
      ? "Signature"
      : i < 30
        ? "Extra Sweet"
        : i < 50
          ? "Playful & Bright"
          : i < 75
            ? "Soft & Caring"
            : "Story & Dua";

  return {
    id: `baby-${String(i + 1).padStart(3, "0")}`,
    index: i + 1,
    label: `${persona.tag} ${girlName} (#${i + 1})`,
    category: `${persona.category} · ${nuance}`,
    voiceName: persona.voiceName,
    stylePrompt: `${persona.prompt}. Voice nuance: ${nuance.toLowerCase()}, natural human pacing, real child emotion.`,
    description: persona.desc,
    pitchHint: persona.pitchHint,
  };
});

// Device offline fallback voices (used only when internet is unavailable or user selects Device Offline Voice)
const NAMES = BABY_GIRL_NAMES;

const STYLES: Array<[string, string, number, number, number]> = [
  ["Meethi", "🍬", 1.62, 1.0, 1.0],
  ["Chulbuli", "🎀", 1.78, 1.08, 1.5],
  ["Sharmeeli", "🌸", 1.55, 0.9, 0.6],
  ["Nanhi", "🐣", 1.9, 0.95, 1.1],
  ["Gudiya", "🧸", 1.72, 1.0, 1.2],
  ["Pyari", "💖", 1.6, 0.97, 1.0],
  ["Masoom", "👼", 1.68, 0.88, 0.8],
  ["Shararti", "😜", 1.75, 1.12, 1.7],
  ["Khush", "😄", 1.7, 1.06, 1.4],
  ["Narm", "☁️", 1.45, 0.86, 0.5],
  ["Titli", "🦋", 1.82, 1.04, 1.3],
  ["Chirya", "🐦", 1.95, 1.1, 1.4],
  ["Shehzadi", "👑", 1.58, 0.94, 0.9],
  ["Pari", "🧚", 1.85, 0.98, 1.2],
  ["Lori", "🌙", 1.42, 0.82, 0.4],
  ["Phool", "🌷", 1.64, 0.96, 1.0],
  ["Sitara", "⭐", 1.76, 1.02, 1.2],
  ["Hoshiyar", "📚", 1.52, 1.04, 0.9],
  ["Jugnu", "✨", 1.88, 1.07, 1.5],
  ["Chandni", "🌟", 1.5, 0.92, 0.7],
];

const jitter = (i: number, k: number) =>
  (((Math.sin(i * 12.9898 + k * 78.233) * 43758.5453) % 1) + 1) % 1;

export const VOICE_PRESETS: VoicePreset[] = Array.from({ length: 100 }, (_, i) => {
  const [style, emoji, pitch, rate, expr] = STYLES[i % STYLES.length];
  const name = NAMES[Math.floor(i / STYLES.length) % NAMES.length];
  return {
    id: i,
    name: `${style} ${name}`,
    emoji,
    pitch: +Math.min(2, Math.max(1.2, pitch + (jitter(i, 1) - 0.5) * 0.24)).toFixed(2),
    rate: +Math.min(1.25, Math.max(0.78, rate + (jitter(i, 2) - 0.5) * 0.14)).toFixed(2),
    expr: +(expr * (0.8 + jitter(i, 3) * 0.4)).toFixed(2),
    voiceSlot: Math.floor(i / STYLES.length),
  };
});

const femaleRe =
  /female|woman|girl|child|kid|\bana\b|zira|samantha|heera|kalpana|swara|neerja|uzma|salma|aditi|veena|priya|aria|jenny|ava|emma|sonia|libby|maisie|natasha|clara|sara|zoe|karen|moira|tessa|fiona|victoria|google/i;
const maleRe =
  /\bmale\b|\bman\b|david|mark|guy|ravi|hemant|asad|prabhat|george|daniel|james|ryan|thomas|brian|eric|christopher|andrew|roger|steffan/i;
const naturalRe = /natural|neural|online|premium|enhanced|wavenet|google/i;
const childRe = /\bana\b|maisie|child|kid|girl/i;

export function girlVoices(voices: SpeechSynthesisVoice[]): SpeechSynthesisVoice[] {
  const ok = voices.filter((v) => /^(ur|hi|en|pa|bn)/i.test(v.lang) && !maleRe.test(v.name));
  const list = ok.length ? ok : voices;
  const score = (v: SpeechSynthesisVoice) => {
    const l = v.lang.toLowerCase();
    return (
      (childRe.test(v.name) ? 40 : 0) +
      (naturalRe.test(v.name) ? 20 : 0) +
      (femaleRe.test(v.name) ? 15 : 0) +
      (l.startsWith("ur") ? 10 : l.startsWith("hi") ? 8 : l.startsWith("en") ? 6 : 0)
    );
  };
  return [...list].sort((a, b) => score(b) - score(a));
}

export function presetVoice(
  preset: VoicePreset,
  voices: SpeechSynthesisVoice[]
): SpeechSynthesisVoice | null {
  const list = girlVoices(voices);
  if (!list.length) return null;
  return list[preset.voiceSlot % list.length];
}
