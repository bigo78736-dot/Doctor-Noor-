import { useCallback, useEffect, useRef, useState } from "react";
import type { User } from "firebase/auth";
import {
  BookOpen,
  ClipboardList,
  Globe,
  Heart,
  Lock,
  MapPin,
  MessageCircle,
  Settings,
  Stethoscope,
  Unlock,
  WifiOff,
  X,
} from "lucide-react";
import { ChatPanel } from "./components/ChatPanel";
import { ClinicPanel } from "./components/ClinicPanel";
import { DiaryPanel } from "./components/DiaryPanel";
import { FloatingDock } from "./components/FloatingDock";
import { LivingStage } from "./components/LivingStage";
import { PWAInstallButton } from "./components/PWAInstallButton";
import { SettingsModal } from "./components/SettingsModal";
import { StoriesDuaPanel } from "./components/StoriesDuaPanel";
import { WorldToolsPanel } from "./components/WorldToolsPanel";
import {
  downloadAutoSaveBackup,
  loadSnapshotFromDb,
  saveSnapshotToDb,
  type NoorBackupBundle,
} from "./lib/autoSave";
import { downloadPortableAppFile, sharePortableApp } from "./lib/appPackager";
import type { AvatarEngine } from "./lib/avatarEngine";
import { commandReply, detectCommands, detectLang, isCommand, offlineReply } from "./lib/brain";
import {
  clearCloudMessages,
  createFamilyRoom,
  deleteCloudDiaryEntry,
  deleteCloudReminder,
  deleteCloudReport,
  deleteCloudVital,
  ensureCloudWorkspace,
  joinFamilyRoom,
  leaveFamilyRoom,
  normalizeRoomCode,
  pushCloudMessage,
  saveCloudDiaryEntry,
  saveCloudReminder,
  saveCloudReport,
  saveCloudVital,
  signInCloudSync,
  signOutCloudSync,
  subscribeAuthUser,
  subscribeCloudWorkspace,
  subscribeFamilyRoom,
  syncRoomChannel,
  syncWorkspaceToCloud,
} from "./lib/cloudSync";
import { BUNDLED_PIN_CHECK, DEFAULT_PROFILE, DEFAULT_SETTINGS, hashPin } from "./lib/constants";
import { LiveCallClient } from "./lib/liveCallClient";
import { SpeechController, createSentenceStreamer, extractTags, stripTags } from "./lib/speechController";
import { GEMINI_VOICE_STYLES } from "./lib/voices";
import type {
  AiVitalState,
  ChatMessage,
  DiaryEntry,
  FamilyRoomConfig,
  GestureName,
  GroundingSource,
  MedReminder,
  MedicalReportRecord,
  NoorProfile,
  VitalRecord,
  VoiceSettings,
} from "./types/noor";

type DrawerPanel = "chat" | "clinic" | "world" | "diary" | "stories" | null;

function mergeBrothersMemory(p: NoorProfile): NoorProfile {
  let about = p.about || DEFAULT_PROFILE.about;
  let familyNotes = p.familyNotes || DEFAULT_PROFILE.familyNotes;
  if (!/ayan\s*ali/i.test(about) || !/muhammad/i.test(about)) {
    about = `${about.trim()} Permanently remembers her dear brothers Ayan Ali bhai and Muhammad bhai.`.trim();
  }
  if (!/ayan\s*ali/i.test(familyNotes) || !/muhammad/i.test(familyNotes)) {
    familyNotes = `${familyNotes.trim()} Always remembers her beloved brothers Ayan Ali bhai and Muhammad bhai warmly by name.`.trim();
  }
  return { ...p, about, familyNotes };
}

function loadProfile(): NoorProfile {
  try {
    const raw = localStorage.getItem("noor.profile");
    return mergeBrothersMemory(
      raw ? ({ ...DEFAULT_PROFILE, ...JSON.parse(raw) } as NoorProfile) : DEFAULT_PROFILE
    );
  } catch {
    return DEFAULT_PROFILE;
  }
}

function loadSettings(): VoiceSettings {
  try {
    const raw = localStorage.getItem("noor.settings");
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = { ...DEFAULT_SETTINGS, ...JSON.parse(raw) } as VoiceSettings;
    if (!GEMINI_VOICE_STYLES.some((v) => v.id === parsed.geminiStyleId)) {
      parsed.geminiStyleId = DEFAULT_SETTINGS.geminiStyleId;
    }
    return parsed;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function loadHistory(): ChatMessage[] {
  try {
    const raw = localStorage.getItem("noor.history");
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function loadReminders(): MedReminder[] {
  try {
    const raw = localStorage.getItem("noor.reminders");
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function loadDiary(): DiaryEntry[] {
  try {
    const raw = localStorage.getItem("noor.diary");
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function loadVitals(): VitalRecord[] {
  try {
    const raw = localStorage.getItem("noor.vitals");
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function loadReports(): MedicalReportRecord[] {
  try {
    const raw = localStorage.getItem("noor.reports");
    const arr = raw ? JSON.parse(raw) : [];
    return Array.isArray(arr) ? arr : [];
  } catch {
    return [];
  }
}

function loadFamilyRoom(): FamilyRoomConfig | null {
  try {
    const raw = localStorage.getItem("noor.familyRoom");
    if (!raw) return null;
    const parsed = JSON.parse(raw) as FamilyRoomConfig;
    if (parsed && parsed.roomCode && parsed.passcode) return parsed;
    return null;
  } catch {
    return null;
  }
}

export default function App() {
  const [profile, setProfile] = useState<NoorProfile>(loadProfile);
  const [settings, setSettings] = useState<VoiceSettings>(loadSettings);
  const [history, setHistory] = useState<ChatMessage[]>(loadHistory);
  const [reminders, setReminders] = useState<MedReminder[]>(loadReminders);
  const [diaryEntries, setDiaryEntries] = useState<DiaryEntry[]>(loadDiary);
  const [vitals, setVitals] = useState<VitalRecord[]>(loadVitals);
  const [reports, setReports] = useState<MedicalReportRecord[]>(loadReports);
  const [activeRoom, setActiveRoom] = useState<FamilyRoomConfig | null>(loadFamilyRoom);
  const [roomBusy, setRoomBusy] = useState(false);
  const [familyMode, setFamilyMode] = useState<boolean>(
    () => localStorage.getItem("noor.family") === "1"
  );
  const [customPinHash, setCustomPinHash] = useState<string>(
    () => localStorage.getItem("noor.customPinHash") || ""
  );

  const [started, setStarted] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isBusy, setIsBusy] = useState(false);
  const [isMicListening, setIsMicListening] = useState(false);
  const [caption, setCaption] = useState("");
  const [heardText, setHeardText] = useState("");
  const [drawer, setDrawer] = useState<DrawerPanel>(null);
  const [clinicSubTab, setClinicSubTab] = useState<
    "medicine" | "nearby" | "heart" | "vision" | "triage" | "safety"
  >("medicine");
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [mapsQuotaExceeded, setMapsQuotaExceeded] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [pinModalOpen, setPinModalOpen] = useState(false);
  const [pinInput, setPinInput] = useState("");
  const [pinError, setPinError] = useState("");
  const [isOnline, setIsOnline] = useState(
    typeof navigator !== "undefined" ? navigator.onLine : true
  );
  const [toastMsg, setToastMsg] = useState("");

  // Gemini Live real-time call state
  const [liveCallStatus, setLiveCallStatus] = useState<"ended" | "connecting" | "connected">(
    "ended"
  );
  const [liveVideoOn, setLiveVideoOn] = useState(false);

  // Firebase Multi-Device Cloud Sync state
  const [cloudUser, setCloudUser] = useState<User | null>(null);
  const [cloudSyncStatus, setCloudSyncStatus] = useState<
    "signed_out" | "syncing" | "synced" | "error"
  >("signed_out");

  const toastTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const avatarRef = useRef<AvatarEngine | null>(null);
  const speechRef = useRef<SpeechController | null>(null);
  const liveClientRef = useRef<LiveCallClient | null>(null);
  const liveVideoRef = useRef<HTMLVideoElement | null>(null);
  const liveVideoStreamRef = useRef<MediaStream | null>(null);
  const serverAppUrlRef = useRef<string>("");
  const startedRef = useRef(started);
  startedRef.current = started;

  const isRemoteSyncRef = useRef(false);
  const isRoomSyncRef = useRef(false);
  const cloudWorkspaceReadyRef = useRef(false);
  const pendingRoomInviteRef = useRef<{ roomCode: string; passcode: string } | null>(null);
  const profileRef = useRef(profile);
  profileRef.current = profile;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;
  const activeRoomRef = useRef(activeRoom);
  activeRoomRef.current = activeRoom;
  const historyRef = useRef(history);
  historyRef.current = history;
  const remindersRef = useRef(reminders);
  remindersRef.current = reminders;
  const diaryRef = useRef(diaryEntries);
  diaryRef.current = diaryEntries;
  const vitalsRef = useRef(vitals);
  vitalsRef.current = vitals;
  const reportsRef = useRef(reports);
  reportsRef.current = reports;

  const chatHistory = history;

  const showToast = useCallback((msg: string) => {
    setToastMsg(msg);
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    toastTimerRef.current = setTimeout(() => setToastMsg(""), 4200);
  }, []);

  if (!speechRef.current) {
    speechRef.current = new SpeechController(
      settings,
      (speaking) => setIsSpeaking(speaking),
      (notice) => showToast(notice)
    );
  }

  const idbHydratedRef = useRef(false);
  const authUserNoticeShownRef = useRef(false);

  useEffect(() => {
    fetch("/api/health")
      .then((r) => r.json())
      .then((d) => {
        const publicUrl =
          (typeof d?.sharedAppUrl === "string" && d.sharedAppUrl) ||
          (typeof d?.appUrl === "string" ? d.appUrl.replace("://ais-dev-", "://ais-pre-") : "");
        if (publicUrl) {
          serverAppUrlRef.current = publicUrl;
        }
      })
      .catch(() => {});

    // Detect shared ?room=...&key=... family room invite in URL
    try {
      const params = new URLSearchParams(window.location.search);
      const roomParam = normalizeRoomCode(params.get("room") || "");
      const keyParam = (params.get("key") || "").trim().slice(0, 32);
      if (roomParam && keyParam.length >= 4) {
        pendingRoomInviteRef.current = { roomCode: roomParam, passcode: keyParam };
        if (!authUserNoticeShownRef.current) {
          authUserNoticeShownRef.current = true;
          showToast(
            `Family Room ${roomParam} invite detected — sign in with Google in Settings to sync live!`
          );
        }
      }
    } catch {}

    const onQuota = () => setMapsQuotaExceeded(true);
    window.addEventListener("gmp-quota-exceeded", onQuota);
    return () => window.removeEventListener("gmp-quota-exceeded", onQuota);
  }, [showToast]);

  // Hydrate from IndexedDB auto-save on initial load if localStorage was cleared
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const [dbProfile, dbSettings, dbHistory, dbReminders, dbDiary, dbVitals, dbReports] =
          await Promise.all([
            loadSnapshotFromDb<NoorProfile>("noor.profile"),
            loadSnapshotFromDb<VoiceSettings>("noor.settings"),
            loadSnapshotFromDb<ChatMessage[]>("noor.history"),
            loadSnapshotFromDb<MedReminder[]>("noor.reminders"),
            loadSnapshotFromDb<DiaryEntry[]>("noor.diary"),
            loadSnapshotFromDb<VitalRecord[]>("noor.vitals"),
            loadSnapshotFromDb<MedicalReportRecord[]>("noor.reports"),
          ]);
        if (cancelled) return;
        if (!localStorage.getItem("noor.profile") && dbProfile) {
          setProfile(mergeBrothersMemory({ ...DEFAULT_PROFILE, ...dbProfile }));
        }
        if (!localStorage.getItem("noor.settings") && dbSettings) {
          setSettings({ ...DEFAULT_SETTINGS, ...dbSettings });
        }
        if (!localStorage.getItem("noor.history") && Array.isArray(dbHistory) && dbHistory.length) {
          setHistory(dbHistory);
        }
        if (!localStorage.getItem("noor.reminders") && Array.isArray(dbReminders) && dbReminders.length) {
          setReminders(dbReminders);
        }
        if (!localStorage.getItem("noor.diary") && Array.isArray(dbDiary) && dbDiary.length) {
          setDiaryEntries(dbDiary);
        }
        if (!localStorage.getItem("noor.vitals") && Array.isArray(dbVitals) && dbVitals.length) {
          setVitals(dbVitals);
        }
        if (!localStorage.getItem("noor.reports") && Array.isArray(dbReports) && dbReports.length) {
          setReports(dbReports);
        }
      } finally {
        idbHydratedRef.current = true;
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    speechRef.current?.updateSettings(settings);
    try {
      localStorage.setItem("noor.settings", JSON.stringify(settings));
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.settings", settings);
  }, [settings]);

  useEffect(() => {
    try {
      localStorage.setItem("noor.profile", JSON.stringify(profile));
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.profile", profile);
  }, [profile]);

  useEffect(() => {
    const trimmed = chatHistory.slice(-80);
    try {
      localStorage.setItem("noor.history", JSON.stringify(trimmed));
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.history", trimmed);
  }, [chatHistory]);

  useEffect(() => {
    try {
      localStorage.setItem("noor.reminders", JSON.stringify(reminders));
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.reminders", reminders);
  }, [reminders]);

  useEffect(() => {
    const trimmed = diaryEntries.slice(0, 100);
    try {
      localStorage.setItem("noor.diary", JSON.stringify(trimmed));
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.diary", trimmed);
  }, [diaryEntries]);

  useEffect(() => {
    const trimmed = vitals.slice(0, 100);
    try {
      localStorage.setItem("noor.vitals", JSON.stringify(trimmed));
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.vitals", trimmed);
  }, [vitals]);

  useEffect(() => {
    const trimmed = reports.slice(0, 50);
    try {
      localStorage.setItem("noor.reports", JSON.stringify(trimmed));
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.reports", trimmed);
  }, [reports]);

  useEffect(() => {
    try {
      if (activeRoom) {
        localStorage.setItem("noor.familyRoom", JSON.stringify(activeRoom));
      } else {
        localStorage.removeItem("noor.familyRoom");
      }
    } catch {}
  }, [activeRoom]);

  useEffect(() => {
    try {
      localStorage.setItem("noor.family", familyMode ? "1" : "0");
    } catch {}
    if (idbHydratedRef.current) saveSnapshotToDb("noor.family", familyMode);
  }, [familyMode]);

  // Firebase Auth & Real-Time Firestore Multi-Phone Cloud Sync
  useEffect(() => {
    let unsubCloud: (() => void) | null = null;
    let cancelled = false;

    const unsubAuth = subscribeAuthUser(async (user) => {
      unsubCloud?.();
      unsubCloud = null;
      cloudWorkspaceReadyRef.current = false;

      if (!user) {
        setCloudUser(null);
        setCloudSyncStatus("signed_out");
        return;
      }

      setCloudUser(user);
      setCloudSyncStatus("syncing");
      try {
        await ensureCloudWorkspace(user.uid, profileRef.current, settingsRef.current);
        if (cancelled) return;
        cloudWorkspaceReadyRef.current = true;

        unsubCloud = subscribeCloudWorkspace(user.uid, {
          onWorkspace: (data) => {
            isRemoteSyncRef.current = true;
            setProfile((prev) =>
              mergeBrothersMemory({
                ...prev,
                name: data.name || prev.name,
                about: data.about || prev.about,
                familyNotes:
                  typeof data.familyNotes === "string" ? data.familyNotes : prev.familyNotes,
                bodyMode: typeof data.bodyMode === "boolean" ? data.bodyMode : prev.bodyMode,
              })
            );
            setSettings((prev) => ({
              ...prev,
              lang: data.lang || prev.lang,
              stt: data.stt || prev.stt,
              geminiStyleId: GEMINI_VOICE_STYLES.some((v) => v.id === data.geminiStyleId)
                ? data.geminiStyleId
                : prev.geminiStyleId,
            }));
            setCloudSyncStatus("synced");
            setTimeout(() => {
              isRemoteSyncRef.current = false;
            }, 80);
          },
          onMessages: (remoteMsgs) => {
            if (remoteMsgs.length === 0) return;
            setHistory((prev) => {
              const mergedMap = new Map<string, ChatMessage>();
              for (const m of prev) mergedMap.set(m.id, m);
              for (const m of remoteMsgs) mergedMap.set(m.id, m);
              return Array.from(mergedMap.values())
                .sort((a, b) => a.timestamp - b.timestamp)
                .slice(-80);
            });
          },
          onReminders: (remoteRems) => {
            setReminders((prev) => {
              if (remoteRems.length === 0 && prev.length > 0) return prev;
              const prevDates = new Map(prev.map((r) => [r.id, r.lastTriggeredDate]));
              return remoteRems.map((r) => ({
                ...r,
                lastTriggeredDate: prevDates.get(r.id) || r.lastTriggeredDate,
              }));
            });
          },
          onDiary: (remoteDiary) => {
            setDiaryEntries((prev) => {
              if (remoteDiary.length === 0 && prev.length > 0) return prev;
              return remoteDiary;
            });
          },
          onVitals: (remoteVitals) => {
            setVitals((prev) => {
              if (remoteVitals.length === 0 && prev.length > 0) return prev;
              return remoteVitals;
            });
          },
          onReports: (remoteReports) => {
            setReports((prev) => {
              if (remoteReports.length === 0 && prev.length > 0) return prev;
              return remoteReports;
            });
          },
        });
        setCloudSyncStatus("synced");

        // Auto-join pending shared Family Room invite URL if present
        const invite = pendingRoomInviteRef.current;
        if (invite) {
          pendingRoomInviteRef.current = null;
          if (activeRoomRef.current?.roomCode !== invite.roomCode) {
            try {
              const joined = await joinFamilyRoom(
                user.uid,
                user.displayName || profileRef.current.name,
                invite.roomCode,
                invite.passcode
              );
              if (!cancelled) {
                setActiveRoom(joined);
                showToast(`Joined Shared Family Room ${joined.roomCode}!`);
                try {
                  const cleanUrl = new URL(window.location.href);
                  cleanUrl.searchParams.delete("room");
                  cleanUrl.searchParams.delete("key");
                  window.history.replaceState({}, "", cleanUrl.toString());
                } catch {}
              }
            } catch (err) {
              const msg = err instanceof Error ? err.message : "Could not join shared room.";
              if (!cancelled) showToast(msg);
            }
          }
        }
      } catch {
        if (!cancelled) setCloudSyncStatus("error");
      }
    });

    return () => {
      cancelled = true;
      unsubCloud?.();
      unsubAuth();
    };
  }, [showToast]);

  // Debounced sync of workspace profile & voice settings changes to Firestore
  useEffect(() => {
    if (!cloudUser || !cloudWorkspaceReadyRef.current || isRemoteSyncRef.current) return;
    const t = setTimeout(() => {
      void syncWorkspaceToCloud(cloudUser.uid, profile, settings).catch(() => {});
    }, 700);
    return () => clearTimeout(t);
  }, [cloudUser, profile, settings]);

  // Subscribe to Multi-Phone Shared Family Room live channels
  useEffect(() => {
    if (!cloudUser || !activeRoom?.roomCode) return;

    const clearRoomFlagSoon = () => {
      setTimeout(() => {
        isRoomSyncRef.current = false;
      }, 120);
    };

    const unsub = subscribeFamilyRoom(activeRoom.roomCode, cloudUser.uid, {
      onChat: (remoteMsgs) => {
        if (!remoteMsgs.length) return;
        isRoomSyncRef.current = true;
        setHistory((prev) => {
          const map = new Map<string, ChatMessage>();
          for (const m of prev) map.set(m.id, m);
          for (const m of remoteMsgs) map.set(m.id, m);
          return Array.from(map.values())
            .sort((a, b) => a.timestamp - b.timestamp)
            .slice(-80);
        });
        clearRoomFlagSoon();
      },
      onReminders: (remoteRems) => {
        isRoomSyncRef.current = true;
        setReminders((prev) => {
          const prevDates = new Map(prev.map((r) => [r.id, r.lastTriggeredDate]));
          return remoteRems.map((r) => ({
            ...r,
            lastTriggeredDate: prevDates.get(r.id) || r.lastTriggeredDate,
          }));
        });
        clearRoomFlagSoon();
      },
      onDiary: (remoteEntries) => {
        isRoomSyncRef.current = true;
        setDiaryEntries(remoteEntries);
        clearRoomFlagSoon();
      },
      onVitals: (remoteVitals) => {
        isRoomSyncRef.current = true;
        setVitals(remoteVitals);
        clearRoomFlagSoon();
      },
      onReports: (remoteReports) => {
        isRoomSyncRef.current = true;
        setReports(remoteReports);
        clearRoomFlagSoon();
      },
    });

    return () => unsub();
  }, [cloudUser, activeRoom?.roomCode]);

  // Broadcast local updates to active Shared Family Room (guarded against remote echo)
  useEffect(() => {
    if (!cloudUser || !activeRoom?.roomCode || isRoomSyncRef.current) return;
    const t = setTimeout(() => {
      void syncRoomChannel(
        cloudUser.uid,
        cloudUser.displayName || profileRef.current.name,
        activeRoom.roomCode,
        "chat",
        history.slice(-50)
      ).catch(() => {});
    }, 350);
    return () => clearTimeout(t);
  }, [cloudUser, activeRoom?.roomCode, history]);

  useEffect(() => {
    if (!cloudUser || !activeRoom?.roomCode || isRoomSyncRef.current) return;
    const t = setTimeout(() => {
      void syncRoomChannel(
        cloudUser.uid,
        cloudUser.displayName || profileRef.current.name,
        activeRoom.roomCode,
        "reminders",
        reminders.slice(0, 60)
      ).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [cloudUser, activeRoom?.roomCode, reminders]);

  useEffect(() => {
    if (!cloudUser || !activeRoom?.roomCode || isRoomSyncRef.current) return;
    const t = setTimeout(() => {
      void syncRoomChannel(
        cloudUser.uid,
        cloudUser.displayName || profileRef.current.name,
        activeRoom.roomCode,
        "diary",
        diaryEntries.slice(0, 60)
      ).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [cloudUser, activeRoom?.roomCode, diaryEntries]);

  useEffect(() => {
    if (!cloudUser || !activeRoom?.roomCode || isRoomSyncRef.current) return;
    const t = setTimeout(() => {
      void syncRoomChannel(
        cloudUser.uid,
        cloudUser.displayName || profileRef.current.name,
        activeRoom.roomCode,
        "vitals",
        vitals.slice(0, 60)
      ).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [cloudUser, activeRoom?.roomCode, vitals]);

  useEffect(() => {
    if (!cloudUser || !activeRoom?.roomCode || isRoomSyncRef.current) return;
    const t = setTimeout(() => {
      void syncRoomChannel(
        cloudUser.uid,
        cloudUser.displayName || profileRef.current.name,
        activeRoom.roomCode,
        "reports",
        reports.slice(0, 30)
      ).catch(() => {});
    }, 300);
    return () => clearTimeout(t);
  }, [cloudUser, activeRoom?.roomCode, reports]);

  useEffect(() => {
    const onOnline = () => setIsOnline(true);
    const onOffline = () => setIsOnline(false);
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setDrawer(null);
    };
    window.addEventListener("online", onOnline);
    window.addEventListener("offline", onOffline);
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("online", onOnline);
      window.removeEventListener("offline", onOffline);
      window.removeEventListener("keydown", onKey);
    };
  }, []);

  const stopLiveVideoStream = useCallback(() => {
    liveClientRef.current?.attachVideoElement(null);
    liveVideoStreamRef.current?.getTracks().forEach((t) => t.stop());
    liveVideoStreamRef.current = null;
    if (liveVideoRef.current) {
      liveVideoRef.current.srcObject = null;
    }
    setLiveVideoOn(false);
  }, []);

  useEffect(() => {
    return () => {
      liveClientRef.current?.stop();
      stopLiveVideoStream();
    };
  }, [stopLiveVideoStream]);

  const handleAvatarReady = useCallback((engine: AvatarEngine | null) => {
    avatarRef.current = engine;
    speechRef.current?.attachAvatar(engine);
    liveClientRef.current?.attachAvatar(engine);
  }, []);

  const speakImmediate = useCallback((taggedText: string) => {
    const speech = speechRef.current;
    if (!speech) return;
    setStarted(true);
    speech.unlockAudio();
    speech.stop();
    const streamer = createSentenceStreamer(speech);
    streamer.feed(taggedText, true);
    setCaption(stripTags(taggedText));
  }, []);

  // Scheduled daily medicine / dua reminder check every 15 seconds
  useEffect(() => {
    const id = setInterval(() => {
      const now = new Date();
      const hh = String(now.getHours()).padStart(2, "0");
      const mm = String(now.getMinutes()).padStart(2, "0");
      const hhmm = `${hh}:${mm}`;
      const today = now.toISOString().slice(0, 10);

      setReminders((prev) => {
        let changed = false;
        const dueItems: MedReminder[] = [];
        const updated = prev.map((r) => {
          if (r.enabled && r.time === hhmm && r.lastTriggeredDate !== today) {
            changed = true;
            dueItems.push(r);
            return { ...r, lastTriggeredDate: today };
          }
          return r;
        });

        if (dueItems.length > 0) {
          const first = dueItems[0];
          showToast(`Reminder: ${first.title}${first.note ? ` — ${first.note}` : ""}`);
          if (typeof Notification !== "undefined" && Notification.permission === "granted") {
            try {
              new Notification(`Dr. ${profileRef.current.name} Reminder`, {
                body: `${first.title}${first.note ? ` — ${first.note}` : ""}`,
                icon: "/assets/noor-icon-192.png",
              });
            } catch {}
          }
          if (startedRef.current && liveCallStatus === "ended") {
            speakImmediate(
              `[stethoscope] Yaad-dihani! ${first.title} ka waqt ho gaya hai. ${first.note}`
            );
          }
        }
        return changed ? updated : prev;
      });
    }, 15000);

    return () => clearInterval(id);
  }, [liveCallStatus, showToast, speakImmediate]);

  const setHistoryList = (updater: (prev: ChatMessage[]) => ChatMessage[]) => {
    setHistory((prev) => updater(prev));
  };

  const handleStart = () => {
    setStarted(true);
    speechRef.current?.unlockAudio();
    const first = profile.name.split(" ")[0];
    let greeting = `[wave] Assalam o Alaikum! Main Dr. ${first} hoon. Aaj main aap ki kya madad kar sakti hoon?`;
    if (familyMode) {
      greeting =
        settings.lang === "pa"
          ? `[heart] Assalam o Alaikum Ammi Abbu! Main tuhadi pyari ${first} haan. Tusi kiven ho?`
          : `[heart] Assalam o Alaikum Ammi Abbu! Main aap ki pyari ${first} hoon. Aap kaise hain?`;
    } else if (settings.lang === "pa") {
      greeting = `[wave] Assalam o Alaikum ji! Main Dr. ${first} haan. Daso main tuhadi ki madad karaan?`;
    } else if (settings.lang === "en") {
      greeting = `[wave] Assalam o Alaikum! I am Dr. ${first}. How can I help you today?`;
    }
    speakImmediate(greeting);
  };

  const toggleLiveCall = async () => {
    if (liveCallStatus !== "ended") {
      liveClientRef.current?.stop();
      liveClientRef.current = null;
      stopLiveVideoStream();
      setLiveCallStatus("ended");
      return;
    }

    if (!navigator.onLine) {
      showToast("Live Call requires an internet connection.");
      return;
    }

    setStarted(true);
    speechRef.current?.stop();
    setHeardText("");
    setCaption("Connecting Live Call with Dr. Noor…");

    const activeStyle =
      GEMINI_VOICE_STYLES.find((v) => v.id === settings.geminiStyleId) || GEMINI_VOICE_STYLES[0];

    const client = new LiveCallClient(
      {
        onStatus: (status) => {
          setLiveCallStatus(status);
          if (status === "ended") {
            stopLiveVideoStream();
          } else if (status === "connected") {
            showToast("Live Voice Call connected — just speak naturally!");
          }
        },
        onInputTranscript: (txt) => {
          setHeardText(txt);
        },
        onOutputTranscript: (txt) => {
          setCaption(txt);
        },
        onSpeakingChange: (speaking) => {
          setIsSpeaking(speaking);
        },
        onError: (err) => {
          showToast(err);
        },
      },
      avatarRef.current
    );

    liveClientRef.current = client;
    await client.start({
      mode: familyMode ? "family" : "public",
      lang: settings.lang,
      voiceName: activeStyle.voiceName,
      name: profile.name,
      coords: userCoords,
    });
  };

  const toggleLiveVideo = async () => {
    if (liveCallStatus === "ended") {
      showToast("Start a Live Call first to share live camera view.");
      return;
    }

    if (liveVideoOn) {
      stopLiveVideoStream();
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      showToast("Camera is not available in this browser.");
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "environment" },
      });
      liveVideoStreamRef.current = stream;
      setLiveVideoOn(true);
      requestAnimationFrame(() => {
        if (liveVideoRef.current) {
          liveVideoRef.current.srcObject = stream;
          liveClientRef.current?.attachVideoElement(liveVideoRef.current);
        }
      });
      showToast("Dr. Noor can see your camera during this call.");
    } catch {
      showToast("Camera permission was denied.");
    }
  };

  const ask = async (rawText: string) => {
    const clean = rawText.trim();
    if (!clean || isBusy) return;

    setStarted(true);
    const speech = speechRef.current;
    speech?.unlockAudio();
    speech?.stop();

    setHeardText(clean);
    const lang = detectLang(clean, settings.lang);

    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: "user",
      content: clean,
      timestamp: Date.now(),
    };
    const nextHistory = [...chatHistory, userMsg];
    setHistoryList(() => nextHistory);
    if (cloudUser && cloudWorkspaceReadyRef.current) {
      void pushCloudMessage(cloudUser.uid, userMsg).catch(() => {});
    }

    // 1. Instant physical gesture/command execution (play, run, jump, dance, walk, hug, dua...)
    const cmds = detectCommands(clean);
    if (isCommand(clean, cmds)) {
      const reply = commandReply(cmds, lang);
      const botMsg: ChatMessage = {
        id: `a-${Date.now() + 1}`,
        role: "assistant",
        content: reply,
        timestamp: Date.now(),
      };
      setHistoryList((prev) => [...prev, botMsg]);
      if (cloudUser && cloudWorkspaceReadyRef.current) {
        void pushCloudMessage(cloudUser.uid, botMsg).catch(() => {});
      }
      speakImmediate(reply);
      return;
    }

    // 2. Offline fallback if no internet
    if (!navigator.onLine) {
      const reply = offlineReply(clean, {
        name: profile.name,
        family: familyMode,
        lang,
      });
      const botMsg: ChatMessage = {
        id: `a-${Date.now() + 1}`,
        role: "assistant",
        content: reply,
        timestamp: Date.now(),
      };
      setHistoryList((prev) => [...prev, botMsg]);
      speakImmediate(reply);
      return;
    }

    // 3. Streaming Gemini 4 Hydrogen + Online Grounding + Expressive Baby Voice + Full-Body Gestures
    setIsBusy(true);
    avatarRef.current?.play("think");
    setCaption("…");

    const botId = `a-${Date.now() + 1}`;
    setHistoryList((prev) => [
      ...prev,
      { id: botId, role: "assistant", content: "", timestamp: Date.now() },
    ]);

    const streamer = speech ? createSentenceStreamer(speech) : null;
    let fullReply = "";
    let sources: GroundingSource[] | undefined;

    let activeLocation = userCoords;
    const looksLikePlaceQuery =
      /\b(near|nearby|nearest|hospital|clinic|medical|pharmacy|x-?ray|ultrasound|altrson|lab|location|qareeb|paas|nazdeek|kahan|kidhar|map)\b/i.test(
        clean
      );
    if (looksLikePlaceQuery && !activeLocation && navigator.geolocation) {
      activeLocation = await new Promise<{ lat: number; lng: number } | null>((resolve) => {
        const t = setTimeout(() => resolve(null), 2600);
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            clearTimeout(t);
            const c = { lat: pos.coords.latitude, lng: pos.coords.longitude };
            setUserCoords(c);
            resolve(c);
          },
          () => {
            clearTimeout(t);
            resolve(null);
          },
          { enableHighAccuracy: false, timeout: 2500, maximumAge: 120000 }
        );
      });
    }

    const nowDate = new Date();
    const clientTime = {
      iso: nowDate.toISOString(),
      timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Karachi",
      localFormatted: nowDate.toLocaleString("en-US", {
        weekday: "short",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      }),
      offsetMinutes: -nowDate.getTimezoneOffset(),
    };

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: nextHistory.slice(-16).map((m) => ({
            role: m.role,
            content: m.content,
          })),
          mode: familyMode ? "family" : "public",
          language: settings.lang,
          useSearch: settings.useSearch,
          profileContext: {
            name: profile.name,
            about: profile.about,
            familyNotes: familyMode ? profile.familyNotes : "",
          },
          clientTime,
          userLocation: activeLocation,
        }),
      });

      if (!res.ok || !res.body) {
        throw new Error(`Chat service error (${res.status})`);
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";

      while (true) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        let nlIdx: number;
        while ((nlIdx = buffer.indexOf("\n\n")) !== -1) {
          const eventBlock = buffer.slice(0, nlIdx);
          buffer = buffer.slice(nlIdx + 2);
          for (const line of eventBlock.split("\n")) {
            if (!line.startsWith("data: ")) continue;
            try {
              const payload = JSON.parse(line.slice(6));
              if (payload.type === "chunk" && payload.text) {
                fullReply += payload.text;
                streamer?.feed(payload.text, false);
                const cleanCaption = stripTags(fullReply);
                setCaption(cleanCaption);
                setHistoryList((prev) =>
                  prev.map((m) =>
                    m.id === botId ? { ...m, content: fullReply } : m
                  )
                );
              } else if (payload.type === "sources" && Array.isArray(payload.sources)) {
                sources = payload.sources;
              } else if (payload.type === "error") {
                throw new Error(payload.error || "Gemini response error");
              }
            } catch (parseErr) {
              if (
                parseErr instanceof Error &&
                parseErr.message !== "Unexpected end of JSON input"
              ) {
                throw parseErr;
              }
            }
          }
        }
      }

      streamer?.feed("", true);
      if (!fullReply.trim()) {
        throw new Error("No reply received from Dr. Noor.");
      }

      const finalBotMsg: ChatMessage = {
        id: botId,
        role: "assistant",
        content: fullReply,
        timestamp: Date.now(),
        sources,
      };
      setHistoryList((prev) =>
        prev.map((m) => (m.id === botId ? finalBotMsg : m))
      );
      if (cloudUser && cloudWorkspaceReadyRef.current) {
        void pushCloudMessage(cloudUser.uid, finalBotMsg).catch(() => {});
      }
      setCaption(stripTags(fullReply));

      const tags = extractTags(fullReply);
      if (tags.length && !speech?.active) {
        avatarRef.current?.play(tags[0]);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not reach AI service.";
      showToast(msg);
      let fallback: string;
      if (!navigator.onLine) {
        fallback = offlineReply(clean, {
          name: profile.name,
          family: familyMode,
          lang,
        });
      } else if (lang === "en") {
        fallback =
          "[think] The AI server took a bit too long right now. Please ask your question once more and I will answer right away.";
      } else if (lang === "pa") {
        fallback =
          "[think] Is vele online server te thora rush ae — meherbani karke apna sawal ik vaari hor puchho, main foran jawab dewan gi.";
      } else {
        fallback =
          "[think] Is waqt online AI server par thora load aa gaya — meherbani karke apna sawal ek baar phir bhejein, main foran jawab doon gi.";
      }
      setHistoryList((prev) =>
        prev.map((m) => (m.id === botId ? { ...m, content: fallback } : m))
      );
      speakImmediate(fallback);
    } finally {
      setIsBusy(false);
    }
  };

  const handleQuickAction = (say: string, gesture: GestureName) => {
    setStarted(true);
    speechRef.current?.unlockAudio();
    avatarRef.current?.play(gesture);
    if (liveCallStatus !== "ended") {
      setCaption(say);
      return;
    }
    ask(say);
  };

  const handleToggleFamilyRequest = (wantEnable: boolean) => {
    if (!wantEnable) {
      setFamilyMode(false);
      showToast("Switched to Public Baby Doctor Mode.");
      return;
    }
    setPinInput("");
    setPinError("");
    setPinModalOpen(true);
  };

  const handleVerifyPin = async (e: React.FormEvent) => {
    e.preventDefault();
    const entered = pinInput.trim();
    if (!entered) return;
    const bundleHash = await hashPin(entered, BUNDLED_PIN_CHECK.salt);
    const localHash = customPinHash ? await hashPin(entered, "noor-local-pin") : "";
    if (
      bundleHash === BUNDLED_PIN_CHECK.hash ||
      (customPinHash && localHash === customPinHash)
    ) {
      setFamilyMode(true);
      setPinModalOpen(false);
      showToast("Family Mode unlocked.");
      if (liveCallStatus === "ended") {
        speakImmediate(
          "[heart] Ammi jaan, Abbu jaan, main aa gayi! Noor aap sab se bohat pyar karti hai."
        );
      }
    } else {
      setPinError("Incorrect PIN. Try again or set a custom PIN in Settings.");
    }
  };

  const handleExportHistory = () => {
    if (!chatHistory.length) {
      showToast("No conversation messages to download yet.");
      return;
    }
    const text = chatHistory
      .map(
        (m) =>
          `[${new Date(m.timestamp).toLocaleString()}] ${
            m.role === "user" ? "You" : profile.name
          }: ${stripTags(m.content)}`
      )
      .join("\n\n");
    const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `dr-noor-haram-chat-${new Date().toISOString().slice(0, 10)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleClearHistory = () => {
    speechRef.current?.stop();
    setHistoryList(() => []);
    setCaption("");
    setHeardText("");
    if (cloudUser && cloudWorkspaceReadyRef.current) {
      void clearCloudMessages(cloudUser.uid).catch(() => {});
    }
    showToast("Conversation cleared.");
  };

  const handleUpdateRemindersSync = (next: MedReminder[]) => {
    if (cloudUser && cloudWorkspaceReadyRef.current) {
      const prevMap = new Map(reminders.map((r) => [r.id, r]));
      const nextMap = new Map(next.map((r) => [r.id, r]));
      for (const oldItem of reminders) {
        if (!nextMap.has(oldItem.id)) {
          void deleteCloudReminder(cloudUser.uid, oldItem.id).catch(() => {});
        }
      }
      for (const item of next) {
        const old = prevMap.get(item.id);
        if (!old) {
          void saveCloudReminder(cloudUser.uid, item, true).catch(() => {});
        } else if (
          old.enabled !== item.enabled ||
          old.title !== item.title ||
          old.time !== item.time ||
          old.note !== item.note
        ) {
          void saveCloudReminder(cloudUser.uid, item, false).catch(() => {});
        }
      }
    }
    setReminders(next);
  };

  const handleUpdateEntriesSync = (next: DiaryEntry[]) => {
    if (cloudUser && cloudWorkspaceReadyRef.current) {
      const prevMap = new Map(diaryEntries.map((d) => [d.id, d]));
      const nextMap = new Map(next.map((d) => [d.id, d]));
      for (const oldItem of diaryEntries) {
        if (!nextMap.has(oldItem.id)) {
          void deleteCloudDiaryEntry(cloudUser.uid, oldItem.id).catch(() => {});
        }
      }
      for (const item of next) {
        if (!prevMap.has(item.id)) {
          void saveCloudDiaryEntry(cloudUser.uid, item).catch(() => {});
        }
      }
    }
    setDiaryEntries(next);
  };

  const handleUpdateVitalsSync = (next: VitalRecord[]) => {
    if (cloudUser && cloudWorkspaceReadyRef.current) {
      const prevMap = new Map(vitals.map((v) => [v.id, v]));
      const nextMap = new Map(next.map((v) => [v.id, v]));
      for (const oldItem of vitals) {
        if (!nextMap.has(oldItem.id)) {
          void deleteCloudVital(cloudUser.uid, oldItem.id).catch(() => {});
        }
      }
      for (const item of next) {
        if (!prevMap.has(item.id)) {
          void saveCloudVital(cloudUser.uid, item).catch(() => {});
        }
      }
    }
    setVitals(next);
  };

  const handleSaveReportSync = (report: MedicalReportRecord) => {
    if (cloudUser && cloudWorkspaceReadyRef.current) {
      void saveCloudReport(cloudUser.uid, report).catch(() => {});
    }
    setReports((prev) => [report, ...prev.filter((r) => r.id !== report.id)].slice(0, 50));
  };

  const handleDeleteReportSync = (id: string) => {
    if (cloudUser && cloudWorkspaceReadyRef.current) {
      void deleteCloudReport(cloudUser.uid, id).catch(() => {});
    }
    setReports((prev) => prev.filter((r) => r.id !== id));
  };

  const handleCreateFamilyRoom = async (roomName: string, passcode?: string) => {
    if (!cloudUser) {
      showToast("Please sign in with Google first to create a Shared Family Room.");
      return;
    }
    setRoomBusy(true);
    try {
      const created = await createFamilyRoom(
        cloudUser.uid,
        cloudUser.displayName || profile.name,
        roomName,
        passcode,
        {
          chat: historyRef.current,
          reminders: remindersRef.current,
          diary: diaryRef.current,
          vitals: vitalsRef.current,
          reports: reportsRef.current,
        }
      );
      setActiveRoom(created);
      showToast(`Family Room ${created.roomCode} created! Share link or code with family.`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to create Family Room.";
      showToast(msg);
    } finally {
      setRoomBusy(false);
    }
  };

  const handleJoinFamilyRoom = async (roomCode: string, passcode: string) => {
    if (!cloudUser) {
      showToast("Please sign in with Google first to join a Shared Family Room.");
      return;
    }
    setRoomBusy(true);
    try {
      const joined = await joinFamilyRoom(
        cloudUser.uid,
        cloudUser.displayName || profile.name,
        roomCode,
        passcode
      );
      setActiveRoom(joined);
      showToast(`Joined Family Room ${joined.roomCode} — live sync active!`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Incorrect Room Code or Passcode.";
      showToast(msg);
    } finally {
      setRoomBusy(false);
    }
  };

  const handleLeaveFamilyRoom = async () => {
    if (!activeRoom) return;
    setRoomBusy(true);
    try {
      if (cloudUser) {
        await leaveFamilyRoom(cloudUser.uid, activeRoom.roomCode);
      }
      setActiveRoom(null);
      showToast("Left Shared Family Room.");
    } finally {
      setRoomBusy(false);
    }
  };

  const handleSignInCloud = async () => {
    try {
      const u = await signInCloudSync();
      showToast(`Signed in as ${u.displayName || u.email || "Google user"} — syncing across devices!`);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not sign in with Google.";
      showToast(msg);
    }
  };

  const handleSignOutCloud = async () => {
    try {
      await signOutCloudSync();
      showToast("Signed out of Cloud Sync (local browser data preserved).");
    } catch {}
  };

  const getCurrentBundle = (): NoorBackupBundle => ({
    version: 1,
    exportedAt: new Date().toISOString(),
    profile,
    settings,
    history: chatHistory,
    reminders,
    diaryEntries,
    vitals,
    reports,
    familyMode,
  });

  const handleDownloadBackup = () => {
    downloadAutoSaveBackup(getCurrentBundle());
    showToast("Auto-Save backup downloaded!");
  };

  const getLiveAppUrl = () => {
    if (typeof window === "undefined") return serverAppUrlRef.current || "/";
    if (serverAppUrlRef.current && serverAppUrlRef.current.startsWith("https://")) {
      return serverAppUrlRef.current.replace("://ais-dev-", "://ais-pre-");
    }
    const origin = window.location.origin;
    if (
      origin.startsWith("https://") &&
      !origin.includes("localhost") &&
      !origin.includes("127.0.0.1")
    ) {
      return origin.replace("://ais-dev-", "://ais-pre-");
    }
    return origin;
  };

  const handleDownloadPortableApp = () => {
    const liveUrl = getLiveAppUrl();
    downloadPortableAppFile(getCurrentBundle(), liveUrl);
    showToast("App file saved to Downloads with WiFi voice & online search!");
  };

  const handleShareApp = async (urlOverride?: string) => {
    const liveUrl = urlOverride || getLiveAppUrl();
    const mode = await sharePortableApp(getCurrentBundle(), liveUrl);
    if (mode === "shared_file") showToast("App file shared!");
    else if (mode === "shared_link") showToast("App link shared!");
    else if (mode === "copied") showToast("Link copied & App file downloaded to share!");
    else showToast("App file downloaded — ready to send!");
  };

  const handleRestoreBackup = (bundle: NoorBackupBundle) => {
    if (bundle.profile) setProfile(mergeBrothersMemory({ ...DEFAULT_PROFILE, ...bundle.profile }));
    if (bundle.settings) {
      const validVoice = GEMINI_VOICE_STYLES.some((v) => v.id === bundle.settings.geminiStyleId);
      setSettings({
        ...DEFAULT_SETTINGS,
        ...bundle.settings,
        geminiStyleId: validVoice ? bundle.settings.geminiStyleId : DEFAULT_SETTINGS.geminiStyleId,
      });
    }
    if (Array.isArray(bundle.history)) setHistory(bundle.history);
    if (Array.isArray(bundle.reminders)) setReminders(bundle.reminders);
    if (Array.isArray(bundle.diaryEntries)) setDiaryEntries(bundle.diaryEntries);
    if (Array.isArray(bundle.vitals)) setVitals(bundle.vitals);
    if (Array.isArray(bundle.reports)) setReports(bundle.reports);
    if (typeof bundle.familyMode === "boolean") setFamilyMode(bundle.familyMode);
    showToast("Backup restored & auto-saved!");
  };

  const toggleDrawer = (target: Exclude<DrawerPanel, null>) => {
    setDrawer((curr) => (curr === target ? null : target));
  };

  const aiVitalState: AiVitalState = !isOnline
    ? "offline"
    : liveCallStatus === "connected"
      ? "live_call"
      : isSpeaking
        ? "speaking"
        : isBusy || liveCallStatus === "connecting"
          ? "thinking"
          : isMicListening || (started && settings.autoListen)
            ? "listening"
            : "idle";

  useEffect(() => {
    avatarRef.current?.setListening(aiVitalState === "listening");
  }, [aiVitalState]);

  return (
    <div className="relative h-dvh w-full overflow-hidden bg-[#0e0c14] text-[#faf6f0]">
      {/* Full-Display Living Portrait Stage */}
      <div className="absolute inset-0 z-0">
        <LivingStage
          photoUrl={profile.photoDataUrl}
          points={profile.points}
          bodyMode={profile.bodyMode}
          name={profile.name}
          isSpeaking={isSpeaking}
          familyMode={familyMode}
          started={started}
          onStart={handleStart}
          onStopSpeech={() => {
            if (liveCallStatus !== "ended") {
              toggleLiveCall();
            } else {
              speechRef.current?.stop();
            }
          }}
          onAvatarReady={handleAvatarReady}
          onToast={showToast}
        />
      </div>

      {/* Live Call PiP Camera Preview (only when Live Video is active) */}
      {liveVideoOn && liveCallStatus !== "ended" && (
        <div className="fixed top-28 right-4 z-20 w-32 h-24 rounded-2xl overflow-hidden border-2 border-[#e8b86d]/70 bg-black shadow-2xl">
          <video
            ref={liveVideoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover"
          />
        </div>
      )}

      {/* Google Maps Demo Key Quota Banner (shown only if quota exceeded) */}
      {mapsQuotaExceeded && (
        <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2 text-xs md:text-sm text-center fixed top-0 inset-x-0 z-50 shadow-sm">
          <span>
            Google Maps Platform quota reached. If you are the app owner, visit{" "}
            <a
              href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
              target="_blank"
              rel="noopener noreferrer"
              className="underline font-semibold text-amber-950 hover:text-amber-800"
            >
              maps developer site
            </a>{" "}
            for instructions to update your account.
          </span>
        </div>
      )}

      {/* Minimal Floating Top Header */}
      <header className="absolute top-0 left-0 right-0 z-30 h-14 px-2.5 sm:px-5 bg-gradient-to-b from-[#0e0c14]/90 via-[#0e0c14]/55 to-transparent flex items-center justify-between gap-2 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-1.5 sm:gap-2 shrink-0">
          <div
            className={`w-8 h-8 rounded-lg bg-[#e6483d]/20 border border-[#e6483d]/45 flex items-center justify-center shrink-0 transition-transform ${
              aiVitalState === "listening"
                ? "animate-pulse scale-110 bg-[#e6483d]/35"
                : aiVitalState === "thinking" || aiVitalState === "speaking"
                  ? "heartbeat-active bg-[#e6483d]/35 border-[#e6483d]"
                  : ""
            }`}
          >
            <Heart className="w-4 h-4 text-[#e6483d] fill-current" />
          </div>
          <h1 className="text-xs sm:text-sm font-bold tracking-tight text-[#faf6f0] drop-shadow whitespace-nowrap">
            <span className="sm:hidden">{profile.name.split(" ")[0]}</span>
            <span className="hidden sm:inline">Dr. {profile.name}</span>
          </h1>
          {!isOnline && (
            <span
              title="Offline mode active"
              className="hidden md:inline-flex items-center gap-1 text-[11px] font-medium text-[#e8b86d]"
            >
              <WifiOff className="w-3.5 h-3.5" />
              Offline
            </span>
          )}
        </div>

        <nav
          aria-label="Workspace panels"
          className="pointer-events-auto flex-1 min-w-0 flex items-center justify-start sm:justify-end gap-1 sm:gap-1.5 overflow-x-auto noor-scroll py-1 pl-0.5"
        >
          <PWAInstallButton
            shareUrl={getLiveAppUrl()}
            activeRoom={activeRoom}
            onDownloadPortableApp={handleDownloadPortableApp}
            onShareApp={handleShareApp}
            onDownloadBackup={handleDownloadBackup}
            onToast={showToast}
          />

          <button
            type="button"
            onClick={() => {
              setClinicSubTab("nearby");
              setDrawer("clinic");
            }}
            title="Find Nearby Hospitals, Medical Stores, X-Ray & Ultrasound"
            className={`min-h-[36px] px-2 sm:px-3 rounded-xl border text-xs font-semibold flex items-center gap-1 backdrop-blur-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              drawer === "clinic" && clinicSubTab === "nearby"
                ? "bg-[#5eead4] border-[#5eead4] text-[#0e0c14]"
                : "bg-[#15121e]/75 border-white/15 text-[#5eead4] hover:text-white"
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Near</span>
          </button>

          <button
            type="button"
            onClick={() => toggleDrawer("world")}
            title="All World Knowledge & Universal Translator"
            className={`min-h-[36px] px-2 sm:px-3 rounded-xl border text-xs font-semibold flex items-center gap-1 backdrop-blur-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              drawer === "world"
                ? "bg-[#e8b86d] border-[#e8b86d] text-[#0e0c14]"
                : "bg-[#15121e]/75 border-white/15 text-[#e8b86d] hover:text-white"
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>World</span>
          </button>

          <button
            type="button"
            onClick={() => toggleDrawer("chat")}
            className={`min-h-[36px] px-2 sm:px-3 rounded-xl border text-xs font-semibold flex items-center gap-1.5 backdrop-blur-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              drawer === "chat"
                ? "bg-[#e6483d] border-[#e6483d] text-white"
                : "bg-[#15121e]/75 border-white/15 text-white/85 hover:text-white"
            }`}
          >
            <MessageCircle className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Chat</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setClinicSubTab("medicine");
              toggleDrawer("clinic");
            }}
            className={`min-h-[36px] px-2 sm:px-3 rounded-xl border text-xs font-semibold flex items-center gap-1.5 backdrop-blur-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              drawer === "clinic" && clinicSubTab !== "nearby"
                ? "bg-[#e6483d] border-[#e6483d] text-white"
                : "bg-[#15121e]/75 border-white/15 text-white/85 hover:text-white"
            }`}
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>Clinic</span>
          </button>

          <button
            type="button"
            onClick={() => toggleDrawer("diary")}
            className={`min-h-[36px] px-2 sm:px-3 rounded-xl border text-xs font-semibold flex items-center gap-1.5 backdrop-blur-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              drawer === "diary"
                ? "bg-[#e6483d] border-[#e6483d] text-white"
                : "bg-[#15121e]/75 border-white/15 text-white/85 hover:text-white"
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Diary</span>
          </button>

          <button
            type="button"
            onClick={() => toggleDrawer("stories")}
            className={`min-h-[36px] px-2 sm:px-3 rounded-xl border text-xs font-semibold flex items-center gap-1.5 backdrop-blur-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              drawer === "stories"
                ? "bg-[#e6483d] border-[#e6483d] text-white"
                : "bg-[#15121e]/75 border-white/15 text-white/85 hover:text-white"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span className="hidden md:inline">Stories &amp; Dua</span>
            <span className="hidden sm:inline md:hidden">Dua</span>
          </button>

          <button
            type="button"
            onClick={() => handleToggleFamilyRequest(!familyMode)}
            title={familyMode ? "Family Mode active" : "Unlock Family Mode"}
            className={`min-h-[36px] px-2 sm:px-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1 backdrop-blur-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              familyMode
                ? "bg-[#e8b86d]/20 border-[#e8b86d]/55 text-[#e8b86d]"
                : "bg-[#15121e]/75 border-white/15 text-white/80 hover:text-white"
            }`}
          >
            {familyMode ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
            <span className="hidden lg:inline">Family</span>
          </button>

          <button
            type="button"
            onClick={() => setSettingsOpen(true)}
            aria-label="Open settings"
            title="100 Baby Voices, Family & Portrait Settings"
            className="min-h-[36px] min-w-[36px] rounded-xl bg-[#15121e]/75 hover:bg-[#1c1826] backdrop-blur-md border border-white/15 text-white/85 flex items-center justify-center transition-colors shrink-0 cursor-pointer"
          >
            <Settings className="w-4 h-4" />
          </button>
        </nav>
      </header>

      {/* Compact Little Floating Chat + Live Call + Always-Open Mic Dock */}
      {!drawer && (
        <FloatingDock
          noorName={profile.name}
          caption={caption}
          heardText={heardText}
          isBusy={isBusy}
          isSpeaking={isSpeaking}
          started={started}
          autoListen={settings.autoListen}
          liveCallStatus={liveCallStatus}
          liveVideoOn={liveVideoOn}
          sttLang={settings.stt}
          onToggleAutoListen={() =>
            setSettings((s) => ({ ...s, autoListen: !s.autoListen }))
          }
          onToggleLiveCall={toggleLiveCall}
          onToggleLiveVideo={toggleLiveVideo}
          onSend={ask}
          onInterruptSpeech={() => speechRef.current?.stop()}
          onHeardPreview={(t) => setHeardText(t)}
          onQuickAction={handleQuickAction}
          onOpenVision={() => {
            setClinicSubTab("vision");
            setDrawer("clinic");
          }}
          onEnsureStarted={() => {
            setStarted(true);
            speechRef.current?.unlockAudio();
          }}
          onUnlockAudio={() => speechRef.current?.unlockAudio()}
          onListeningChange={setIsMicListening}
          onToast={showToast}
        />
      )}

      {/* Slide-Over Frosted Glass Drawer for Chat / Clinic / World / Diary / Stories & Dua */}
      {drawer && (
        <aside
          aria-label="Workspace drawer"
          className="fixed top-14 right-0 bottom-0 z-40 w-full sm:w-[440px] bg-[#15121e]/95 backdrop-blur-xl border-l border-white/15 shadow-2xl flex flex-col"
        >
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/10 bg-[#120f1a]">
            <span className="text-xs font-semibold uppercase tracking-wider text-[#e8b86d]">
              {drawer === "chat"
                ? "Conversation & Sources"
                : drawer === "clinic"
                  ? "Dr. Noor Clinic · Dawai, Heart & Live Scan"
                  : drawer === "world"
                    ? "World Knowledge & Translator"
                    : drawer === "diary"
                      ? "Dawai Reminders & Family Diary"
                      : "Stories & Dua Studio"}
            </span>
            <button
              type="button"
              onClick={() => setDrawer(null)}
              aria-label="Close drawer"
              className="min-h-[34px] px-2.5 rounded-lg hover:bg-white/10 text-xs font-medium text-white/75 hover:text-white flex items-center gap-1 cursor-pointer"
            >
              <X className="w-4 h-4" />
              <span>Full View</span>
            </button>
          </div>

          <div className="flex-1 min-h-0 flex flex-col">
            {drawer === "chat" && (
              <ChatPanel
                messages={chatHistory}
                noorName={profile.name}
                isBusy={isBusy}
                useSearch={settings.useSearch}
                onToggleSearch={() =>
                  setSettings((s) => ({ ...s, useSearch: !s.useSearch }))
                }
                onSend={ask}
                onOpenVision={() => {
                  setClinicSubTab("vision");
                  setDrawer("clinic");
                }}
                onClearHistory={handleClearHistory}
                onExportHistory={handleExportHistory}
              />
            )}

            {drawer === "world" && (
              <WorldToolsPanel
                language={settings.lang}
                onSpeakResult={speakImmediate}
                onAddToChat={(summary) => {
                  setHistoryList((prev) => [
                    ...prev,
                    {
                      id: `world-${Date.now()}`,
                      role: "assistant",
                      content: summary,
                      timestamp: Date.now(),
                    },
                  ]);
                  setDrawer("chat");
                }}
                onToast={showToast}
              />
            )}

            {drawer === "clinic" && (
              <ClinicPanel
                language={settings.lang}
                familyMode={familyMode}
                aiState={aiVitalState}
                noorName={profile.name}
                requestedSubTab={clinicSubTab}
                userCoords={userCoords}
                onCoordsUpdate={setUserCoords}
                reports={reports}
                onSaveReport={handleSaveReportSync}
                onDeleteReport={handleDeleteReportSync}
                onSpeakResult={speakImmediate}
                onAddToChat={(summary, img) => {
                  setHistoryList((prev) => [
                    ...prev,
                    {
                      id: `clinic-${Date.now()}`,
                      role: "assistant",
                      content: summary,
                      timestamp: Date.now(),
                      imagePreview: img,
                    },
                  ]);
                  setDrawer("chat");
                }}
                onToast={showToast}
              />
            )}

            {drawer === "diary" && (
              <DiaryPanel
                reminders={reminders}
                entries={diaryEntries}
                vitals={vitals}
                reports={reports}
                noorName={profile.name}
                onUpdateReminders={handleUpdateRemindersSync}
                onUpdateEntries={handleUpdateEntriesSync}
                onUpdateVitals={handleUpdateVitalsSync}
                onSpeakText={speakImmediate}
                onShareToChat={(text) => {
                  setDrawer(null);
                  ask(text);
                }}
                onToast={showToast}
              />
            )}

            {drawer === "stories" && (
              <StoriesDuaPanel
                noorName={profile.name}
                language={settings.lang}
                familyMode={familyMode}
                onSpeakStory={speakImmediate}
                onToast={showToast}
              />
            )}
          </div>
        </aside>
      )}

      {/* PIN Unlock Modal */}
      {pinModalOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Unlock Family Mode"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) setPinModalOpen(false);
          }}
        >
          <form
            onSubmit={handleVerifyPin}
            className="w-full max-w-sm rounded-3xl bg-[#15121e] border border-white/15 p-5 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#e8b86d]" />
                <h2 className="text-sm font-semibold text-[#faf6f0]">
                  Enter Family Mode PIN
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setPinModalOpen(false)}
                aria-label="Close PIN modal"
                className="w-8 h-8 rounded-lg hover:bg-white/10 text-white/70 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <p className="text-xs text-white/60 leading-relaxed">
              Enter the Noor Haram family PIN (or a custom PIN you saved in Settings) to unlock
              private family memories and affectionate daughter greetings.
            </p>
            <input
              type="password"
              inputMode="numeric"
              autoFocus
              value={pinInput}
              onChange={(e) => {
                setPinInput(e.target.value);
                setPinError("");
              }}
              placeholder="Enter PIN…"
              className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#1c1826] border border-white/15 focus:border-[#e8b86d] outline-none text-sm text-[#faf6f0]"
            />
            {pinError && <p className="text-xs text-[#e6483d]">{pinError}</p>}
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setPinModalOpen(false)}
                className="min-h-[40px] px-4 rounded-xl bg-white/[0.06] text-xs font-medium text-white/80 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="min-h-[40px] px-4 rounded-xl bg-[#e8b86d] text-[#0e0c14] text-xs font-bold cursor-pointer"
              >
                Unlock
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Settings Modal */}
      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        profile={profile}
        settings={settings}
        familyMode={familyMode}
        customPinHash={customPinHash}
        onUpdateProfile={setProfile}
        onUpdateSettings={setSettings}
        onToggleFamilyMode={handleToggleFamilyRequest}
        onSaveCustomPinHash={(h) => {
          setCustomPinHash(h);
          try {
            localStorage.setItem("noor.customPinHash", h);
          } catch {}
        }}
        onDownloadBackup={handleDownloadBackup}
        onRestoreBackup={handleRestoreBackup}
        onTestVoice={speakImmediate}
        cloudUser={
          cloudUser
            ? { uid: cloudUser.uid, displayName: cloudUser.displayName, email: cloudUser.email }
            : null
        }
        cloudSyncStatus={cloudSyncStatus}
        onSignInCloud={handleSignInCloud}
        onSignOutCloud={handleSignOutCloud}
        activeRoom={activeRoom}
        roomBusy={roomBusy}
        shareAppBaseUrl={getLiveAppUrl()}
        onCreateFamilyRoom={handleCreateFamilyRoom}
        onJoinFamilyRoom={handleJoinFamilyRoom}
        onLeaveFamilyRoom={handleLeaveFamilyRoom}
        onToast={showToast}
      />

      {/* Toast Notification */}
      {toastMsg && (
        <div
          role="status"
          className="fixed top-16 left-1/2 -translate-x-1/2 z-50 max-w-md px-4 py-2.5 rounded-xl bg-[#1c1826]/95 border border-[#e8b86d]/45 text-xs font-medium text-[#faf6f0] shadow-2xl"
        >
          {toastMsg}
        </div>
      )}
    </div>
  );
}
