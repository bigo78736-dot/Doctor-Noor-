import {createRoot} from 'react-dom/client';
import {registerSW} from 'virtual:pwa-register';
import App from './App.tsx';
import './index.css';

// Tier 1 Google Maps Platform quota & auth listener (Demo Key protection)
(window as unknown as { gm_authFailure?: () => void }).gm_authFailure = () => {
  window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
};
const origConsoleError = console.error;
console.error = (...args: unknown[]) => {
  origConsoleError.apply(console, args);
  const msg = args.map((a) => String(a)).join(' ');
  if (msg.includes('OverQuotaMapError') || msg.includes('QuotaExceededError')) {
    window.dispatchEvent(new CustomEvent('gmp-quota-exceeded'));
  }
};

if (import.meta.env.PROD) {
  registerSW({
    immediate: true,
    onRegisterError() {
      // Non-fatal in restricted mobile WebViews or file:// previews
    },
  });
}

createRoot(document.getElementById('root')!).render(<App />);
