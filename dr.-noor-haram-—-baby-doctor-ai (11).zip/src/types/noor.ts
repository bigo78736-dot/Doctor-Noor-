export type GestureName =
  | "smile"
  | "laugh"
  | "wave"
  | "nod"
  | "shake"
  | "jump"
  | "dance"
  | "heart"
  | "think"
  | "sad"
  | "wink"
  | "stethoscope"
  | "walk"
  | "run"
  | "clap"
  | "hug"
  | "dua"
  | "play"
  | "surprise";

export interface Point2D {
  x: number;
  y: number;
}

export interface FacePoints {
  leftEye: Point2D;
  rightEye: Point2D;
  mouth: Point2D;
  eyeScale: number;
  mouthScale: number;
}

export interface NoorProfile {
  name: string;
  about: string;
  familyNotes: string;
  photoDataUrl: string;
  points: FacePoints;
  bodyMode: boolean;
}

export interface GroundingSource {
  title: string;
  uri: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: number;
  sources?: GroundingSource[];
  imagePreview?: string;
}

export interface VoicePreset {
  id: number;
  name: string;
  emoji: string;
  pitch: number;
  rate: number;
  expr: number;
  voiceSlot: number;
}

export interface GeminiVoiceStyle {
  id: string;
  index: number;
  label: string;
  category: string;
  voiceName: "Kore" | "Zephyr" | "Puck";
  stylePrompt: string;
  description: string;
  pitchHint: number;
}

export interface VoiceSettings {
  lang: "auto" | "roman" | "ur" | "pa" | "en";
  stt: "ur-PK" | "pa-IN" | "hi-IN" | "en-US";
  engine: "gemini" | "device";
  geminiStyleId: string;
  voiceURI: string;
  pitch: number;
  rate: number;
  preset: number;
  useSearch: boolean;
  autoListen: boolean;
}

export interface VisionAnalysis {
  title: string;
  urgency: "routine" | "consult_soon" | "urgent";
  noorReply: string;
  keyFindings: string[];
  careSteps: string[];
  redFlags: string[];
}

export interface TriageResult {
  urgency: "routine" | "consult_soon" | "urgent";
  summary: string;
  noorMessage: string;
  homeCare: string[];
  watchFor: string[];
  doctorQuestions: string[];
}

export interface MedicineGuideResult {
  name: string;
  category: string;
  noorSummary: string;
  uses: string[];
  howToUseSafely: string[];
  precautionsAndSideEffects: string[];
  whenToSeeDoctor: string[];
  sources?: GroundingSource[];
}

export interface GeneratedStory {
  title: string;
  content: string;
  gesture: GestureName;
}

export interface MedReminder {
  id: string;
  title: string;
  time: string; // HH:MM (24h)
  note: string;
  enabled: boolean;
  lastTriggeredDate?: string; // YYYY-MM-DD
  calendarEventId?: string;
  calendarLink?: string;
}

export interface CalendarAlarmEvent {
  id: string;
  summary: string;
  timeLabel: string;
  htmlLink?: string;
  noorReminderId?: string;
}

export interface DiaryEntry {
  id: string;
  kind: "health" | "memory";
  title: string;
  notes: string;
  createdAt: number;
}

export type AiVitalState =
  | "idle"
  | "listening"
  | "thinking"
  | "speaking"
  | "live_call"
  | "offline";

export interface VitalRecord {
  id: string;
  tempF?: number;
  bpSys?: number;
  bpDia?: number;
  sugarMgDl?: number;
  spo2?: number;
  heartRate?: number;
  note?: string;
  createdAt: number;
}

export interface MedicalReportRecord {
  id: string;
  title: string;
  urgency: "routine" | "consult_soon" | "urgent";
  noorReply: string;
  keyFindings: string[];
  careSteps: string[];
  redFlags: string[];
  fileName?: string;
  mimeType?: string;
  createdAt: number;
}

export interface DoseCalculationResult {
  medicineName: string;
  patientWeightKg: number;
  patientAgeLabel: string;
  estimatedDoseText: string;
  frequencyText: string;
  maxDailyLimit: string;
  noorAdvice: string;
  safetyWarnings: string[];
  sources?: GroundingSource[];
}

export interface FamilyRoomConfig {
  roomCode: string;
  passcode: string;
  roomName: string;
  role: "owner" | "member";
}
