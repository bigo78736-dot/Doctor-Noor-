import { useState } from "react";
import { BookOpen, Heart, Loader2, Sparkles, Volume2 } from "lucide-react";
import type { GeneratedStory, GestureName, VoiceSettings } from "../types/noor";

const URDU_RE = /[\u0600-\u06ff]/;

interface StoriesDuaPanelProps {
  noorName: string;
  language: VoiceSettings["lang"];
  familyMode: boolean;
  onSpeakStory: (taggedText: string) => void;
  onToast: (msg: string) => void;
}

const CURATED_COLLECTION: Array<{
  id: string;
  kindLabel: string;
  title: string;
  gesture: GestureName;
  text: string;
}> = [
  {
    id: "dua-family",
    kindLabel: "Dua",
    title: "Heartfelt Dua for Family & Health",
    gesture: "dua",
    text: "Ya Allah, hamare Ammi Abbu, ghar walon aur sab pyaron ko hamesha sehat, hifazat, aur sukoon ata farma. Un ke dilon ko noor aur rehmat se bhar de. Ameen.",
  },
  {
    id: "story-crow",
    kindLabel: "Story",
    title: "Pyasa Kauwa (Clever Little Crow)",
    gesture: "smile",
    text: "Ek dafa ka zikr hai, ek nanhe kauwe ko bohat pyas lagi. Usay ek ghara mila jis mein paani bohat neeche tha. Kauwe ne himmat nahi haari, chhote chhote pathar daale, paani oopar aaya aur us ne jee bhar kar paani piya. Seekh: Sabar aur aqal se har mushkil aasan ho jaati hai.",
  },
  {
    id: "poem-hygiene",
    kindLabel: "Health Rhyme",
    title: "Haath Dhone Ki Pyari Nazm",
    gesture: "dance",
    text: "Khaane se pehle aur khel ke baad, saboon se dho lo dono haath! Chhote chhote keede bhaag jayenge, hum sab sehatmand aur khush ho jayenge!",
  },
  {
    id: "dua-sleep",
    kindLabel: "Bedtime",
    title: "Chand aur Sitaron Wali Goodnight",
    gesture: "hug",
    text: "Ab chand nikal aaya hai aur sitare chamak rahe hain. Aankhein band karein, lambi pyari saans lein, aur Allah ka shukar ada karein. Noor aap ko meethi neend ki dua deti hai. Allah Hafiz.",
  },
];

const KINDS: Array<{ id: "story" | "dua" | "poem" | "health_tip"; label: string }> = [
  { id: "story", label: "Bedtime Story" },
  { id: "dua", label: "Loving Dua" },
  { id: "poem", label: "Kid Rhyme" },
  { id: "health_tip", label: "Healthy Habit" },
];

export function StoriesDuaPanel({
  noorName,
  language,
  familyMode,
  onSpeakStory,
  onToast,
}: StoriesDuaPanelProps) {
  const [kind, setKind] = useState<"story" | "dua" | "poem" | "health_tip">("story");
  const [topic, setTopic] = useState("");
  const [listenerName, setListenerName] = useState("");
  const [busy, setBusy] = useState(false);
  const [generated, setGenerated] = useState<GeneratedStory | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!navigator.onLine) {
      onToast("Generating a new story needs internet — you can still play any favorite below offline.");
      return;
    }

    setBusy(true);
    try {
      const res = await fetch("/api/story", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          kind,
          topic: topic.trim(),
          listenerName: listenerName.trim(),
          language: language === "auto" ? "roman" : language,
          mode: familyMode ? "family" : "public",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not create story");
      const story = data as GeneratedStory;
      setGenerated(story);
      onSpeakStory(`[${story.gesture || "smile"}] ${story.title}. ${story.content}`);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Could not generate story");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex-1 h-full overflow-y-auto noor-scroll bg-[#15121e] p-4 space-y-6">
      {/* AI Personalized Studio */}
      <form
        onSubmit={handleGenerate}
        className="rounded-2xl bg-[#1c1826] border border-[#e8b86d]/25 p-4 space-y-4"
      >
        <div className="flex items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-semibold text-[#faf6f0] flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-[#e8b86d]" />
              <span>Create Personal Story or Dua</span>
            </h2>
            <p className="text-xs text-white/60 mt-0.5">
              {noorName.split(" ")[0]} will write and read it aloud in your language.
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-2">
          {KINDS.map((k) => (
            <button
              key={k.id}
              type="button"
              onClick={() => setKind(k.id)}
              className={`min-h-[36px] px-3 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                kind === k.id
                  ? "bg-[#e8b86d]/20 border-[#e8b86d]/55 text-[#faf6f0]"
                  : "bg-[#15121e] border-white/10 text-white/70 hover:text-white"
              }`}
            >
              {k.label}
            </button>
          ))}
        </div>

        <div className="grid sm:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label htmlFor="story-topic" className="block text-xs font-medium text-white/75">
              Theme or Topic
            </label>
            <input
              id="story-topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g., Honesty, brushing teeth, Ammi & Abbu…"
              className="w-full min-h-[42px] px-3 rounded-xl bg-[#15121e] border border-white/10 focus:border-[#e8b86d]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40"
            />
          </div>

          <div className="space-y-1">
            <label htmlFor="story-listener" className="block text-xs font-medium text-white/75">
              Listener Name (optional)
            </label>
            <input
              id="story-listener"
              type="text"
              value={listenerName}
              onChange={(e) => setListenerName(e.target.value)}
              placeholder="e.g., Ayaan, Zainab, Ammi jaan…"
              className="w-full min-h-[42px] px-3 rounded-xl bg-[#15121e] border border-white/10 focus:border-[#e8b86d]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={busy}
          className="w-full min-h-[44px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-45 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
        >
          {busy ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>Writing for you…</span>
            </>
          ) : (
            <>
              <BookOpen className="w-4 h-4" />
              <span>Write &amp; Read Aloud</span>
            </>
          )}
        </button>

        {generated && (
          <div className="mt-3 pt-3 border-t border-white/10 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-sm font-semibold text-[#e8b86d]">{generated.title}</h3>
              <button
                type="button"
                onClick={() =>
                  onSpeakStory(`[${generated.gesture || "smile"}] ${generated.content}`)
                }
                className="min-h-[34px] px-3 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                <Volume2 className="w-3.5 h-3.5 text-[#e8b86d]" />
                <span>Read Again</span>
              </button>
            </div>
            <p
              className={`text-sm leading-relaxed text-[#faf6f0]/90 whitespace-pre-wrap ${
                URDU_RE.test(generated.content) ? "font-urdu text-base" : ""
              }`}
            >
              {generated.content}
            </p>
          </div>
        )}
      </form>

      {/* Instant Offline Favorites */}
      <div className="space-y-3">
        <div className="flex items-center gap-2">
          <Heart className="w-4 h-4 text-[#e6483d]" />
          <h3 className="text-sm font-semibold text-[#faf6f0]">
            Curated Stories &amp; Duas (Always Available)
          </h3>
        </div>

        <div className="grid gap-3">
          {CURATED_COLLECTION.map((item) => (
            <div
              key={item.id}
              className="rounded-2xl bg-[#1c1826]/80 border border-white/10 p-4 space-y-2"
            >
              <div className="flex items-center justify-between gap-2">
                <div>
                  <span className="text-[11px] uppercase tracking-wider font-semibold text-[#e8b86d]">
                    {item.kindLabel}
                  </span>
                  <h4 className="text-sm font-semibold text-[#faf6f0]">{item.title}</h4>
                </div>
                <button
                  type="button"
                  onClick={() => onSpeakStory(`[${item.gesture}] ${item.text}`)}
                  className="min-h-[38px] px-3.5 rounded-lg bg-[#e6483d]/15 hover:bg-[#e6483d]/25 border border-[#e6483d]/40 text-xs font-semibold text-[#faf6f0] flex items-center gap-1.5 transition-colors cursor-pointer shrink-0"
                >
                  <Volume2 className="w-3.5 h-3.5 text-[#e6483d]" />
                  <span>Play</span>
                </button>
              </div>
              <p className="text-xs leading-relaxed text-white/75">{item.text}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
