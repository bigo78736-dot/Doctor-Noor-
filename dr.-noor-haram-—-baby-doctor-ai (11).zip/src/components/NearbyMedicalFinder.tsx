import { useCallback, useEffect, useRef, useState } from "react";
import {
  APIProvider,
  AdvancedMarker,
  InfoWindow,
  Map as GoogleMap,
  Pin,
  useMap,
  useMapsLibrary,
} from "@vis.gl/react-google-maps";
import {
  AlertOctagon,
  Clock,
  CloudSun,
  ExternalLink,
  Hospital,
  Loader2,
  MapPin,
  MessageSquareShare,
  Navigation,
  Phone,
  Pill,
  Route,
  Scan,
  Search,
  Volume2,
  Wind,
} from "lucide-react";
import type { VoiceSettings } from "../types/noor";

export interface NearbyMedicalPlace {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  googleMapsUri: string;
  phone?: string;
  openNow?: boolean;
  rating?: number;
  userRatingCount?: number;
  distanceKm?: number;
  primaryType?: string;
}

export interface SosRouteInfo {
  destinationName: string;
  destinationAddress: string;
  destinationUri: string;
  destinationPhone?: string;
  durationText: string;
  distanceText: string;
  encodedPolyline: string;
  steps: Array<{ instruction: string; distanceMeters: number }>;
}

export type MedicalFacilityCategory = "hospital" | "pharmacy" | "xray" | "ultrasound";

interface NearbyMedicalFinderProps {
  language: VoiceSettings["lang"];
  userCoords: { lat: number; lng: number } | null;
  onCoordsUpdate: (coords: { lat: number; lng: number }) => void;
  onSpeakResult: (taggedText: string) => void;
  onToast: (msg: string) => void;
}

const DEFAULT_FALLBACK_CENTER = { lat: 31.5204, lng: 74.3587 }; // Lahore center only before GPS/city search

const CATEGORY_CONFIG: Array<{
  id: MedicalFacilityCategory;
  label: string;
  query: string;
  pinColor: string;
  icon: typeof Hospital;
}> = [
  {
    id: "hospital",
    label: "Hospitals",
    query: "Hospital Emergency Clinic",
    pinColor: "#e6483d",
    icon: Hospital,
  },
  {
    id: "pharmacy",
    label: "Medical Store",
    query: "Pharmacy Medical Store Chemist",
    pinColor: "#5eead4",
    icon: Pill,
  },
  {
    id: "xray",
    label: "X-Ray",
    query: "X-Ray Radiology Diagnostic Center",
    pinColor: "#e8b86d",
    icon: Scan,
  },
  {
    id: "ultrasound",
    label: "Ultrasound",
    query: "Ultrasound Sonography Diagnostic Lab",
    pinColor: "#a78bfa",
    icon: Scan,
  },
];

function MapCameraSync({
  center,
  selectedPlace,
}: {
  center: { lat: number; lng: number };
  selectedPlace: NearbyMedicalPlace | null;
}) {
  const map = useMap();

  useEffect(() => {
    if (!map) return;
    if (selectedPlace) {
      map.panTo({ lat: selectedPlace.lat, lng: selectedPlace.lng });
      map.setZoom(15);
    } else {
      map.panTo(center);
    }
  }, [map, center, selectedPlace]);

  return null;
}

function SosRoutePolylineOverlay({ encodedPolyline }: { encodedPolyline: string }) {
  const map = useMap();
  const mapsLib = useMapsLibrary("maps");
  const geometryLib = useMapsLibrary("geometry");
  const coreLib = useMapsLibrary("core");
  const polylineRef = useRef<{ setMap: (target: null) => void } | null>(null);

  useEffect(() => {
    if (!map || !mapsLib || !geometryLib || !coreLib || !encodedPolyline) {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
        polylineRef.current = null;
      }
      return;
    }

    try {
      const path = geometryLib.encoding.decodePath(encodedPolyline);
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
      }
      const line = new mapsLib.Polyline({
        path,
        geodesic: true,
        strokeColor: "#e6483d",
        strokeOpacity: 0.92,
        strokeWeight: 5,
      });
      line.setMap(map);
      polylineRef.current = line;

      const bounds = new coreLib.LatLngBounds();
      for (const pt of path) bounds.extend(pt);
      map.fitBounds(bounds, 44);
    } catch {
      // Ignore invalid polyline strings
    }

    return () => {
      if (polylineRef.current) {
        polylineRef.current.setMap(null);
        polylineRef.current = null;
      }
    };
  }, [map, mapsLib, geometryLib, coreLib, encodedPolyline]);

  return null;
}

export function NearbyMedicalFinder({
  language,
  userCoords,
  onCoordsUpdate,
  onSpeakResult,
  onToast,
}: NearbyMedicalFinderProps) {
  const [mapsApiKey, setMapsApiKey] = useState<string>(
    () => (import.meta.env.VITE_GOOGLE_MAPS_API_KEY as string) || ""
  );
  const [category, setCategory] = useState<MedicalFacilityCategory>("hospital");
  const [customCityQuery, setCustomCityQuery] = useState("");
  const [openNowOnly, setOpenNowOnly] = useState(false);
  const [locating, setLocating] = useState(false);
  const [searching, setSearching] = useState(false);
  const [sosBusy, setSosBusy] = useState(false);
  const [places, setPlaces] = useState<NearbyMedicalPlace[]>([]);
  const [selectedPlace, setSelectedPlace] = useState<NearbyMedicalPlace | null>(null);
  const [sosRoute, setSosRoute] = useState<SosRouteInfo | null>(null);
  const [localTimeInfo, setLocalTimeInfo] = useState<{
    timeZoneName: string;
    localTime: string;
  } | null>(null);
  const [envInfo, setEnvInfo] = useState<{
    weather: {
      condition: string;
      tempC: number | null;
      feelsLikeC: number | null;
      humidity: number | null;
      uvIndex: number | null;
      windKmh: number | null;
    } | null;
    airQuality: {
      aqi: number | null;
      category: string;
      dominantPollutant: string;
      healthAdvice: string;
    } | null;
    pollen: Array<{ code: string; name: string; value: number | null; category: string }>;
  } | null>(null);
  const [hasSearchedOnce, setHasSearchedOnce] = useState(false);

  const activeCenter = userCoords || DEFAULT_FALLBACK_CENTER;
  const activeCatMeta =
    CATEGORY_CONFIG.find((c) => c.id === category) || CATEGORY_CONFIG[0];

  useEffect(() => {
    if (mapsApiKey) return;
    fetch("/api/maps-config")
      .then((r) => r.json())
      .then((d) => {
        if (d?.apiKey && typeof d.apiKey === "string") {
          setMapsApiKey(d.apiKey);
        }
      })
      .catch(() => {});
  }, [mapsApiKey]);

  const computeRouteToPlace = useCallback(
    async (origin: { lat: number; lng: number }, target: NearbyMedicalPlace, speakNotice = false) => {
      try {
        const routeRes = await fetch("/api/sos-route", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            originLat: origin.lat,
            originLng: origin.lng,
            destLat: target.lat,
            destLng: target.lng,
            travelMode: "DRIVE",
            language: language === "ur" ? "ur" : "en",
          }),
        });
        const routeData = await routeRes.json().catch(() => ({}));
        if (routeRes.status === 429 || routeData?.quotaExceeded) {
          window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
          onToast("Google Maps daily quota limit reached.");
          return null;
        }
        if (!routeRes.ok) {
          throw new Error(routeData.error || "Could not calculate live route.");
        }
        const info: SosRouteInfo = {
          destinationName: target.name,
          destinationAddress: target.address,
          destinationUri: target.googleMapsUri,
          destinationPhone: target.phone,
          durationText: routeData.durationText || "Nearby",
          distanceText: routeData.distanceText || "",
          encodedPolyline: routeData.encodedPolyline || "",
          steps: Array.isArray(routeData.steps) ? routeData.steps : [],
        };
        setSosRoute(info);
        setSelectedPlace(target);
        if (speakNotice) {
          onSpeakResult(
            `[stethoscope] Sab se qareeb 24/7 Emergency Hospital ${target.name} hai. Gaari se taqreeban ${info.durationText} (${info.distanceText}) lagega. Live route map par dikh raha hai.`
          );
        }
        return info;
      } catch (err) {
        onToast(err instanceof Error ? err.message : "Route calculation failed.");
        return null;
      }
    },
    [language, onSpeakResult, onToast]
  );

  const runNearbySearch = useCallback(
    async (
      coords: { lat: number; lng: number } | null,
      cat: MedicalFacilityCategory,
      cityOverride?: string,
      openOnly?: boolean
    ) => {
      if (!navigator.onLine) {
        onToast("Nearby hospital & lab search requires an active internet connection.");
        return;
      }

      const catObj = CATEGORY_CONFIG.find((c) => c.id === cat) || CATEGORY_CONFIG[0];
      const city = (cityOverride ?? customCityQuery).trim();
      const textQuery = city ? `${catObj.query} in ${city}` : catObj.query;

      setSearching(true);
      setHasSearchedOnce(true);
      setSelectedPlace(null);

      try {
        const res = await fetch("/api/nearby-medical", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            textQuery,
            category: cat,
            lat: coords?.lat,
            lng: coords?.lng,
            openNow: openOnly ?? openNowOnly,
            language: language === "ur" ? "ur" : "en",
          }),
        });

        const data = await res.json().catch(() => ({}));
        if (res.status === 429 || data?.quotaExceeded) {
          window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
          onToast("Google Maps daily quota limit reached.");
          return;
        }
        if (!res.ok) {
          throw new Error(data.error || "Could not search nearby medical facilities.");
        }

        const list = Array.isArray(data.places) ? (data.places as NearbyMedicalPlace[]) : [];
        setPlaces(list);
        if (data.center && typeof data.center.lat === "number" && typeof data.center.lng === "number") {
          onCoordsUpdate(data.center);
          fetch("/api/environment", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              lat: data.center.lat,
              lng: data.center.lng,
              language: language === "ur" ? "ur" : "en",
            }),
          })
            .then((er) => er.json())
            .then((ed) => {
              if (ed?.weather || ed?.airQuality || ed?.pollen?.length) {
                setEnvInfo(ed);
              }
            })
            .catch(() => {});
        }
        if (data.localTimeInfo) {
          setLocalTimeInfo(data.localTimeInfo);
        }

        if (list.length > 0) {
          const top = list[0];
          setSelectedPlace(top);
          const distText =
            typeof top.distanceKm === "number"
              ? `${top.distanceKm.toFixed(1)} km door`
              : "aap ke qareeb";
          onSpeakResult(
            `[stethoscope] Aap ke sab se qareeb ${catObj.label} mein ${top.name} mila hai jo ${distText} hai, address ${top.address}. Neeche map aur directions button dekh lein.`
          );
        } else {
          onToast(`No ${catObj.label} found nearby. Try another city/area name or uncheck Open Now.`);
        }
      } catch (err) {
        onToast(err instanceof Error ? err.message : "Nearby search failed.");
      } finally {
        setSearching(false);
      }
    },
    [customCityQuery, language, onCoordsUpdate, onSpeakResult, onToast, openNowOnly]
  );

  // Feature 3: 1-Tap Emergency SOS -> GPS -> Open 24/7 ER -> Routes API Turn-by-Turn
  const triggerEmergencySos = async () => {
    if (!navigator.onLine) {
      onToast("Emergency ER search needs an active internet connection. Call local emergency (1122 / 911).");
      return;
    }
    setSosBusy(true);
    setCategory("hospital");
    setOpenNowOnly(true);

    const resolveGps = (): Promise<{ lat: number; lng: number } | null> =>
      new Promise((resolve) => {
        if (!navigator.geolocation) {
          resolve(userCoords);
          return;
        }
        navigator.geolocation.getCurrentPosition(
          (pos) => {
            const c = { lat: pos.coords.latitude, lng: pos.coords.longitude };
            onCoordsUpdate(c);
            resolve(c);
          },
          () => resolve(userCoords),
          { enableHighAccuracy: true, timeout: 8000, maximumAge: 30000 }
        );
      });

    try {
      const origin = await resolveGps();
      if (!origin) {
        onToast("Allow GPS location to route directly to the nearest open 24/7 Emergency Room.");
        setSosBusy(false);
        return;
      }

      const res = await fetch("/api/nearby-medical", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          textQuery: "Hospital Emergency Room 24 hours",
          category: "hospital",
          lat: origin.lat,
          lng: origin.lng,
          openNow: true,
          language: language === "ur" ? "ur" : "en",
        }),
      });
      const data = await res.json().catch(() => ({}));
      if (res.status === 429 || data?.quotaExceeded) {
        window.dispatchEvent(new CustomEvent("gmp-quota-exceeded"));
        onToast("Google Maps daily quota limit reached.");
        return;
      }
      if (!res.ok) throw new Error(data.error || "ER lookup failed.");

      const list = Array.isArray(data.places) ? (data.places as NearbyMedicalPlace[]) : [];
      setPlaces(list);
      setHasSearchedOnce(true);

      if (list.length === 0) {
        onToast("No open ER returned for GPS point — call 1122 / local ambulance immediately.");
        return;
      }

      await computeRouteToPlace(origin, list[0], true);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "SOS routing failed.");
    } finally {
      setSosBusy(false);
    }
  };

  useEffect(() => {
    if (!userCoords || envInfo) return;
    fetch("/api/environment", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        lat: userCoords.lat,
        lng: userCoords.lng,
        language: language === "ur" ? "ur" : "en",
      }),
    })
      .then((er) => er.json())
      .then((ed) => {
        if (ed?.weather || ed?.airQuality || ed?.pollen?.length) {
          setEnvInfo(ed);
        }
      })
      .catch(() => {});
  }, [userCoords, envInfo, language]);

  const detectGpsAndSearch = (catOverride?: MedicalFacilityCategory) => {
    const targetCat = catOverride || category;
    if (!navigator.geolocation) {
      onToast("GPS is unavailable in this browser — enter your city/area name below.");
      runNearbySearch(userCoords, targetCat);
      return;
    }

    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const nextCoords = {
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
        };
        setLocating(false);
        onCoordsUpdate(nextCoords);
        runNearbySearch(nextCoords, targetCat, "");
      },
      () => {
        setLocating(false);
        onToast(
          "Location permission not granted. Allow GPS or type any city/area worldwide (e.g. Lahore, Dubai, London, Delhi)."
        );
        if (customCityQuery.trim() || userCoords) {
          runNearbySearch(userCoords, targetCat);
        }
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  };

  const whatsappSosUrl = userCoords
    ? `https://wa.me/?text=${encodeURIComponent(
        `EMERGENCY SOS from Dr. Noor Haram App! Please help — my live GPS location is:\nhttps://maps.google.com/?q=${userCoords.lat},${userCoords.lng}${
          sosRoute ? `\nHeading to ER: ${sosRoute.destinationName} (${sosRoute.durationText})` : ""
        }`
      )}`
    : `https://wa.me/?text=${encodeURIComponent("EMERGENCY SOS! Need urgent medical help right now.")}`;

  return (
    <div className="space-y-4">
      <div className="space-y-1">
        <h2 className="text-base font-semibold text-[#faf6f0]">
          Nearby Hospitals, Emergency SOS, X-Ray &amp; Labs
        </h2>
        <p className="text-xs text-white/60 leading-relaxed">
          Detect live GPS or search worldwide on Google Maps for verified hospitals, pharmacies,
          X-ray &amp; ultrasound centers with instant turn-by-turn routes.
        </p>
      </div>

      {/* 1-Tap Emergency SOS Action Card */}
      <div className="rounded-2xl bg-[#e6483d]/12 border border-[#e6483d]/45 p-3 space-y-2.5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <button
            type="button"
            onClick={triggerEmergencySos}
            disabled={sosBusy}
            className="flex-1 min-h-[42px] px-3.5 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-60 text-white text-xs font-bold flex items-center justify-center gap-2 shadow-lg cursor-pointer"
          >
            {sosBusy ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <AlertOctagon className="w-4 h-4 shrink-0" />
            )}
            <span>{sosBusy ? "Finding Nearest 24/7 ER Route…" : "SOS: Nearest Open 24/7 ER Route"}</span>
          </button>

          <a
            href="tel:1122"
            className="min-h-[42px] px-3 rounded-xl bg-[#1c1826] hover:bg-[#272136] border border-white/15 text-[#faf6f0] text-xs font-bold inline-flex items-center gap-1.5 shrink-0"
            title="Call Rescue 1122 / Emergency"
          >
            <Phone className="w-3.5 h-3.5 text-[#5eead4]" />
            <span>1122</span>
          </a>

          <a
            href={whatsappSosUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="min-h-[42px] px-3 rounded-xl bg-[#22c55e]/15 hover:bg-[#22c55e]/25 border border-[#22c55e]/45 text-[#4ade80] text-xs font-bold inline-flex items-center gap-1.5 shrink-0"
            title="Share live GPS location via WhatsApp"
          >
            <MessageSquareShare className="w-3.5 h-3.5" />
            <span>GPS SOS</span>
          </a>
        </div>

        {sosRoute && (
          <div className="rounded-xl bg-[#120f1a] border border-[#e6483d]/35 p-3 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[11px] uppercase tracking-wider font-bold text-[#e6483d]">
                  Live Emergency Route
                </div>
                <div className="text-xs font-semibold text-[#faf6f0] truncate">
                  {sosRoute.destinationName}
                </div>
                <div className="text-[11px] text-white/60 truncate">
                  {sosRoute.destinationAddress}
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="font-mono-tabular text-sm font-bold text-[#5eead4]">
                  {sosRoute.durationText}
                </div>
                <div className="font-mono-tabular text-[11px] text-white/65">
                  {sosRoute.distanceText}
                </div>
              </div>
            </div>

            {sosRoute.steps.length > 0 && (
              <ol className="max-h-32 overflow-y-auto noor-scroll space-y-1 pl-4 list-decimal text-[11px] text-white/80">
                {sosRoute.steps.slice(0, 12).map((st, idx) => (
                  <li key={idx}>
                    {st.instruction}{" "}
                    {st.distanceMeters > 0 && (
                      <span className="text-white/45 font-mono-tabular">
                        ({st.distanceMeters >= 1000
                          ? `${(st.distanceMeters / 1000).toFixed(1)} km`
                          : `${st.distanceMeters} m`})
                      </span>
                    )}
                  </li>
                ))}
              </ol>
            )}
          </div>
        )}
      </div>

      {/* Category Chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
        {CATEGORY_CONFIG.map((item) => {
          const Icon = item.icon;
          const active = category === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                setCategory(item.id);
                if (userCoords || customCityQuery.trim()) {
                  runNearbySearch(userCoords, item.id);
                }
              }}
              className={`min-h-[38px] px-2.5 rounded-xl border text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
                active
                  ? "bg-[#e6483d]/20 border-[#e6483d] text-[#faf6f0]"
                  : "bg-[#1c1826] border-white/10 text-white/75 hover:text-white"
              }`}
            >
              <Icon className="w-3.5 h-3.5 shrink-0" style={{ color: item.pinColor }} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* Live GPS Button + Area Input */}
      <div className="space-y-2">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => detectGpsAndSearch()}
            disabled={locating || searching}
            className="flex-1 min-h-[42px] px-3.5 rounded-xl bg-[#5eead4] hover:bg-[#4ad8c2] disabled:opacity-60 text-[#0e0c14] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            {locating ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Navigation className="w-4 h-4" />
            )}
            <span>{locating ? "Detecting GPS…" : "Use My Live GPS Location"}</span>
          </button>

          <label className="min-h-[42px] px-3 rounded-xl bg-[#1c1826] border border-white/10 flex items-center gap-2 text-xs text-white/80 cursor-pointer shrink-0">
            <input
              type="checkbox"
              checked={openNowOnly}
              onChange={(e) => {
                const next = e.target.checked;
                setOpenNowOnly(next);
                if (userCoords || customCityQuery.trim()) {
                  runNearbySearch(userCoords, category, undefined, next);
                }
              }}
              className="accent-[#5eead4] w-4 h-4"
            />
            <span>Open Now</span>
          </label>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            runNearbySearch(userCoords, category);
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={customCityQuery}
            onChange={(e) => setCustomCityQuery(e.target.value)}
            placeholder="Or enter any city/area worldwide (e.g., Gulberg Lahore, Deira Dubai, London)…"
            className="flex-1 min-h-[42px] px-3.5 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#5eead4]/50 outline-none text-xs text-[#faf6f0] placeholder:text-white/40"
          />
          <button
            type="submit"
            disabled={searching}
            className="min-h-[42px] px-3.5 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-45 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
          >
            {searching ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <Search className="w-4 h-4" />
            )}
            <span>Search</span>
          </button>
        </form>
      </div>

      {/* Exact Verified Local Time Bar */}
      {localTimeInfo && (
        <div className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl bg-[#1c1826] border border-[#5eead4]/25 text-xs">
          <span className="inline-flex items-center gap-1.5 text-[#5eead4] font-medium">
            <Clock className="w-3.5 h-3.5 shrink-0" />
            <span>{localTimeInfo.localTime}</span>
          </span>
          <span className="text-white/55 truncate">{localTimeInfo.timeZoneName}</span>
        </div>
      )}

      {/* Weather, Air Quality (AQI) & Pollen Alert Card */}
      {envInfo && (envInfo.weather || envInfo.airQuality || envInfo.pollen.length > 0) && (
        <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-3.5 space-y-2.5">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1.5 text-xs font-semibold text-[#faf6f0]">
              <CloudSun className="w-4 h-4 text-[#e8b86d]" />
              <span>Local Weather, Air Quality &amp; Pollen</span>
            </div>
            <button
              type="button"
              onClick={() => {
                const wxText = envInfo.weather?.tempC !== null && envInfo.weather
                  ? `Mausam ${envInfo.weather.condition || "clear"} hai, temperature ${Math.round(envInfo.weather.tempC)} degree Celsius. `
                  : "";
                const aqiText = envInfo.airQuality?.aqi !== null && envInfo.airQuality
                  ? `Hawa ki quality yaani AQI ${envInfo.airQuality.aqi} (${envInfo.airQuality.category}) hai. ${envInfo.airQuality.healthAdvice}`
                  : "";
                onSpeakResult(`[stethoscope] ${wxText}${aqiText}`);
              }}
              className="min-h-[28px] px-2.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-[11px] font-medium text-[#faf6f0] inline-flex items-center gap-1 cursor-pointer"
            >
              <Volume2 className="w-3 h-3 text-[#e8b86d]" />
              <span>Advice</span>
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            {envInfo.weather && (
              <div className="rounded-xl bg-[#120f1a] border border-white/10 p-2.5 space-y-0.5">
                <div className="text-[11px] text-white/55">Weather</div>
                <div className="font-mono-tabular font-bold text-sm text-[#faf6f0]">
                  {envInfo.weather.tempC !== null ? `${Math.round(envInfo.weather.tempC)}°C` : "—"}{" "}
                  <span className="font-normal text-xs text-white/75">{envInfo.weather.condition}</span>
                </div>
                <div className="text-[11px] text-white/55 font-mono-tabular">
                  {envInfo.weather.humidity !== null ? `Humidity ${envInfo.weather.humidity}%` : ""}
                  {envInfo.weather.uvIndex !== null ? ` · UV ${envInfo.weather.uvIndex}` : ""}
                </div>
              </div>
            )}

            {envInfo.airQuality && (
              <div className="rounded-xl bg-[#120f1a] border border-white/10 p-2.5 space-y-0.5">
                <div className="flex items-center gap-1 text-[11px] text-white/55">
                  <Wind className="w-3 h-3 text-[#5eead4]" />
                  <span>Air Quality (UAQI)</span>
                </div>
                <div className="font-mono-tabular font-bold text-sm text-[#5eead4]">
                  {envInfo.airQuality.aqi ?? "—"}{" "}
                  <span className="font-normal text-xs text-white/80">
                    {envInfo.airQuality.category}
                  </span>
                </div>
                {envInfo.airQuality.dominantPollutant && (
                  <div className="text-[11px] text-white/55 uppercase">
                    Main: {envInfo.airQuality.dominantPollutant}
                  </div>
                )}
              </div>
            )}
          </div>

          {envInfo.pollen.length > 0 && (
            <div className="text-[11px] text-white/70 flex flex-wrap gap-x-3 gap-y-1">
              {envInfo.pollen.map((p) => (
                <span key={p.code || p.name}>
                  <span className="text-[#e8b86d] font-medium">{p.name}:</span> {p.category}
                  {p.value !== null ? ` (${p.value})` : ""}
                </span>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Interactive Google Map */}
      {mapsApiKey ? (
        <div className="w-full h-[260px] rounded-2xl overflow-hidden border border-white/15 bg-[#0e0c14]">
          <APIProvider apiKey={mapsApiKey} language="en">
            <GoogleMap
              defaultCenter={activeCenter}
              defaultZoom={13}
              mapId="DEMO_MAP_ID"
              internalUsageAttributionIds={["gmp_mcp_codeassist_v1_aistudio"]}
              gestureHandling="greedy"
              disableDefaultUI={false}
              style={{ width: "100%", height: "100%" }}
              onClick={() => setSelectedPlace(null)}
            >
              <MapCameraSync center={activeCenter} selectedPlace={selectedPlace} />
              {sosRoute?.encodedPolyline && (
                <SosRoutePolylineOverlay encodedPolyline={sosRoute.encodedPolyline} />
              )}

              {userCoords && (
                <AdvancedMarker position={userCoords} title="Your Live Location">
                  <Pin background="#5eead4" glyphColor="#0e0c14" borderColor="#0e0c14" />
                </AdvancedMarker>
              )}

              {places.map((pl) => (
                <AdvancedMarker
                  key={pl.id}
                  position={{ lat: pl.lat, lng: pl.lng }}
                  title={pl.name}
                  onClick={() => setSelectedPlace(pl)}
                >
                  <Pin
                    background={activeCatMeta.pinColor}
                    glyphColor="#ffffff"
                    borderColor="#0e0c14"
                  />
                </AdvancedMarker>
              ))}

              {selectedPlace && (
                <InfoWindow
                  position={{ lat: selectedPlace.lat, lng: selectedPlace.lng }}
                  onCloseClick={() => setSelectedPlace(null)}
                >
                  <div className="text-[#111] max-w-[210px] space-y-1 p-0.5">
                    <div className="font-bold text-xs">{selectedPlace.name}</div>
                    <div className="text-[11px] text-gray-700">{selectedPlace.address}</div>
                    {selectedPlace.googleMapsUri && (
                      <a
                        href={selectedPlace.googleMapsUri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-block text-[11px] font-semibold text-blue-600 underline"
                      >
                        Open in Google Maps
                      </a>
                    )}
                  </div>
                </InfoWindow>
              )}
            </GoogleMap>
          </APIProvider>
        </div>
      ) : (
        <div className="p-3 rounded-xl bg-[#1c1826] border border-white/10 text-xs text-white/65">
          Tap <b>Use My Live GPS Location</b> or <b>Search</b> above to load verified nearby medical
          centers and Google Maps directions.
        </div>
      )}

      {/* Results List */}
      {searching && (
        <div className="flex items-center justify-center gap-2 py-4 text-xs text-white/70">
          <Loader2 className="w-4 h-4 animate-spin text-[#5eead4]" />
          <span>Checking verified Google Maps places near you…</span>
        </div>
      )}

      {!searching && places.length > 0 && (
        <div className="space-y-2.5">
          {places.map((pl, idx) => (
            <div
              key={pl.id}
              onClick={() => setSelectedPlace(pl)}
              className={`rounded-2xl p-3.5 border transition-colors cursor-pointer space-y-2 ${
                selectedPlace?.id === pl.id
                  ? "bg-[#251f33] border-[#5eead4]/55"
                  : "bg-[#1c1826] border-white/10 hover:border-white/20"
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-bold text-[#e8b86d]">#{idx + 1}</span>
                    <h3 className="text-sm font-semibold text-[#faf6f0] truncate">{pl.name}</h3>
                  </div>
                  <p className="text-xs text-white/65 mt-0.5 leading-snug">{pl.address}</p>
                </div>
                {typeof pl.distanceKm === "number" && (
                  <span className="text-[11px] font-mono-tabular font-semibold text-[#5eead4] shrink-0">
                    {pl.distanceKm.toFixed(1)} km
                  </span>
                )}
              </div>

              <div className="flex flex-wrap items-center gap-2 text-[11px]">
                {typeof pl.rating === "number" && (
                  <span className="text-[#e8b86d] font-semibold">
                    ★ {pl.rating.toFixed(1)}
                    {pl.userRatingCount ? ` (${pl.userRatingCount})` : ""}
                  </span>
                )}
                {typeof pl.openNow === "boolean" && (
                  <span
                    className={`font-semibold ${
                      pl.openNow ? "text-[#5eead4]" : "text-[#e6483d]"
                    }`}
                  >
                    {pl.openNow ? "Open Now" : "Closed Now"}
                  </span>
                )}
                {pl.phone && (
                  <a
                    href={`tel:${pl.phone}`}
                    onClick={(e) => e.stopPropagation()}
                    className="inline-flex items-center gap-1 text-white/80 hover:text-white"
                  >
                    <Phone className="w-3 h-3 text-[#5eead4]" />
                    <span>{pl.phone}</span>
                  </a>
                )}
              </div>

              <div className="flex flex-wrap gap-2 pt-1">
                {userCoords && (
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      void computeRouteToPlace(userCoords, pl, false);
                    }}
                    className="min-h-[32px] px-3 rounded-lg bg-[#e6483d]/15 hover:bg-[#e6483d]/25 border border-[#e6483d]/45 text-[11px] font-semibold text-[#faf6f0] inline-flex items-center gap-1.5 cursor-pointer"
                  >
                    <Route className="w-3.5 h-3.5 text-[#e6483d]" />
                    <span>Show Live Route</span>
                  </button>
                )}
                {pl.googleMapsUri && (
                  <a
                    href={pl.googleMapsUri}
                    target="_blank"
                    rel="noopener noreferrer"
                    onClick={(e) => e.stopPropagation()}
                    className="min-h-[32px] px-3 rounded-lg bg-[#5eead4]/15 hover:bg-[#5eead4]/25 border border-[#5eead4]/40 text-[11px] font-semibold text-[#5eead4] inline-flex items-center gap-1.5"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                    <span>Google Maps</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSpeakResult(
                      `[stethoscope] ${pl.name}, address ${pl.address}${
                        typeof pl.distanceKm === "number"
                          ? `, aap se taqreeban ${pl.distanceKm.toFixed(1)} kilometer door hai`
                          : ""
                      }.`
                    );
                  }}
                  className="min-h-[32px] px-2.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-[11px] font-medium text-[#faf6f0] inline-flex items-center gap-1 cursor-pointer"
                >
                  <Volume2 className="w-3.5 h-3.5 text-[#e8b86d]" />
                  <span>Speak</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {!searching && hasSearchedOnce && places.length === 0 && (
        <div className="p-4 rounded-2xl bg-[#1c1826] border border-white/10 text-xs text-white/70 text-center">
          Is area mein koi result nahi mila — apna shehar/ilaaqa likh kar Search dabayein.
        </div>
      )}
    </div>
  );
}
