import { useEffect, useRef, useState } from "react";
import {
  AlertCircle,
  AlertTriangle,
  Barcode,
  Calculator,
  Camera,
  CheckCircle2,
  ClipboardPlus,
  ExternalLink,
  FileText,
  FolderHeart,
  HeartPulse,
  Loader2,
  MapPin,
  MessageSquarePlus,
  Pill,
  Search,
  ShieldAlert,
  Stethoscope,
  Thermometer,
  Trash2,
  Upload,
  Video,
  Volume2,
  X,
} from "lucide-react";
import type {
  AiVitalState,
  DoseCalculationResult,
  MedicalReportRecord,
  MedicineGuideResult,
  TriageResult,
  VisionAnalysis,
  VoiceSettings,
} from "../types/noor";
import { HeartHealthMonitor, HeartHealthStrip } from "./HeartHealthMonitor";
import { NearbyMedicalFinder } from "./NearbyMedicalFinder";

const URDU_RE = /[\u0600-\u06ff]/;

interface ClinicToolResult {
  title: string;
  safetyLevel: "safe_with_care" | "caution" | "avoid_or_urgent";
  noorSummary: string;
  steps: string[];
  avoidOrWarnings: string[];
  sources?: Array<{ title: string; uri: string }>;
}

interface ClinicPanelProps {
  language: VoiceSettings["lang"];
  familyMode: boolean;
  aiState?: AiVitalState;
  noorName?: string;
  requestedSubTab?: "medicine" | "nearby" | "heart" | "vision" | "triage" | "safety";
  userCoords: { lat: number; lng: number } | null;
  onCoordsUpdate: (coords: { lat: number; lng: number }) => void;
  reports?: MedicalReportRecord[];
  onSaveReport?: (report: MedicalReportRecord) => void;
  onDeleteReport?: (id: string) => void;
  onSpeakResult: (taggedText: string) => void;
  onAddToChat: (text: string, imagePreview?: string) => void;
  onToast: (msg: string) => void;
}

const AGE_GROUPS = [
  "Infant (0-12 mos)",
  "Toddler (1-5 yrs)",
  "Child (6-12 yrs)",
  "Teen / Adult",
];

const DURATIONS = ["Just started", "1-2 days", "3+ days", "Over a week"];

const SYMPTOMS = [
  "Fever",
  "Cough / Cold",
  "Sore Throat",
  "Tummy / Vomiting",
  "Skin Rash",
  "Ear Pain",
  "Low Appetite",
  "Tiredness",
];

async function readAndProcessFile(
  file: File
): Promise<{ dataUrl: string; base64: string; mimeType: string; isPdf: boolean; fileName: string }> {
  const isPdf = file.type === "application/pdf" || /\.pdf$/i.test(file.name);
  const rawUrl = await new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });

  if (isPdf) {
    return {
      dataUrl: rawUrl,
      base64: rawUrl.split(",")[1] || "",
      mimeType: "application/pdf",
      isPdf: true,
      fileName: file.name,
    };
  }

  const img = await new Promise<HTMLImageElement>((resolve, reject) => {
    const el = new Image();
    el.onload = () => resolve(el);
    el.onerror = reject;
    el.src = rawUrl;
  });

  const maxSide = 1280;
  const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
  const w = Math.max(1, Math.round(img.width * scale));
  const h = Math.max(1, Math.round(img.height * scale));
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  ctx?.drawImage(img, 0, 0, w, h);
  const dataUrl = canvas.toDataURL("image/jpeg", 0.86);
  return {
    dataUrl,
    base64: dataUrl.split(",")[1] || "",
    mimeType: "image/jpeg",
    isPdf: false,
    fileName: file.name,
  };
}

function UrgencyBadge({ urgency }: { urgency: "routine" | "consult_soon" | "urgent" }) {
  if (urgency === "urgent") {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#e6483d]">
        <AlertTriangle className="w-4 h-4 shrink-0" />
        Seek Urgent Medical Care
      </span>
    );
  }
  if (urgency === "consult_soon") {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#e8b86d]">
        <AlertCircle className="w-4 h-4 shrink-0" />
        Consult a Doctor Soon
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#5eead4]">
      <CheckCircle2 className="w-4 h-4 shrink-0" />
      Routine Comfort Care
    </span>
  );
}

export function ClinicPanel({
  language,
  familyMode,
  aiState = "idle",
  noorName = "Noor Haram",
  requestedSubTab,
  userCoords,
  onCoordsUpdate,
  reports = [],
  onSaveReport,
  onDeleteReport,
  onSpeakResult,
  onAddToChat,
  onToast,
}: ClinicPanelProps) {
  const [subTab, setSubTab] = useState<
    "medicine" | "nearby" | "heart" | "vision" | "triage" | "safety"
  >(requestedSubTab || "medicine");

  useEffect(() => {
    if (requestedSubTab) setSubTab(requestedSubTab);
  }, [requestedSubTab]);

  // Medicine & Illness Lookup state
  const [medQuery, setMedQuery] = useState("");
  const [medBusy, setMedBusy] = useState(false);
  const [medResult, setMedResult] = useState<MedicineGuideResult | null>(null);

  // Weight & Age Dose Calculator state
  const [doseMedName, setDoseMedName] = useState("");
  const [doseWeightKg, setDoseWeightKg] = useState("14");
  const [doseAgeBand, setDoseAgeBand] = useState(AGE_GROUPS[1]);
  const [doseBusy, setDoseBusy] = useState(false);
  const [doseResult, setDoseResult] = useState<DoseCalculationResult | null>(null);

  // Vision Doctor + Live Camera state
  const fileRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [imagePreview, setImagePreview] = useState("");
  const [imageBase64, setImageBase64] = useState("");
  const [fileMimeType, setFileMimeType] = useState("image/jpeg");
  const [pdfFileName, setPdfFileName] = useState("");
  const [visionQuestion, setVisionQuestion] = useState("");
  const [visionBusy, setVisionBusy] = useState(false);
  const [visionResult, setVisionResult] = useState<VisionAnalysis | null>(null);

  // Symptom Triage state
  const [ageGroup, setAgeGroup] = useState(AGE_GROUPS[1]);
  const [tempF, setTempF] = useState(99.5);
  const [duration, setDuration] = useState(DURATIONS[0]);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>(["Fever"]);
  const [triageNotes, setTriageNotes] = useState("");
  const [triageBusy, setTriageBusy] = useState(false);
  const [triageResult, setTriageResult] = useState<TriageResult | null>(null);

  // Interaction Safety & First Aid state
  const [mixInput, setMixInput] = useState("");
  const [safetyBusy, setSafetyBusy] = useState(false);
  const [safetyResult, setSafetyResult] = useState<ClinicToolResult | null>(null);

  const tempC = (((tempF - 32) * 5) / 9).toFixed(1);

  const stopCamera = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    setCameraActive(false);
  };

  useEffect(() => {
    return () => stopCamera();
  }, []);

  useEffect(() => {
    if (cameraActive && videoRef.current && streamRef.current) {
      videoRef.current.srcObject = streamRef.current;
    }
  }, [cameraActive]);

  const startCamera = async () => {
    if (!navigator.mediaDevices?.getUserMedia) {
      onToast("Live camera is not available in this browser.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: { ideal: "environment" } },
      });
      streamRef.current = stream;
      setCameraActive(true);
    } catch {
      onToast("Camera permission denied or camera unavailable.");
    }
  };

  const captureCameraFrame = () => {
    const video = videoRef.current;
    if (!video || video.videoWidth === 0) return;
    const max = 1280;
    const scale = Math.min(1, max / Math.max(video.videoWidth, video.videoHeight));
    const c = document.createElement("canvas");
    c.width = Math.round(video.videoWidth * scale);
    c.height = Math.round(video.videoHeight * scale);
    c.getContext("2d")?.drawImage(video, 0, 0, c.width, c.height);
    const dataUrl = c.toDataURL("image/jpeg", 0.88);
    setImagePreview(dataUrl);
    setImageBase64(dataUrl.split(",")[1] || "");
    setFileMimeType("image/jpeg");
    setPdfFileName("");
    setVisionResult(null);
    stopCamera();
  };

  const runMedicineLookup = async (qOverride?: string) => {
    const q = (qOverride ?? medQuery).trim();
    if (!q) {
      onToast("Please enter any medicine (dawai) or illness (marz) name.");
      return;
    }
    if (!navigator.onLine) {
      onToast("Online medicine lookup requires an active internet connection.");
      return;
    }
    setMedBusy(true);
    try {
      const res = await fetch("/api/medicine-guide", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          query: q,
          language: language === "auto" ? "roman" : language,
          mode: familyMode ? "family" : "public",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Lookup failed");
      setMedResult(data as MedicineGuideResult);
      if (data.noorSummary) onSpeakResult(data.noorSummary);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Medicine lookup failed");
    } finally {
      setMedBusy(false);
    }
  };

  const runDoseCalculation = async (e: React.FormEvent) => {
    e.preventDefault();
    const med = (doseMedName || medQuery).trim();
    const kg = Number(doseWeightKg);
    if (!med || !Number.isFinite(kg) || kg <= 0 || kg > 250) {
      onToast("Enter medicine name (e.g. Calpol Syrup / Panadol) and valid weight in kg.");
      return;
    }
    if (!navigator.onLine) {
      onToast("Online dose reference check requires an internet connection.");
      return;
    }
    setDoseBusy(true);
    try {
      const res = await fetch("/api/dose-calc", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          medicineName: med,
          weightKg: kg,
          ageBand: doseAgeBand,
          language: language === "auto" ? "roman" : language,
          mode: familyMode ? "family" : "public",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Dose calculation failed");
      setDoseResult(data as DoseCalculationResult);
      if (data.noorAdvice) onSpeakResult(data.noorAdvice);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Could not calculate reference dose.");
    } finally {
      setDoseBusy(false);
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const processed = await readAndProcessFile(file);
      setImagePreview(processed.isPdf ? "" : processed.dataUrl);
      setImageBase64(processed.base64);
      setFileMimeType(processed.mimeType);
      setPdfFileName(processed.isPdf ? processed.fileName : "");
      setVisionResult(null);
    } catch {
      onToast("Could not read that file. Please upload a clear photo or PDF report.");
    }
  };

  const runVisionAnalysis = async () => {
    if (!imageBase64) {
      onToast("Please snap or upload a prescription, PDF lab report, medicine box, or photo.");
      return;
    }
    if (!navigator.onLine) {
      onToast("Vision scan needs an active internet connection.");
      return;
    }

    setVisionBusy(true);
    try {
      const res = await fetch("/api/analyze-image", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          imageBase64,
          mimeType: fileMimeType,
          question: visionQuestion.trim(),
          language: language === "auto" ? "roman" : language,
          mode: familyMode ? "family" : "public",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not analyze image");
      const parsed = data as VisionAnalysis;
      setVisionResult(parsed);
      onSaveReport?.({
        id: `rep-${Date.now()}`,
        title: parsed.title || pdfFileName || "Medical Scan",
        urgency: parsed.urgency || "routine",
        noorReply: parsed.noorReply || "",
        keyFindings: Array.isArray(parsed.keyFindings) ? parsed.keyFindings : [],
        careSteps: Array.isArray(parsed.careSteps) ? parsed.careSteps : [],
        redFlags: Array.isArray(parsed.redFlags) ? parsed.redFlags : [],
        fileName: pdfFileName || "camera-scan.jpg",
        mimeType: fileMimeType,
        createdAt: Date.now(),
      });
      if (parsed.noorReply) onSpeakResult(parsed.noorReply);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Image analysis failed");
    } finally {
      setVisionBusy(false);
    }
  };

  const toggleSymptom = (sym: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(sym) ? prev.filter((s) => s !== sym) : [...prev, sym]
    );
  };

  const runTriage = async () => {
    if (!navigator.onLine) {
      onToast("AI Clinic checkup requires an internet connection.");
      return;
    }
    setTriageBusy(true);
    try {
      const res = await fetch("/api/triage", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ageGroup,
          tempF,
          duration,
          symptoms: selectedSymptoms,
          notes: triageNotes.trim(),
          language: language === "auto" ? "roman" : language,
          mode: familyMode ? "family" : "public",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Could not complete checkup");
      setTriageResult(data as TriageResult);
      if (data.noorMessage) onSpeakResult(data.noorMessage);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Checkup failed");
    } finally {
      setTriageBusy(false);
    }
  };

  const runClinicTool = async (tool: "interaction" | "first_aid", customInput?: string) => {
    const val = (customInput ?? mixInput).trim();
    if (!val) {
      onToast("Please enter medicine names or select a first-aid topic.");
      return;
    }
    if (!navigator.onLine) {
      onToast("Online safety check requires an active internet connection.");
      return;
    }
    setSafetyBusy(true);
    try {
      const res = await fetch("/api/clinic-tools", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tool,
          input: val,
          language: language === "auto" ? "roman" : language,
          mode: familyMode ? "family" : "public",
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Check failed");
      setSafetyResult(data as ClinicToolResult);
      if (data.noorSummary) onSpeakResult(data.noorSummary);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Safety check failed");
    } finally {
      setSafetyBusy(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#15121e]">
      {/* Sub-navigation */}
      <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/10 overflow-x-auto noor-scroll">
        <button
          type="button"
          onClick={() => setSubTab("medicine")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "medicine"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Pill className="w-3.5 h-3.5 text-[#5eead4]" />
          <span>Dawai &amp; Ilaj</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab("nearby")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "nearby"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <MapPin className="w-3.5 h-3.5 text-[#5eead4]" />
          <span>Hospitals &amp; Labs</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab("vision")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "vision"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Camera className="w-3.5 h-3.5 text-[#e8b86d]" />
          <span>Live Scan</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab("triage")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "triage"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Thermometer className="w-3.5 h-3.5 text-[#e6483d]" />
          <span>Checkup</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab("heart")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "heart"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <HeartPulse className="w-3.5 h-3.5 text-[#e6483d]" />
          <span>Heart Health</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab("safety")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "safety"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <ShieldAlert className="w-3.5 h-3.5 text-[#e8b86d]" />
          <span>First Aid &amp; Mix</span>
        </button>
      </div>

      {subTab !== "heart" && (
        <HeartHealthStrip
          aiState={aiState}
          onOpenHeartTab={() => setSubTab("heart")}
        />
      )}

      <div className="flex-1 overflow-y-auto noor-scroll p-4 space-y-5">
        {subTab === "heart" && (
          <HeartHealthMonitor
            aiState={aiState}
            noorName={noorName}
            language={language}
            onSpeakResult={onSpeakResult}
            onOpenTriage={() => setSubTab("triage")}
            onOpenNearby={() => setSubTab("nearby")}
          />
        )}

        {subTab === "nearby" && (
          <NearbyMedicalFinder
            language={language}
            userCoords={userCoords}
            onCoordsUpdate={onCoordsUpdate}
            onSpeakResult={onSpeakResult}
            onToast={onToast}
          />
        )}

        {subTab === "medicine" && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-[#faf6f0]">
                Medicine (Dawai) &amp; Illness (Marz) Explorer
              </h2>
              <p className="text-xs text-white/60 leading-relaxed">
                Search any medicine, tablet, syrup, or illness online. Dr. Noor checks verified
                medical references and explains uses, precautions, and safe care.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                runMedicineLookup();
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={medQuery}
                onChange={(e) => setMedQuery(e.target.value)}
                placeholder="e.g., Panadol, Calpol, ORS, Asthma, Malaria…"
                className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#5eead4]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40"
              />
              <button
                type="submit"
                disabled={medBusy || !medQuery.trim()}
                className="min-h-[44px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-45 text-white text-sm font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                {medBusy ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <Search className="w-4 h-4" />
                )}
                <span>Check</span>
              </button>
            </form>

            <div className="flex flex-wrap gap-1.5">
              {["Panadol / Paracetamol", "ORS Hydration", "Dengue Fever", "Chest Cough"].map(
                (sample) => (
                  <button
                    key={sample}
                    type="button"
                    onClick={() => {
                      setMedQuery(sample);
                      runMedicineLookup(sample);
                    }}
                    className="px-2.5 py-1.5 rounded-lg bg-[#1c1826] hover:bg-[#272136] border border-white/10 text-xs text-white/80 cursor-pointer"
                  >
                    {sample}
                  </button>
                )
              )}
            </div>

            {medResult && (
              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-[#5eead4]">
                      {medResult.category}
                    </span>
                    <h3 className="text-sm font-semibold text-[#faf6f0]">{medResult.name}</h3>
                  </div>
                  <button
                    type="button"
                    onClick={() => onSpeakResult(medResult.noorSummary)}
                    className="min-h-[34px] px-3 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-[#e8b86d]" />
                    <span>Read Aloud</span>
                  </button>
                </div>

                <p
                  className={`text-sm leading-relaxed text-[#faf6f0]/90 ${
                    URDU_RE.test(medResult.noorSummary) ? "font-urdu text-base" : ""
                  }`}
                >
                  {medResult.noorSummary.replace(/\[(\w+)\]/g, "").trim()}
                </p>

                {medResult.uses?.length > 0 && (
                  <div className="space-y-1">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e8b86d]">
                      Uses &amp; Overview
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {medResult.uses.map((u, idx) => (
                        <li key={idx}>{u}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {medResult.howToUseSafely?.length > 0 && (
                  <div className="space-y-1">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#5eead4]">
                      Safe Guidance
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {medResult.howToUseSafely.map((u, idx) => (
                        <li key={idx}>{u}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {medResult.precautionsAndSideEffects?.length > 0 && (
                  <div className="space-y-1">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-white/75">
                      Precautions &amp; Side Effects
                    </h4>
                    <ul className="space-y-1 text-xs text-white/75 list-disc pl-4">
                      {medResult.precautionsAndSideEffects.map((u, idx) => (
                        <li key={idx}>{u}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {medResult.whenToSeeDoctor?.length > 0 && (
                  <div className="space-y-1 rounded-xl bg-[#e6483d]/10 border border-[#e6483d]/25 p-3">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e6483d]">
                      When to Consult a Doctor Immediately
                    </h4>
                    <ul className="space-y-1 text-xs text-[#faf6f0]/85 list-disc pl-4">
                      {medResult.whenToSeeDoctor.map((u, idx) => (
                        <li key={idx}>{u}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {medResult.sources && medResult.sources.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {medResult.sources.slice(0, 4).map((s) => (
                      <a
                        key={s.uri}
                        href={s.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-[#5eead4] hover:underline"
                      >
                        <ExternalLink className="w-3 h-3 shrink-0" />
                        <span className="truncate max-w-[180px]">{s.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Weight & Age Medicine Dose Calculator + Box/Barcode Scan Shortcut */}
            <form
              onSubmit={runDoseCalculation}
              className="rounded-2xl bg-[#1c1826] border border-[#5eead4]/25 p-4 space-y-3"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <Calculator className="w-4 h-4 text-[#5eead4]" />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-[#5eead4]">
                    Weight &amp; Age Dose Calculator
                  </h3>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setVisionQuestion(
                      "Read this medicine box name, strength (mg/ml), expiry date, barcode digits, and safe usage."
                    );
                    setSubTab("vision");
                  }}
                  className="px-2.5 py-1 rounded-lg bg-[#e8b86d]/15 hover:bg-[#e8b86d]/25 border border-[#e8b86d]/40 text-[11px] font-semibold text-[#e8b86d] inline-flex items-center gap-1 cursor-pointer"
                >
                  <Barcode className="w-3.5 h-3.5" />
                  <span>Scan Box / Barcode</span>
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                <input
                  type="text"
                  value={doseMedName}
                  onChange={(e) => setDoseMedName(e.target.value)}
                  placeholder="Medicine (e.g. Calpol 120mg/5ml)"
                  className="sm:col-span-2 min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
                <input
                  type="number"
                  min={1}
                  max={250}
                  step="0.5"
                  value={doseWeightKg}
                  onChange={(e) => setDoseWeightKg(e.target.value)}
                  placeholder="Weight kg"
                  aria-label="Patient weight in kg"
                  className="min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] outline-none"
                />
              </div>

              <div className="flex gap-2">
                <select
                  value={doseAgeBand}
                  onChange={(e) => setDoseAgeBand(e.target.value)}
                  aria-label="Patient age group"
                  className="flex-1 min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs text-[#faf6f0] outline-none"
                >
                  {AGE_GROUPS.map((ag) => (
                    <option key={ag} value={ag}>
                      {ag}
                    </option>
                  ))}
                </select>
                <button
                  type="submit"
                  disabled={doseBusy}
                  className="min-h-[40px] px-4 rounded-xl bg-[#5eead4] hover:bg-[#49d9c2] disabled:opacity-50 text-[#0e0c14] text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  {doseBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Calculator className="w-3.5 h-3.5" />}
                  <span>Calculate</span>
                </button>
              </div>

              {doseResult && (
                <div className="rounded-xl bg-[#120f1a] border border-white/10 p-3 space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="text-xs font-semibold text-[#faf6f0]">
                        {doseResult.medicineName} ({doseResult.patientWeightKg} kg · {doseResult.patientAgeLabel})
                      </div>
                      <div className="text-xs font-bold text-[#5eead4] mt-0.5">
                        {doseResult.estimatedDoseText}
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => onSpeakResult(doseResult.noorAdvice)}
                      className="min-h-[30px] px-2.5 rounded-lg bg-white/[0.06] border border-white/10 text-[11px] font-medium text-[#faf6f0] inline-flex items-center gap-1 cursor-pointer shrink-0"
                    >
                      <Volume2 className="w-3 h-3 text-[#e8b86d]" />
                      <span>Hear</span>
                    </button>
                  </div>
                  <div className="text-[11px] text-white/75">
                    <b>Schedule:</b> {doseResult.frequencyText} · <b>Max:</b> {doseResult.maxDailyLimit}
                  </div>
                  <p className="text-xs leading-relaxed text-[#faf6f0]/90">
                    {doseResult.noorAdvice.replace(/\[(\w+)\]/g, "").trim()}
                  </p>
                  {doseResult.safetyWarnings?.length > 0 && (
                    <ul className="space-y-1 text-[11px] text-[#e8b86d] list-disc pl-4">
                      {doseResult.safetyWarnings.map((w, i) => (
                        <li key={i}>{w}</li>
                      ))}
                    </ul>
                  )}
                </div>
              )}
            </form>
          </div>
        )}

        {subTab === "vision" && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-[#faf6f0]">
                Live Camera &amp; Prescription Scanner
              </h2>
              <p className="text-xs text-white/60 leading-relaxed">
                Point your camera live or upload a photo of a medicine box, doctor note, lab test,
                thermometer, or symptom for Dr. Noor to examine.
              </p>
            </div>

            <input
              ref={fileRef}
              type="file"
              accept="image/*,application/pdf,.pdf"
              onChange={handleFileChange}
              className="hidden"
            />

            {cameraActive ? (
              <div className="relative rounded-2xl overflow-hidden border border-[#5eead4]/40 bg-black space-y-2 p-2">
                <video
                  ref={videoRef}
                  autoPlay
                  playsInline
                  muted
                  className="w-full max-h-60 rounded-xl object-cover"
                />
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={captureCameraFrame}
                    className="flex-1 min-h-[42px] rounded-xl bg-[#e6483d] hover:bg-[#d13b30] text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Capture Photo</span>
                  </button>
                  <button
                    type="button"
                    onClick={stopCamera}
                    className="min-h-[42px] px-4 rounded-xl bg-white/10 text-xs font-medium text-white cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : !imagePreview && !pdfFileName ? (
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={startCamera}
                  className="py-7 px-3 rounded-2xl border border-dashed border-[#5eead4]/40 hover:border-[#5eead4] bg-[#1c1826]/70 hover:bg-[#1c1826] transition-colors flex flex-col items-center gap-2 cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#5eead4]/15 text-[#5eead4] flex items-center justify-center">
                    <Video className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-semibold text-[#faf6f0]">
                    Open Live Camera
                  </span>
                  <span className="text-[11px] text-white/50 text-center">
                    Snap medicine or report
                  </span>
                </button>

                <button
                  type="button"
                  onClick={() => fileRef.current?.click()}
                  className="py-7 px-3 rounded-2xl border border-dashed border-white/20 hover:border-[#e8b86d]/60 bg-[#1c1826]/60 hover:bg-[#1c1826] transition-colors flex flex-col items-center gap-2 cursor-pointer"
                >
                  <div className="w-10 h-10 rounded-xl bg-[#e8b86d]/15 text-[#e8b86d] flex items-center justify-center">
                    <Upload className="w-5 h-5" />
                  </div>
                  <span className="text-xs font-semibold text-[#faf6f0]">
                    Upload Photo / PDF
                  </span>
                  <span className="text-[11px] text-white/50 text-center">
                    Lab PDFs &amp; prescriptions
                  </span>
                </button>
              </div>
            ) : (
              <div className="relative rounded-2xl overflow-hidden border border-white/15 bg-[#0e0c14]">
                {pdfFileName ? (
                  <div className="flex items-center gap-3 p-4 pr-14">
                    <div className="w-11 h-11 rounded-xl bg-[#e6483d]/15 border border-[#e6483d]/40 text-[#e6483d] flex items-center justify-center shrink-0">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-[#faf6f0] truncate">
                        {pdfFileName}
                      </div>
                      <div className="text-[11px] text-[#5eead4]">
                        PDF Lab Report Ready for Analysis
                      </div>
                    </div>
                  </div>
                ) : (
                  <img
                    src={imagePreview}
                    alt="Selected medical photo preview"
                    className="w-full max-h-56 object-contain mx-auto"
                  />
                )}
                <button
                  type="button"
                  onClick={() => {
                    setImagePreview("");
                    setImageBase64("");
                    setFileMimeType("image/jpeg");
                    setPdfFileName("");
                    setVisionResult(null);
                  }}
                  aria-label="Remove file"
                  className="absolute top-2.5 right-2.5 w-9 h-9 rounded-lg bg-[#0e0c14]/85 hover:bg-[#e6483d] text-white flex items-center justify-center border border-white/15 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="space-y-2">
              <label htmlFor="vision-q" className="block text-xs font-medium text-white/75">
                Optional question (Roman Urdu, اردو, or English)
              </label>
              <input
                id="vision-q"
                type="text"
                value={visionQuestion}
                onChange={(e) => setVisionQuestion(e.target.value)}
                placeholder="e.g., Is report mein kya likha hai? Yeh dawai kis liye hai?"
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#e8b86d]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40"
              />
            </div>

            <button
              type="button"
              onClick={runVisionAnalysis}
              disabled={!imageBase64 || visionBusy}
              className="w-full min-h-[44px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-45 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {visionBusy ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Dr. Noor is examining…</span>
                </>
              ) : (
                <>
                  <Stethoscope className="w-4 h-4" />
                  <span>Analyze with Dr. Noor</span>
                </>
              )}
            </button>

            {visionResult && (
              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <h3 className="text-sm font-semibold text-[#faf6f0]">{visionResult.title}</h3>
                  <UrgencyBadge urgency={visionResult.urgency} />
                </div>

                <p
                  className={`text-sm leading-relaxed text-[#faf6f0]/90 ${
                    URDU_RE.test(visionResult.noorReply) ? "font-urdu text-base" : ""
                  }`}
                >
                  {visionResult.noorReply.replace(/\[(\w+)\]/g, "").trim()}
                </p>

                {visionResult.keyFindings?.length > 0 && (
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e8b86d]">
                      Key Findings
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {visionResult.keyFindings.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {visionResult.careSteps?.length > 0 && (
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#5eead4]">
                      Safe Next Steps
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {visionResult.careSteps.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {visionResult.redFlags?.length > 0 && (
                  <div className="space-y-1.5 rounded-xl bg-[#e6483d]/10 border border-[#e6483d]/25 p-3">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e6483d]">
                      See a Doctor Immediately If
                    </h4>
                    <ul className="space-y-1 text-xs text-[#faf6f0]/85 list-disc pl-4">
                      {visionResult.redFlags.map((item, idx) => (
                        <li key={idx}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                <div className="flex flex-wrap gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => onSpeakResult(visionResult.noorReply)}
                    className="min-h-[38px] px-3.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-[#e8b86d]" />
                    <span>Hear Again</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      onAddToChat(
                        `Vision Check — ${visionResult.title}: ${visionResult.noorReply.replace(/\[(\w+)\]/g, "").trim()}`,
                        imagePreview
                      )
                    }
                    className="min-h-[38px] px-3.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                  >
                    <MessageSquarePlus className="w-3.5 h-3.5 text-[#5eead4]" />
                    <span>Save to Chat</span>
                  </button>
                </div>
              </div>
            )}

            {/* Feature 7: Cloud Medical Report Vault History */}
            <div className="rounded-2xl bg-[#1c1826]/70 border border-white/10 p-3.5 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-1.5">
                  <FolderHeart className="w-4 h-4 text-[#5eead4]" />
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-[#5eead4]">
                    Saved Medical Report Vault ({reports.length})
                  </h3>
                </div>
                <span className="text-[10px] text-white/50">Auto-Synced</span>
              </div>

              {reports.length === 0 ? (
                <p className="text-xs text-white/55">
                  Every scanned prescription, medicine box, barcode, or lab PDF is automatically saved here.
                </p>
              ) : (
                <div className="space-y-2 max-h-64 overflow-y-auto noor-scroll pr-0.5">
                  {reports.map((rep) => (
                    <div
                      key={rep.id}
                      className="rounded-xl bg-[#120f1a] border border-white/10 p-3 space-y-1.5"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0">
                          <div className="text-xs font-semibold text-[#faf6f0] truncate">
                            {rep.title}
                          </div>
                          <div className="text-[10px] text-white/45 flex items-center gap-2">
                            <span>{new Date(rep.createdAt).toLocaleString()}</span>
                            {rep.fileName && <span className="truncate">· {rep.fileName}</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <UrgencyBadge urgency={rep.urgency} />
                          {onDeleteReport && (
                            <button
                              type="button"
                              onClick={() => onDeleteReport(rep.id)}
                              aria-label="Delete saved report"
                              className="w-7 h-7 rounded-lg hover:bg-white/10 text-white/45 hover:text-[#e6483d] flex items-center justify-center cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </div>
                      <p className="text-[11px] text-white/75 line-clamp-2">
                        {rep.noorReply.replace(/\[(\w+)\]/g, "").trim()}
                      </p>
                      <div className="flex flex-wrap gap-1.5 pt-0.5">
                        <button
                          type="button"
                          onClick={() => onSpeakResult(rep.noorReply)}
                          className="px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-[11px] text-[#faf6f0] inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Volume2 className="w-3 h-3 text-[#e8b86d]" />
                          <span>Hear</span>
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            onAddToChat(
                              `Saved Report (${rep.title}): ${rep.noorReply.replace(/\[(\w+)\]/g, "").trim()}`
                            )
                          }
                          className="px-2.5 py-1 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-[11px] text-[#5eead4] inline-flex items-center gap-1 cursor-pointer"
                        >
                          <MessageSquarePlus className="w-3 h-3" />
                          <span>Discuss</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {subTab === "triage" && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-[#faf6f0]">
                Fever &amp; Symptom Checkup
              </h2>
              <p className="text-xs text-white/60 leading-relaxed">
                Select age, fever temperature, and symptoms for safe home comfort steps and when to
                visit a pediatrician.
              </p>
            </div>

            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-white/75">Patient Age</span>
              <div className="grid grid-cols-2 gap-2">
                {AGE_GROUPS.map((ag) => (
                  <button
                    key={ag}
                    type="button"
                    onClick={() => setAgeGroup(ag)}
                    className={`min-h-[40px] px-3 rounded-xl text-xs font-medium border text-left transition-colors cursor-pointer ${
                      ageGroup === ag
                        ? "bg-[#e8b86d]/15 border-[#e8b86d]/50 text-[#faf6f0]"
                        : "bg-[#1c1826] border-white/10 text-white/70 hover:text-white"
                    }`}
                  >
                    {ag}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <label htmlFor="temp-slider" className="text-xs font-medium text-white/80">
                  Temperature
                </label>
                <span
                  className={`font-mono-tabular text-sm font-semibold ${
                    tempF >= 102
                      ? "text-[#e6483d]"
                      : tempF >= 100.4
                        ? "text-[#e8b86d]"
                        : "text-[#5eead4]"
                  }`}
                >
                  {tempF.toFixed(1)}°F ({tempC}°C)
                </span>
              </div>
              <input
                id="temp-slider"
                type="range"
                min={96}
                max={105}
                step={0.1}
                value={tempF}
                onChange={(e) => setTempF(Number(e.target.value))}
                className="w-full accent-[#e6483d] cursor-pointer"
              />
              <div className="flex justify-between text-[11px] text-white/45 font-mono-tabular">
                <span>96.0°F</span>
                <span>98.6°F Normal</span>
                <span>100.4°F+ Fever</span>
                <span>105°F</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-white/75">How Long?</span>
              <div className="flex flex-wrap gap-2">
                {DURATIONS.map((d) => (
                  <button
                    key={d}
                    type="button"
                    onClick={() => setDuration(d)}
                    className={`min-h-[36px] px-3 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                      duration === d
                        ? "bg-[#e8b86d]/15 border-[#e8b86d]/50 text-[#faf6f0]"
                        : "bg-[#1c1826] border-white/10 text-white/70 hover:text-white"
                    }`}
                  >
                    {d}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <span className="block text-xs font-medium text-white/75">Symptoms</span>
              <div className="flex flex-wrap gap-2">
                {SYMPTOMS.map((sym) => {
                  const active = selectedSymptoms.includes(sym);
                  return (
                    <button
                      key={sym}
                      type="button"
                      onClick={() => toggleSymptom(sym)}
                      className={`min-h-[36px] px-3 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                        active
                          ? "bg-[#e6483d]/20 border-[#e6483d]/55 text-[#faf6f0]"
                          : "bg-[#1c1826] border-white/10 text-white/70 hover:text-white"
                      }`}
                    >
                      {sym}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-1.5">
              <label htmlFor="triage-notes" className="block text-xs font-medium text-white/75">
                Additional Notes (optional)
              </label>
              <textarea
                id="triage-notes"
                rows={2}
                value={triageNotes}
                onChange={(e) => setTriageNotes(e.target.value)}
                placeholder="e.g., Drinking water well, mild cough at night…"
                className="w-full p-3 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#e8b86d]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40 resize-none"
              />
            </div>

            <button
              type="button"
              onClick={runTriage}
              disabled={triageBusy}
              className="w-full min-h-[44px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-45 text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer"
            >
              {triageBusy ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Preparing Checkup…</span>
                </>
              ) : (
                <>
                  <ClipboardPlus className="w-4 h-4" />
                  <span>Get Dr. Noor&apos;s Checkup Guidance</span>
                </>
              )}
            </button>

            {triageResult && (
              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <UrgencyBadge urgency={triageResult.urgency} />
                  <button
                    type="button"
                    onClick={() => onSpeakResult(triageResult.noorMessage)}
                    className="min-h-[34px] px-3 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-[#e8b86d]" />
                    <span>Read Aloud</span>
                  </button>
                </div>

                <p className="text-xs font-medium text-white/75">{triageResult.summary}</p>
                <p
                  className={`text-sm leading-relaxed text-[#faf6f0] ${
                    URDU_RE.test(triageResult.noorMessage) ? "font-urdu text-base" : ""
                  }`}
                >
                  {triageResult.noorMessage.replace(/\[(\w+)\]/g, "").trim()}
                </p>

                {triageResult.homeCare?.length > 0 && (
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#5eead4]">
                      Comfort &amp; Home Care
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {triageResult.homeCare.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {triageResult.watchFor?.length > 0 && (
                  <div className="space-y-1.5 rounded-xl bg-[#e6483d]/10 border border-[#e6483d]/25 p-3">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e6483d]">
                      Warning Signs to Watch For
                    </h4>
                    <ul className="space-y-1 text-xs text-[#faf6f0]/85 list-disc pl-4">
                      {triageResult.watchFor.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {triageResult.doctorQuestions?.length > 0 && (
                  <div className="space-y-1.5">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e8b86d]">
                      Questions to Ask Your Pediatrician
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {triageResult.doctorQuestions.map((item, i) => (
                        <li key={i}>{item}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {subTab === "safety" && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-[#faf6f0]">
                Dawai Safety Check &amp; Emergency First Aid
              </h2>
              <p className="text-xs text-white/60 leading-relaxed">
                Check online if two medicines can be taken together safely, or get instant step-by-step
                first aid guidance.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                runClinicTool("interaction");
              }}
              className="flex gap-2"
            >
              <input
                type="text"
                value={mixInput}
                onChange={(e) => setMixInput(e.target.value)}
                placeholder="e.g., Panadol + Brufen, Augmentin + Milk…"
                className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#e8b86d]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40"
              />
              <button
                type="submit"
                disabled={safetyBusy || !mixInput.trim()}
                className="min-h-[44px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-45 text-white text-sm font-semibold flex items-center gap-1.5 cursor-pointer shrink-0"
              >
                {safetyBusy ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldAlert className="w-4 h-4" />}
                <span>Check</span>
              </button>
            </form>

            <div className="space-y-2">
              <span className="block text-xs font-medium text-white/75">
                Instant Online First-Aid Guides
              </span>
              <div className="flex flex-wrap gap-1.5">
                {[
                  "High Fever & Fits",
                  "Minor Burn First Aid",
                  "Choking Emergency",
                  "Dehydration / ORS",
                  "Nosebleed",
                  "Sudden Allergy Rash",
                ].map((topic) => (
                  <button
                    key={topic}
                    type="button"
                    disabled={safetyBusy}
                    onClick={() => runClinicTool("first_aid", topic)}
                    className="px-2.5 py-1.5 rounded-lg bg-[#1c1826] hover:bg-[#272136] border border-white/10 text-xs text-white/85 cursor-pointer"
                  >
                    {topic}
                  </button>
                ))}
              </div>
            </div>

            {safetyResult && (
              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <h3 className="text-sm font-semibold text-[#faf6f0]">{safetyResult.title}</h3>
                  <button
                    type="button"
                    onClick={() => onSpeakResult(safetyResult.noorSummary)}
                    className="min-h-[34px] px-3 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-[#e8b86d]" />
                    <span>Read Aloud</span>
                  </button>
                </div>

                <p
                  className={`text-sm leading-relaxed text-[#faf6f0]/90 ${
                    URDU_RE.test(safetyResult.noorSummary) ? "font-urdu text-base" : ""
                  }`}
                >
                  {safetyResult.noorSummary.replace(/\[(\w+)\]/g, "").trim()}
                </p>

                {safetyResult.steps?.length > 0 && (
                  <div className="space-y-1">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#5eead4]">
                      Safe Steps &amp; Guidance
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {safetyResult.steps.map((s, idx) => (
                        <li key={idx}>{s}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {safetyResult.avoidOrWarnings?.length > 0 && (
                  <div className="space-y-1 rounded-xl bg-[#e6483d]/10 border border-[#e6483d]/25 p-3">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e6483d]">
                      Avoid &amp; Urgent Warnings
                    </h4>
                    <ul className="space-y-1 text-xs text-[#faf6f0]/85 list-disc pl-4">
                      {safetyResult.avoidOrWarnings.map((w, idx) => (
                        <li key={idx}>{w}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {safetyResult.sources && safetyResult.sources.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {safetyResult.sources.slice(0, 4).map((s) => (
                      <a
                        key={s.uri}
                        href={s.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-[#5eead4] hover:underline"
                      >
                        <ExternalLink className="w-3 h-3 shrink-0" />
                        <span className="truncate max-w-[180px]">{s.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
