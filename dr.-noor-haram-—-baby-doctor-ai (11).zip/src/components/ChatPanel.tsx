import { useEffect, useRef, useState } from "react";
import {
  Camera,
  Download,
  ExternalLink,
  Globe,
  Send,
  Trash2,
} from "lucide-react";
import { stripTags } from "../lib/speechController";
import type { ChatMessage } from "../types/noor";

const URDU_RE = /[\u0600-\u06ff]/;

interface ChatPanelProps {
  messages: ChatMessage[];
  noorName: string;
  isBusy: boolean;
  useSearch: boolean;
  onToggleSearch: () => void;
  onSend: (text: string) => void;
  onOpenVision: () => void;
  onClearHistory: () => void;
  onExportHistory: () => void;
}

export function ChatPanel({
  messages,
  noorName,
  isBusy,
  useSearch,
  onToggleSearch,
  onSend,
  onOpenVision,
  onClearHistory,
  onExportHistory,
}: ChatPanelProps) {
  const [input, setInput] = useState("");
  const listRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = listRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, isBusy]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const v = input.trim();
    if (!v) return;
    setInput("");
    onSend(v);
  };

  return (
    <div className="flex flex-col h-full bg-[#15121e]">
      {/* Toolbar */}
      <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onToggleSearch}
            className={`min-h-[36px] px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              useSearch
                ? "bg-[#5eead4]/15 border-[#5eead4]/40 text-[#5eead4]"
                : "bg-white/[0.04] border-white/10 text-white/75 hover:text-white"
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>Online Check</span>
          </button>

          <button
            type="button"
            onClick={onOpenVision}
            className="min-h-[36px] px-3 py-1 rounded-lg text-xs font-medium flex items-center gap-1.5 bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-white/80 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Camera className="w-3.5 h-3.5 text-[#e8b86d]" />
            <span>Scan Report</span>
          </button>
        </div>

        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onExportHistory}
            title="Download conversation"
            aria-label="Download conversation"
            className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-white/[0.06] text-white/65 hover:text-white flex items-center justify-center transition-colors cursor-pointer"
          >
            <Download className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onClearHistory}
            title="Clear chat"
            aria-label="Clear chat"
            className="min-h-[36px] min-w-[36px] rounded-lg hover:bg-white/[0.06] text-white/65 hover:text-[#e6483d] flex items-center justify-center transition-colors cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Messages Feed */}
      <div ref={listRef} className="flex-1 overflow-y-auto noor-scroll p-4 space-y-3.5">
        {messages.length === 0 ? (
          <div className="py-8 px-3 text-center space-y-4">
            <p className="text-sm text-white/75 leading-relaxed">
              Ask Dr. {noorName.split(" ")[0]} anything in{" "}
              <span className="text-[#faf6f0] font-medium">Roman Urdu</span>,{" "}
              <span className="text-[#faf6f0] font-medium">Punjabi</span>,{" "}
              <span className="text-[#faf6f0] font-medium">اردو</span>, or{" "}
              <span className="text-[#faf6f0] font-medium">English</span> — medicines, illnesses,
              world facts, stories, duas, or tell her to play, run, jump, hug, or dance.
            </p>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                "Bachay ko bukhar ho to kya karein?",
                "Panadol kis marz ki dawai hai?",
                "Mere saath khelo aur jump karo!",
                "Hamare liye pyari dua karo",
              ].map((prompt) => (
                <button
                  key={prompt}
                  type="button"
                  onClick={() => onSend(prompt)}
                  className="px-3.5 py-2 rounded-xl bg-[#1c1826] hover:bg-[#272136] border border-white/10 text-xs font-medium text-white/85 transition-colors cursor-pointer"
                >
                  {prompt}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((m) => {
            const clean = m.role === "assistant" ? stripTags(m.content) : m.content;
            const isUrdu = URDU_RE.test(clean);
            const isUser = m.role === "user";
            return (
              <div
                key={m.id}
                className={`flex flex-col ${isUser ? "items-end" : "items-start"}`}
              >
                <div
                  className={`max-w-[90%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed whitespace-pre-wrap ${
                    isUser
                      ? "bg-[#2a2138] text-[#faf6f0] border border-white/10 rounded-br-sm"
                      : "bg-[#1c1826] text-[#faf6f0] border border-[#e8b86d]/20 rounded-bl-sm"
                  } ${isUrdu ? "font-urdu text-base" : ""}`}
                >
                  {m.imagePreview && (
                    <img
                      src={m.imagePreview}
                      alt="Uploaded medical scan"
                      className="max-h-40 rounded-xl mb-2 border border-white/10 object-cover"
                    />
                  )}
                  {clean || (isBusy && !isUser ? "…" : "")}
                </div>

                {m.sources && m.sources.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-2 max-w-[90%]">
                    {m.sources.slice(0, 4).map((src) => (
                      <a
                        key={src.uri}
                        href={src.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-[#5eead4] hover:underline"
                      >
                        <ExternalLink className="w-3 h-3 shrink-0" />
                        <span className="truncate max-w-[180px]">{src.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            );
          })
        )}

        {isBusy && (
          <div className="text-xs text-white/55 px-1">
            Dr. {noorName.split(" ")[0]} is checking…
          </div>
        )}
      </div>

      {/* Drawer Input */}
      <div className="p-3 border-t border-white/10 bg-[#120f1a]">
        <form onSubmit={handleSubmit} className="flex items-center gap-2">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={`Ask ${noorName.split(" ")[0]} anything…`}
            className="flex-1 min-w-0 min-h-[42px] px-3.5 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#e8b86d]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/45"
          />
          <button
            type="submit"
            disabled={!input.trim() || isBusy}
            aria-label="Send message"
            className="min-h-[42px] min-w-[42px] rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-40 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
