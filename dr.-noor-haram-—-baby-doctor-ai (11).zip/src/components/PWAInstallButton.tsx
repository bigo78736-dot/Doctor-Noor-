import { useState } from "react";
import {
  Check,
  Copy,
  Download,
  ExternalLink,
  FileDown,
  HardDriveDownload,
  MessageSquareShare,
  Share2,
  Smartphone,
  Users,
  X,
} from "lucide-react";
import { usePWAInstall } from "../hooks/usePWAInstall";
import type { FamilyRoomConfig } from "../types/noor";

interface PWAInstallButtonProps {
  shareUrl: string;
  activeRoom?: FamilyRoomConfig | null;
  onDownloadPortableApp: () => void;
  onShareApp: (urlOverride?: string) => Promise<void>;
  onDownloadBackup: () => void;
  onToast: (msg: string) => void;
}

export function PWAInstallButton({
  shareUrl,
  activeRoom,
  onDownloadPortableApp,
  onShareApp,
  onDownloadBackup,
  onToast,
}: PWAInstallButtonProps) {
  const { isInstallable, isInstalled, isIOS, inIframe, install } = usePWAInstall();
  const [showModal, setShowModal] = useState(false);
  const [copied, setCopied] = useState(false);
  const [includeRoomInvite, setIncludeRoomInvite] = useState(true);

  const effectiveShareUrl = (() => {
    if (!activeRoom || !includeRoomInvite) return shareUrl;
    try {
      const u = new URL(shareUrl);
      u.searchParams.set("room", activeRoom.roomCode);
      u.searchParams.set("key", activeRoom.passcode);
      return u.toString();
    } catch {
      const sep = shareUrl.includes("?") ? "&" : "?";
      return `${shareUrl}${sep}room=${encodeURIComponent(activeRoom.roomCode)}&key=${encodeURIComponent(activeRoom.passcode)}`;
    }
  })();

  const handleInstallClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) {
        onToast("Dr. Noor Haram App installed on your device!");
        setShowModal(false);
      }
      return;
    }
    if (typeof window !== "undefined") {
      const a = document.createElement("a");
      a.href = effectiveShareUrl || window.location.href;
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.click();
      onToast("Opened in full browser tab — tap Install / Add to Home Screen there.");
    }
  };

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(effectiveShareUrl);
      setCopied(true);
      onToast(
        activeRoom && includeRoomInvite
          ? "Family Room link copied — works on any phone worldwide!"
          : "Public link copied — works on any mobile phone!"
      );
      setTimeout(() => setCopied(false), 2200);
    } catch {
      onToast("Select and copy the public link shown above.");
    }
  };

  const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(
    activeRoom && includeRoomInvite
      ? `Assalam-o-Alaikum! Join our Dr. Noor Haram Family Room (${activeRoom.roomName}) & talk on any phone:\n${effectiveShareUrl}`
      : `Assalam-o-Alaikum! Talk to Dr. Noor Haram AI (Baby Doctor, Medicines, Nearby Hospitals & World Info) on any phone:\n${effectiveShareUrl}`
  )}`;

  return (
    <>
      <button
        type="button"
        onClick={() => setShowModal(true)}
        title="Share Public Mobile Link, Download App File, or Install on Phone"
        aria-label="Download & Share App"
        className="min-h-[36px] px-2.5 sm:px-3 rounded-xl bg-[#5eead4] hover:bg-[#49d9c2] text-[#0e0c14] text-xs font-bold flex items-center gap-1.5 shadow-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
      >
        <Download className="w-3.5 h-3.5 shrink-0" />
        <span>Share / App</span>
      </button>

      {showModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="Share, Download & Install Dr. Noor Haram App"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowModal(false);
          }}
        >
          <div className="w-full max-w-md rounded-3xl bg-[#15121e] border border-white/15 p-5 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto noor-scroll">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-[#5eead4]" />
                <h2 className="text-sm font-semibold text-[#faf6f0]">
                  Share on Any Mobile &amp; Install App
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowModal(false)}
                aria-label="Close download modal"
                className="w-8 h-8 rounded-lg hover:bg-white/10 text-white/70 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* 1. Public Shared Link Box (Works on ALL phones without owner login) */}
            <div className="rounded-2xl bg-[#1c1826] border border-[#5eead4]/35 p-3.5 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-semibold text-[#5eead4]">
                  Universal Public Mobile Link (All Phones)
                </span>
                <span className="text-[10px] text-white/55">Fast · Worldwide</span>
              </div>

              {activeRoom && (
                <label className="flex items-center justify-between gap-2 px-2.5 py-2 rounded-xl bg-[#0e0c14] border border-[#e8b86d]/35 text-[11px] text-[#faf6f0] cursor-pointer">
                  <span className="inline-flex items-center gap-1.5 min-w-0">
                    <Users className="w-3.5 h-3.5 text-[#e8b86d] shrink-0" />
                    <span className="truncate">
                      Include Family Room ({activeRoom.roomCode})
                    </span>
                  </span>
                  <input
                    type="checkbox"
                    checked={includeRoomInvite}
                    onChange={(e) => setIncludeRoomInvite(e.target.checked)}
                    className="accent-[#e8b86d] w-4 h-4 shrink-0"
                  />
                </label>
              )}

              <div className="flex items-center gap-1.5">
                <input
                  type="text"
                  readOnly
                  value={effectiveShareUrl}
                  onFocus={(e) => e.target.select()}
                  aria-label="Public shareable app URL"
                  className="flex-1 min-w-0 min-h-[38px] px-2.5 rounded-lg bg-[#0e0c14] border border-white/10 text-[11px] font-mono-tabular text-[#faf6f0] outline-none"
                />
                <button
                  type="button"
                  onClick={handleCopyLink}
                  className="min-h-[38px] px-3 rounded-lg bg-[#5eead4] hover:bg-[#49d9c2] text-[#0e0c14] text-xs font-bold flex items-center gap-1 cursor-pointer shrink-0"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? "Copied" : "Copy"}</span>
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[38px] px-3 rounded-xl bg-[#22c55e]/15 hover:bg-[#22c55e]/25 border border-[#22c55e]/45 text-[#4ade80] text-xs font-semibold flex items-center justify-center gap-1.5"
                >
                  <MessageSquareShare className="w-3.5 h-3.5 shrink-0" />
                  <span>WhatsApp Link</span>
                </a>
                <button
                  type="button"
                  onClick={async () => {
                    await onShareApp(effectiveShareUrl);
                  }}
                  className="min-h-[38px] px-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.12] border border-white/15 text-[#faf6f0] text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Share2 className="w-3.5 h-3.5 text-[#5eead4] shrink-0" />
                  <span>Share / File</span>
                </button>
              </div>
            </div>

            {/* 2. Auto-Download Portable App File */}
            <div className="space-y-2">
              <button
                type="button"
                onClick={() => {
                  onDownloadPortableApp();
                  setShowModal(false);
                }}
                className="w-full min-h-[44px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] text-white text-xs sm:text-sm font-bold flex items-center justify-center gap-2 shadow-lg cursor-pointer"
              >
                <FileDown className="w-4 h-4 shrink-0" />
                <span>Download Standalone App (.html)</span>
              </button>
              <p className="text-[11px] text-white/60 leading-relaxed px-1">
                Saves <code className="text-[#e8b86d]">Dr-Noor-Haram-App.html</code> connected to
                the public server so it works over WiFi on other phones too.
              </p>
            </div>

            {/* 3. Install to Phone Home Screen (PWA) */}
            {!isInstalled && (
              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-3.5 space-y-2.5">
                <span className="block text-xs font-semibold text-[#e8b86d]">
                  Install on Phone Home Screen
                </span>
                {isInstallable ? (
                  <button
                    type="button"
                    onClick={handleInstallClick}
                    className="w-full min-h-[40px] px-3.5 rounded-xl bg-[#e8b86d] text-[#0e0c14] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Download className="w-4 h-4" />
                    <span>Install App Now</span>
                  </button>
                ) : isIOS ? (
                  <p className="text-[11px] text-white/75 leading-relaxed">
                    Open the public link in Safari on iPhone/iPad, tap <strong>Share</strong>,
                    then tap <strong>Add to Home Screen</strong>.
                  </p>
                ) : (
                  <>
                    <p className="text-[11px] text-white/75 leading-relaxed">
                      Open the public link in Android Chrome, then tap{" "}
                      <strong>⋮ → Install app</strong> (or Add to Home Screen).
                    </p>
                    {inIframe && (
                      <button
                        type="button"
                        onClick={handleInstallClick}
                        className="w-full min-h-[38px] px-3 rounded-xl bg-white/[0.08] hover:bg-white/[0.14] border border-white/15 text-xs font-semibold text-[#faf6f0] flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <ExternalLink className="w-3.5 h-3.5 text-[#5eead4]" />
                        <span>Open Public Tab to Install</span>
                      </button>
                    )}
                  </>
                )}
              </div>
            )}

            {/* 4. Auto-Save Data Backup JSON */}
            <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#faf6f0]">
                  Auto-Save Memory Backup
                </span>
                <span className="text-[11px] text-[#5eead4] font-medium">Auto-Save Active</span>
              </div>
              <button
                type="button"
                onClick={() => {
                  onDownloadBackup();
                  setShowModal(false);
                }}
                className="w-full min-h-[38px] px-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <HardDriveDownload className="w-3.5 h-3.5 text-[#e8b86d]" />
                <span>Download Saved Data Backup (.json)</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
