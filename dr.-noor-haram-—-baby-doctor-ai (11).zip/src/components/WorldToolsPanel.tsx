import { useEffect, useRef, useState } from "react";
import {
  ArrowRightLeft,
  BookOpenCheck,
  ExternalLink,
  Globe,
  Languages,
  Loader2,
  MessageSquarePlus,
  Mic,
  Search,
  Sparkles,
  Square,
  Volume2,
} from "lucide-react";
import {
  float32ToInt16Base64,
  startMicPcmPipeline,
  type MicPipelineHandle,
} from "../lib/audioCapture";
import type { VoiceSettings } from "../types/noor";

const URDU_RE = /[\u0600-\u06ff]/;

interface EncyclopediaResult {
  title: string;
  category: string;
  noorSummary: string;
  keyFacts: string[];
  practicalTips: string[];
  sources?: Array<{ title: string; uri: string }>;
}

interface TranslateResult {
  detectedLanguage: string;
  translatedText: string;
  pronunciation: string;
  spokenSummary: string;
  tips: string[];
}

interface WorldToolsPanelProps {
  language: VoiceSettings["lang"];
  onSpeakResult: (taggedText: string) => void;
  onAddToChat: (summary: string) => void;
  onToast: (msg: string) => void;
}

const WORLD_TOPICS = [
  { label: "Global News Today", prompt: "Today's top verified global world news headlines" },
  { label: "Live Time & World", prompt: "Current exact date, time, and what is happening around the world today" },
  { label: "Science & Space", prompt: "Amazing science, space, and NASA discoveries this year" },
  { label: "Countries & Travel", prompt: "Best countries, passport/visa facts, and travel safety tips" },
  { label: "Islam & History", prompt: "Islamic golden age science, Makkah, Madinah, and inspiring history" },
  { label: "Currency & Gold", prompt: "Today's USD to PKR, SAR, AED, GBP, and gold rate overview" },
  { label: "Study & Coding", prompt: "How students anywhere in the world can learn AI, English, and science fast" },
  { label: "Healthy Food", prompt: "World's healthiest everyday foods, hydration, and nutrition facts" },
];

const TARGET_LANGUAGES: Array<{ label: string; code: string }> = [
  { label: "Roman Urdu", code: "ur" },
  { label: "Urdu (اردو)", code: "ur" },
  { label: "English", code: "en" },
  { label: "Arabic (العربية)", code: "ar" },
  { label: "Punjabi (پنجابی)", code: "pa" },
  { label: "Hindi (हिन्दी)", code: "hi" },
  { label: "Turkish (Türkçe)", code: "tr" },
  { label: "Spanish (Español)", code: "es" },
  { label: "French (Français)", code: "fr" },
  { label: "Chinese (中文)", code: "zh" },
];

export function WorldToolsPanel({
  language,
  onSpeakResult,
  onAddToChat,
  onToast,
}: WorldToolsPanelProps) {
  const [tab, setTab] = useState<"encyclopedia" | "translate">("encyclopedia");

  // World Encyclopedia + Deep Research state
  const [query, setQuery] = useState("");
  const [busyMode, setBusyMode] = useState<"none" | "encyclopedia" | "research">("none");
  const [encResult, setEncResult] = useState<EncyclopediaResult | null>(null);

  // Universal Translator + Real-Time Mic Stream state
  const [transText, setTransText] = useState("");
  const [targetLang, setTargetLang] = useState(TARGET_LANGUAGES[2].label);
  const [transBusy, setTransBusy] = useState(false);
  const [transResult, setTransResult] = useState<TranslateResult | null>(null);

  const [liveTransActive, setLiveTransActive] = useState(false);
  const [liveSourceStream, setLiveSourceStream] = useState("");
  const [liveTranslatedStream, setLiveTranslatedStream] = useState("");

  const liveWsRef = useRef<WebSocket | null>(null);
  const liveCtxRef = useRef<AudioContext | null>(null);
  const liveStreamRef = useRef<MediaStream | null>(null);
  const livePipeRef = useRef<MicPipelineHandle | null>(null);

  const stopLiveTranslate = () => {
    livePipeRef.current?.stop();
    livePipeRef.current = null;
    if (liveStreamRef.current) {
      liveStreamRef.current.getTracks().forEach((t) => t.stop());
      liveStreamRef.current = null;
    }
    if (liveCtxRef.current) {
      try {
        liveCtxRef.current.close();
      } catch {}
      liveCtxRef.current = null;
    }
    if (liveWsRef.current) {
      try {
        liveWsRef.current.close();
      } catch {}
      liveWsRef.current = null;
    }
    setLiveTransActive(false);
  };

  useEffect(() => {
    return () => stopLiveTranslate();
  }, []);

  useEffect(() => {
    if (tab !== "translate" && liveTransActive) {
      stopLiveTranslate();
    }
  }, [tab, liveTransActive]);

  const toggleLiveVoiceTranslate = async () => {
    if (liveTransActive) {
      stopLiveTranslate();
      return;
    }
    if (!navigator.onLine) {
      onToast("Live Voice Translator needs an active internet connection.");
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      onToast("Microphone is unavailable in this browser.");
      return;
    }

    const targetObj =
      TARGET_LANGUAGES.find((t) => t.label === targetLang) || TARGET_LANGUAGES[2];
    const sourceCode = language === "en" ? "en" : language === "pa" ? "pa" : "ur";
    const proto = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${proto}//${window.location.host}/ws/translate?source=${encodeURIComponent(
      sourceCode
    )}&target=${encodeURIComponent(targetObj.code)}`;

    setLiveSourceStream("");
    setLiveTranslatedStream("");
    setLiveTransActive(true);

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
      });
      liveStreamRef.current = stream;

      const ws = new WebSocket(wsUrl);
      liveWsRef.current = ws;

      ws.onmessage = async (ev) => {
        try {
          const msg = JSON.parse(String(ev.data || "{}"));
          if (msg.type === "ready") {
            const AC =
              window.AudioContext ||
              (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
            const ctx = new AC();
            liveCtxRef.current = ctx;
            livePipeRef.current = await startMicPcmPipeline(ctx, stream, (pcm16k) => {
              if (ws.readyState === WebSocket.OPEN) {
                ws.send(JSON.stringify({ type: "audio", data: float32ToInt16Base64(pcm16k) }));
              }
            });
          } else if (msg.type === "sourceTranscript" && msg.text) {
            setLiveSourceStream((prev) => `${prev} ${msg.text}`.trim());
          } else if (msg.type === "transcript" && msg.text) {
            setLiveTranslatedStream((prev) => `${prev} ${msg.text}`.trim());
          } else if (msg.type === "error") {
            onToast(msg.error || "Live translator error.");
            stopLiveTranslate();
          }
        } catch {}
      };

      ws.onerror = () => {
        onToast("Could not connect live translation stream.");
        stopLiveTranslate();
      };

      ws.onclose = () => {
        stopLiveTranslate();
      };
    } catch {
      onToast("Microphone permission denied.");
      stopLiveTranslate();
    }
  };

  const runWorldSearch = async (
    mode: "encyclopedia" | "research" = "encyclopedia",
    overrideQuery?: string
  ) => {
    const q = (overrideQuery ?? query).trim();
    if (!q) {
      onToast("Enter any question, country, science topic, news, or URL to search.");
      return;
    }
    if (!navigator.onLine) {
      onToast("World Knowledge Explorer needs WiFi or mobile internet.");
      return;
    }

    setBusyMode(mode);
    try {
      const nowD = new Date();
      const res = await fetch("/api/world-tools", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tool: mode,
          query: q,
          language,
          clientTime: {
            iso: nowD.toISOString(),
            timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone || "Asia/Karachi",
            localFormatted: nowD.toLocaleString("en-US", { hour12: true }),
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "World search failed");
      setEncResult(data as EncyclopediaResult);
      if (data.noorSummary) onSpeakResult(data.noorSummary);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Could not search world information.");
    } finally {
      setBusyMode("none");
    }
  };

  const runTranslate = async (e?: React.FormEvent) => {
    e?.preventDefault();
    const txt = transText.trim();
    if (!txt) {
      onToast("Enter any sentence in any language to translate.");
      return;
    }
    if (!navigator.onLine) {
      onToast("Universal Translator needs an active internet connection.");
      return;
    }

    setTransBusy(true);
    try {
      const res = await fetch("/api/world-tools", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tool: "translate",
          query: txt,
          targetLanguage: targetLang,
          language,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Translation failed");
      setTransResult(data as TranslateResult);
      if (data.spokenSummary) onSpeakResult(data.spokenSummary);
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Translation failed.");
    } finally {
      setTransBusy(false);
    }
  };

  const busy = busyMode !== "none";

  return (
    <div className="flex flex-col h-full bg-[#15121e]">
      {/* Sub-navigation */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10">
        <button
          type="button"
          onClick={() => setTab("encyclopedia")}
          className={`flex-1 min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 border transition-colors cursor-pointer ${
            tab === "encyclopedia"
              ? "bg-[#5eead4]/15 border-[#5eead4]/50 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Globe className="w-3.5 h-3.5 text-[#5eead4]" />
          <span>World &amp; Deep Research</span>
        </button>

        <button
          type="button"
          onClick={() => setTab("translate")}
          className={`flex-1 min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 border transition-colors cursor-pointer ${
            tab === "translate"
              ? "bg-[#e8b86d]/15 border-[#e8b86d]/50 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Languages className="w-3.5 h-3.5 text-[#e8b86d]" />
          <span>Live Translator</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto noor-scroll p-4 space-y-4">
        {tab === "encyclopedia" && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-[#faf6f0]">
                World Knowledge &amp; Verified Deep Research
              </h2>
              <p className="text-xs text-white/60 leading-relaxed">
                Quick-explore live facts or run multi-source Deep Research on medical science,
                news, countries, or any website link worldwide.
              </p>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                runWorldSearch("encyclopedia");
              }}
              className="space-y-2"
            >
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Ask anything in the world or paste a URL…"
                className="w-full min-h-[44px] px-3.5 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#5eead4]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40"
              />
              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={busy || !query.trim()}
                  className="flex-1 min-h-[42px] px-3.5 rounded-xl bg-[#5eead4] hover:bg-[#49d9c2] disabled:opacity-45 text-[#0e0c14] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {busyMode === "encyclopedia" ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Search className="w-4 h-4" />
                  )}
                  <span>Quick Search</span>
                </button>

                <button
                  type="button"
                  disabled={busy || !query.trim()}
                  onClick={() => runWorldSearch("research")}
                  className="flex-1 min-h-[42px] px-3.5 rounded-xl bg-[#e8b86d]/20 hover:bg-[#e8b86d]/30 border border-[#e8b86d]/55 disabled:opacity-45 text-[#faf6f0] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  {busyMode === "research" ? (
                    <Loader2 className="w-4 h-4 animate-spin text-[#e8b86d]" />
                  ) : (
                    <BookOpenCheck className="w-4 h-4 text-[#e8b86d]" />
                  )}
                  <span>Deep Research</span>
                </button>
              </div>
            </form>

            <div className="flex flex-wrap gap-1.5">
              {WORLD_TOPICS.map((t) => (
                <button
                  key={t.label}
                  type="button"
                  disabled={busy}
                  onClick={() => {
                    setQuery(t.prompt);
                    runWorldSearch("encyclopedia", t.prompt);
                  }}
                  className="px-2.5 py-1.5 rounded-lg bg-[#1c1826] hover:bg-[#272136] border border-white/10 text-xs text-white/85 flex items-center gap-1 cursor-pointer"
                >
                  <Sparkles className="w-3 h-3 text-[#e8b86d]" />
                  <span>{t.label}</span>
                </button>
              ))}
            </div>

            {encResult && (
              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider font-semibold text-[#5eead4]">
                      {encResult.category}
                    </span>
                    <h3 className="text-sm font-semibold text-[#faf6f0]">{encResult.title}</h3>
                  </div>
                  <div className="flex gap-1.5">
                    <button
                      type="button"
                      onClick={() => onSpeakResult(encResult.noorSummary)}
                      className="min-h-[34px] px-3 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                    >
                      <Volume2 className="w-3.5 h-3.5 text-[#e8b86d]" />
                      <span>Hear</span>
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onAddToChat(
                          `${encResult.title}: ${encResult.noorSummary.replace(/\[(\w+)\]/g, "").trim()}`
                        )
                      }
                      className="min-h-[34px] px-3 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquarePlus className="w-3.5 h-3.5 text-[#5eead4]" />
                      <span>Save</span>
                    </button>
                  </div>
                </div>

                <p
                  className={`text-sm leading-relaxed text-[#faf6f0]/90 ${
                    URDU_RE.test(encResult.noorSummary) ? "font-urdu text-base" : ""
                  }`}
                >
                  {encResult.noorSummary.replace(/\[(\w+)\]/g, "").trim()}
                </p>

                {encResult.keyFacts?.length > 0 && (
                  <div className="space-y-1">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#e8b86d]">
                      Verified Key Facts
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {encResult.keyFacts.map((f, idx) => (
                        <li key={idx}>{f}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {encResult.practicalTips?.length > 0 && (
                  <div className="space-y-1">
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-[#5eead4]">
                      Helpful Takeaways
                    </h4>
                    <ul className="space-y-1 text-xs text-white/80 list-disc pl-4">
                      {encResult.practicalTips.map((t, idx) => (
                        <li key={idx}>{t}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {encResult.sources && encResult.sources.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {encResult.sources.slice(0, 5).map((s) => (
                      <a
                        key={s.uri}
                        href={s.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1 text-[11px] text-[#5eead4] hover:underline"
                      >
                        <ExternalLink className="w-3 h-3 shrink-0" />
                        <span className="truncate max-w-[180px]">{s.title}</span>
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {tab === "translate" && (
          <div className="space-y-4">
            <div className="space-y-1">
              <h2 className="text-base font-semibold text-[#faf6f0]">
                Universal Voice &amp; Text Translator
              </h2>
              <p className="text-xs text-white/60 leading-relaxed">
                Stream live speech translation with your microphone OR type to translate between
                Urdu, Roman Urdu, Punjabi, English, Arabic, Hindi, Turkish &amp; more.
              </p>
            </div>

            {/* Real-Time Streaming Voice Translator */}
            <div className="rounded-2xl bg-[#1c1826] border border-[#5eead4]/25 p-3.5 space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-[#faf6f0]">
                    Real-Time Live Speech Translator
                  </div>
                  <div className="text-[11px] text-white/55">
                    Speak directly into mic for instant live translation
                  </div>
                </div>
                <button
                  type="button"
                  onClick={toggleLiveVoiceTranslate}
                  className={`min-h-[38px] px-3 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0 ${
                    liveTransActive
                      ? "bg-[#e6483d] text-white"
                      : "bg-[#5eead4] hover:bg-[#49d9c2] text-[#0e0c14]"
                  }`}
                >
                  {liveTransActive ? (
                    <>
                      <Square className="w-3.5 h-3.5 fill-current" />
                      <span>Stop Mic</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-3.5 h-3.5" />
                      <span>Speak Live</span>
                    </>
                  )}
                </button>
              </div>

              {(liveTransActive || liveSourceStream || liveTranslatedStream) && (
                <div className="space-y-2 pt-1 border-t border-white/10">
                  {liveSourceStream && (
                    <p className="text-xs text-white/65">Heard: “{liveSourceStream}”</p>
                  )}
                  <div className="flex items-start justify-between gap-2">
                    <p
                      className={`text-sm font-medium text-[#5eead4] leading-relaxed ${
                        URDU_RE.test(liveTranslatedStream) ? "font-urdu text-base" : ""
                      }`}
                    >
                      {liveTranslatedStream ||
                        (liveTransActive ? "Listening — speak clearly…" : "")}
                    </p>
                    {liveTranslatedStream && (
                      <button
                        type="button"
                        onClick={() => onSpeakResult(liveTranslatedStream)}
                        className="min-h-[30px] px-2.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-[11px] text-[#faf6f0] flex items-center gap-1 cursor-pointer shrink-0"
                      >
                        <Volume2 className="w-3 h-3 text-[#e8b86d]" />
                        <span>Speak</span>
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>

            <form onSubmit={runTranslate} className="space-y-3">
              <textarea
                rows={3}
                value={transText}
                onChange={(e) => setTransText(e.target.value)}
                placeholder="Type anything in Urdu, English, Punjabi, Arabic, etc.…"
                className="w-full p-3 rounded-xl bg-[#1c1826] border border-white/10 focus:border-[#e8b86d]/50 outline-none text-sm text-[#faf6f0] placeholder:text-white/40 resize-none"
              />

              <div className="flex items-center gap-2">
                <label htmlFor="target-lang" className="text-xs text-white/65 shrink-0">
                  Translate to:
                </label>
                <select
                  id="target-lang"
                  value={targetLang}
                  onChange={(e) => setTargetLang(e.target.value)}
                  className="flex-1 min-h-[40px] px-3 rounded-xl bg-[#1c1826] border border-white/10 text-xs text-[#faf6f0] outline-none"
                >
                  {TARGET_LANGUAGES.map((l) => (
                    <option key={l.label} value={l.label}>
                      {l.label}
                    </option>
                  ))}
                </select>
                <button
                  type="submit"
                  disabled={transBusy || !transText.trim()}
                  className="min-h-[40px] px-4 rounded-xl bg-[#e8b86d] hover:bg-[#d9a75a] disabled:opacity-45 text-[#0e0c14] text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
                >
                  {transBusy ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <ArrowRightLeft className="w-4 h-4" />
                  )}
                  <span>Translate</span>
                </button>
              </div>
            </form>

            {transResult && (
              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-3">
                <div className="flex items-center justify-between gap-2 pb-2 border-b border-white/10">
                  <span className="text-[11px] font-semibold uppercase tracking-wider text-[#e8b86d]">
                    Detected: {transResult.detectedLanguage} → {targetLang}
                  </span>
                  <button
                    type="button"
                    onClick={() => onSpeakResult(transResult.spokenSummary || transResult.translatedText)}
                    className="min-h-[32px] px-2.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-[#faf6f0] flex items-center gap-1 cursor-pointer"
                  >
                    <Volume2 className="w-3.5 h-3.5 text-[#5eead4]" />
                    <span>Speak</span>
                  </button>
                </div>

                <p
                  className={`text-base font-medium leading-relaxed text-[#faf6f0] ${
                    URDU_RE.test(transResult.translatedText) ? "font-urdu text-lg" : ""
                  }`}
                >
                  {transResult.translatedText}
                </p>

                {transResult.pronunciation && (
                  <div className="rounded-xl bg-[#120f1a] border border-white/10 px-3 py-2 text-xs text-white/75">
                    <span className="text-[#5eead4] font-semibold">Pronunciation: </span>
                    {transResult.pronunciation}
                  </div>
                )}

                {transResult.tips?.length > 0 && (
                  <ul className="space-y-1 text-xs text-white/70 list-disc pl-4">
                    {transResult.tips.map((tip, i) => (
                      <li key={i}>{tip}</li>
                    ))}
                  </ul>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
