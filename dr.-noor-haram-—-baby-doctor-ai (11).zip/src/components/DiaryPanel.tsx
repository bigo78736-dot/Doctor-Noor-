import { useEffect, useState } from "react";
import {
  Activity,
  Bell,
  BellRing,
  Calendar,
  CalendarCheck,
  CalendarPlus,
  ExternalLink,
  FileDown,
  Heart,
  Loader2,
  MessageSquarePlus,
  Plus,
  Printer,
  RefreshCw,
  Stethoscope,
  Trash2,
  Volume2,
  X,
} from "lucide-react";
import { setCachedCalendarAccessToken } from "../lib/firebase";
import {
  createMedicineCalendarEvent,
  deleteMedicineCalendarEvent,
  listMedicineCalendarEvents,
  updateMedicineCalendarEvent,
} from "../lib/googleCalendar";
import type {
  CalendarAlarmEvent,
  DiaryEntry,
  MedReminder,
  MedicalReportRecord,
  VitalRecord,
} from "../types/noor";

interface DiaryPanelProps {
  reminders: MedReminder[];
  entries: DiaryEntry[];
  vitals?: VitalRecord[];
  reports?: MedicalReportRecord[];
  noorName?: string;
  calendarToken?: string | null;
  onConnectGoogleCalendar?: () => Promise<void>;
  onUpdateReminders: (next: MedReminder[]) => void;
  onUpdateEntries: (next: DiaryEntry[]) => void;
  onUpdateVitals?: (next: VitalRecord[]) => void;
  onSpeakText: (taggedText: string) => void;
  onShareToChat: (text: string) => void;
  onToast: (msg: string) => void;
}

type PendingCalendarConfirm =
  | { kind: "update_reminder"; reminder: MedReminder; eventId: string }
  | { kind: "delete_reminder"; reminder: MedReminder; eventId: string }
  | { kind: "delete_event"; event: CalendarAlarmEvent }
  | null;

function escapeHtml(raw: string): string {
  return String(raw || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function DiaryPanel({
  reminders,
  entries,
  vitals = [],
  reports = [],
  noorName = "Noor Haram",
  calendarToken = null,
  onConnectGoogleCalendar,
  onUpdateReminders,
  onUpdateEntries,
  onUpdateVitals,
  onSpeakText,
  onShareToChat,
  onToast,
}: DiaryPanelProps) {
  const [subTab, setSubTab] = useState<"reminders" | "diary" | "vitals">("reminders");

  // Google Calendar Alarms state
  const [calendarEvents, setCalendarEvents] = useState<CalendarAlarmEvent[]>([]);
  const [calendarLoading, setCalendarLoading] = useState(false);
  const [calendarBusyId, setCalendarBusyId] = useState<string | null>(null);
  const [confirmAction, setConfirmAction] = useState<PendingCalendarConfirm>(null);

  // Reminder form
  const [remTitle, setRemTitle] = useState("");
  const [remTime, setRemTime] = useState("09:00");
  const [remNote, setRemNote] = useState("");

  // Diary form
  const [entryKind, setEntryKind] = useState<"health" | "memory">("health");
  const [entryTitle, setEntryTitle] = useState("");
  const [entryNotes, setEntryNotes] = useState("");

  // Vitals form
  const [tempF, setTempF] = useState("");
  const [bpSys, setBpSys] = useState("");
  const [bpDia, setBpDia] = useState("");
  const [sugarMgDl, setSugarMgDl] = useState("");
  const [spo2, setSpo2] = useState("");
  const [heartRate, setHeartRate] = useState("");
  const [vitalNote, setVitalNote] = useState("");

  const refreshCalendarEvents = async (tokenOverride?: string | null) => {
    const token = tokenOverride ?? calendarToken;
    if (!token) return;
    setCalendarLoading(true);
    try {
      const list = await listMedicineCalendarEvents(token);
      setCalendarEvents(list);
      // Link any matching reminders back by noorReminderId
      const byRemId = new Map<string, CalendarAlarmEvent>();
      for (const ev of list) {
        if (ev.noorReminderId) byRemId.set(ev.noorReminderId, ev);
      }
      if (byRemId.size > 0) {
        let changed = false;
        const synced = reminders.map((r) => {
          const match = byRemId.get(r.id);
          if (match && r.calendarEventId !== match.id) {
            changed = true;
            return { ...r, calendarEventId: match.id, calendarLink: match.htmlLink };
          }
          return r;
        });
        if (changed) onUpdateReminders(synced);
      }
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Could not load Google Calendar events.";
      if (/session expired|access not granted/i.test(msg)) {
        setCachedCalendarAccessToken(null);
      }
      onToast(msg);
    } finally {
      setCalendarLoading(false);
    }
  };

  useEffect(() => {
    if (calendarToken && subTab === "reminders") {
      void refreshCalendarEvents(calendarToken);
    } else if (!calendarToken) {
      setCalendarEvents([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [calendarToken, subTab]);

  const handleCreateCalendarAlarm = async (rem: MedReminder) => {
    if (!calendarToken) {
      onToast("Please sign in with Google Calendar first.");
      return;
    }
    setCalendarBusyId(rem.id);
    try {
      const created = await createMedicineCalendarEvent(calendarToken, rem, noorName);
      onUpdateReminders(
        reminders.map((x) =>
          x.id === rem.id
            ? { ...x, calendarEventId: created.eventId, calendarLink: created.htmlLink }
            : x
        )
      );
      onToast(`Added daily alarm for "${rem.title}" (${rem.time}) to Google Calendar!`);
      await refreshCalendarEvents(calendarToken);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to create Calendar alarm.";
      if (/session expired|access not granted/i.test(msg)) {
        setCachedCalendarAccessToken(null);
      }
      onToast(msg);
    } finally {
      setCalendarBusyId(null);
    }
  };

  const executeConfirmedCalendarAction = async () => {
    if (!confirmAction) return;
    const action = confirmAction;
    setConfirmAction(null);

    if (!calendarToken) {
      onToast("Google Calendar session expired — please sign in again.");
      return;
    }

    if (action.kind === "update_reminder") {
      setCalendarBusyId(action.reminder.id);
      try {
        const updated = await updateMedicineCalendarEvent(
          calendarToken,
          action.eventId,
          action.reminder,
          noorName
        );
        onUpdateReminders(
          reminders.map((x) =>
            x.id === action.reminder.id
              ? { ...x, calendarEventId: updated.eventId, calendarLink: updated.htmlLink }
              : x
          )
        );
        onToast(`Updated Google Calendar alarm for "${action.reminder.title}"!`);
        await refreshCalendarEvents(calendarToken);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed to update Calendar event.";
        if (/session expired|access not granted/i.test(msg)) {
          setCachedCalendarAccessToken(null);
        }
        onToast(msg);
      } finally {
        setCalendarBusyId(null);
      }
      return;
    }

    if (action.kind === "delete_reminder") {
      setCalendarBusyId(action.reminder.id);
      try {
        await deleteMedicineCalendarEvent(calendarToken, action.eventId);
        onUpdateReminders(reminders.filter((x) => x.id !== action.reminder.id));
        onToast(`Deleted "${action.reminder.title}" and removed its Google Calendar alarm.`);
        await refreshCalendarEvents(calendarToken);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed to delete Calendar event.";
        if (/session expired|access not granted/i.test(msg)) {
          setCachedCalendarAccessToken(null);
        }
        onToast(msg);
      } finally {
        setCalendarBusyId(null);
      }
      return;
    }

    if (action.kind === "delete_event") {
      setCalendarBusyId(action.event.id);
      try {
        await deleteMedicineCalendarEvent(calendarToken, action.event.id);
        onUpdateReminders(
          reminders.map((r) =>
            r.calendarEventId === action.event.id
              ? { ...r, calendarEventId: undefined, calendarLink: undefined }
              : r
          )
        );
        setCalendarEvents((prev) => prev.filter((e) => e.id !== action.event.id));
        onToast(`Removed "${action.event.summary}" from Google Calendar.`);
      } catch (err) {
        const msg = err instanceof Error ? err.message : "Failed to remove Calendar event.";
        if (/session expired|access not granted/i.test(msg)) {
          setCachedCalendarAccessToken(null);
        }
        onToast(msg);
      } finally {
        setCalendarBusyId(null);
      }
    }
  };

  const addReminder = (e: React.FormEvent) => {
    e.preventDefault();
    const title = remTitle.trim();
    if (!title) {
      onToast("Please enter a medicine, checkup, or dua name.");
      return;
    }
    const item: MedReminder = {
      id: `rem-${Date.now()}`,
      title,
      time: remTime || "09:00",
      note: remNote.trim(),
      enabled: true,
    };
    onUpdateReminders([item, ...reminders]);
    setRemTitle("");
    setRemNote("");
    onToast(`Reminder saved for ${item.time}.`);
  };

  const addEntry = (e: React.FormEvent) => {
    e.preventDefault();
    const title = entryTitle.trim();
    const notes = entryNotes.trim();
    if (!title && !notes) {
      onToast("Please write a note or memory.");
      return;
    }
    const item: DiaryEntry = {
      id: `entry-${Date.now()}`,
      kind: entryKind,
      title: title || (entryKind === "health" ? "Health Check Log" : "Family Memory"),
      notes,
      createdAt: Date.now(),
    };
    onUpdateEntries([item, ...entries]);
    setEntryTitle("");
    setEntryNotes("");
    onToast("Saved to your Family Diary.");
  };

  const addVital = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedTemp = tempF.trim() ? Number(tempF) : undefined;
    const parsedSys = bpSys.trim() ? Number(bpSys) : undefined;
    const parsedDia = bpDia.trim() ? Number(bpDia) : undefined;
    const parsedSugar = sugarMgDl.trim() ? Number(sugarMgDl) : undefined;
    const parsedSpo2 = spo2.trim() ? Number(spo2) : undefined;
    const parsedHr = heartRate.trim() ? Number(heartRate) : undefined;

    if (
      parsedTemp === undefined &&
      parsedSys === undefined &&
      parsedSugar === undefined &&
      parsedSpo2 === undefined &&
      parsedHr === undefined
    ) {
      onToast("Enter at least one measurement (Fever, BP, Sugar, SpO2, or Pulse).");
      return;
    }

    const record: VitalRecord = {
      id: `vit-${Date.now()}`,
      tempF: parsedTemp !== undefined && parsedTemp >= 85 && parsedTemp <= 115 ? parsedTemp : undefined,
      bpSys: parsedSys !== undefined && parsedSys >= 40 && parsedSys <= 300 ? parsedSys : undefined,
      bpDia: parsedDia !== undefined && parsedDia >= 20 && parsedDia <= 200 ? parsedDia : undefined,
      sugarMgDl:
        parsedSugar !== undefined && parsedSugar >= 20 && parsedSugar <= 900 ? parsedSugar : undefined,
      spo2: parsedSpo2 !== undefined && parsedSpo2 >= 40 && parsedSpo2 <= 100 ? parsedSpo2 : undefined,
      heartRate: parsedHr !== undefined && parsedHr >= 25 && parsedHr <= 260 ? parsedHr : undefined,
      note: vitalNote.trim().slice(0, 400) || undefined,
      createdAt: Date.now(),
    };

    onUpdateVitals?.([record, ...vitals]);
    setTempF("");
    setBpSys("");
    setBpDia("");
    setSugarMgDl("");
    setSpo2("");
    setHeartRate("");
    setVitalNote("");
    onToast("Vitals logged & synced!");
    if (record.tempF && record.tempF >= 100.4) {
      onSpeakText(
        `[stethoscope] Bukhar ${record.tempF} degree record ho gaya hai. Paani khoob piyen aur aaraam karein.`
      );
    } else if (record.spo2 && record.spo2 < 94) {
      onSpeakText(
        `[stethoscope] Oxygen level ${record.spo2} percent thora kam hai — gehri saans lein aur zaroorat ho to doctor se check karwayein.`
      );
    }
  };

  const downloadClinicalHtmlReport = () => {
    const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>Doctor Visit Summary — Dr. ${escapeHtml(noorName)}</title>
<style>
  body { font-family: system-ui, -apple-system, sans-serif; color: #111827; max-width: 820px; margin: 24px auto; padding: 0 18px; line-height: 1.5; }
  h1 { font-size: 20px; margin-bottom: 4px; color: #991b1b; }
  h2 { font-size: 15px; border-bottom: 1px solid #d1d5db; padding-bottom: 4px; margin-top: 22px; }
  .meta { font-size: 12px; color: #4b5563; margin-bottom: 16px; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; margin-top: 8px; }
  th, td { border: 1px solid #d1d5db; padding: 6px 8px; text-align: left; }
  th { background: #f3f4f6; }
  .card { border: 1px solid #e5e7eb; border-radius: 8px; padding: 10px 12px; margin: 8px 0; }
</style>
</head>
<body>
  <h1>Family Health &amp; Vitals Report</h1>
  <div class="meta">Generated on ${escapeHtml(new Date().toLocaleString())} · Prepared with Dr. ${escapeHtml(noorName)} AI</div>

  <h2>Recent Vitals (${vitals.length})</h2>
  ${
    vitals.length === 0
      ? "<p>No vitals logged.</p>"
      : `<table><thead><tr><th>Date/Time</th><th>Temp (°F)</th><th>BP (mmHg)</th><th>Sugar (mg/dL)</th><th>SpO2 (%)</th><th>Pulse</th><th>Notes</th></tr></thead><tbody>${vitals
          .slice(0, 30)
          .map(
            (v) =>
              `<tr><td>${escapeHtml(new Date(v.createdAt).toLocaleString())}</td><td>${v.tempF ?? "—"}</td><td>${
                v.bpSys ? `${v.bpSys}/${v.bpDia ?? ""}` : "—"
              }</td><td>${v.sugarMgDl ?? "—"}</td><td>${v.spo2 ?? "—"}</td><td>${
                v.heartRate ?? "—"
              }</td><td>${escapeHtml(v.note || "")}</td></tr>`
          )
          .join("")}</tbody></table>`
  }

  <h2>Active Medicine Reminders (${reminders.length})</h2>
  ${
    reminders.length === 0
      ? "<p>None recorded.</p>"
      : `<ul>${reminders
          .map(
            (r) =>
              `<li><b>${escapeHtml(r.time)}</b> — ${escapeHtml(r.title)} ${
                r.note ? `(${escapeHtml(r.note)})` : ""
              } [${r.enabled ? "Active" : "Paused"}]</li>`
          )
          .join("")}</ul>`
  }

  <h2>Health Diary Logs (${entries.filter((e) => e.kind === "health").length})</h2>
  ${
    entries
      .filter((e) => e.kind === "health")
      .slice(0, 20)
      .map(
        (e) =>
          `<div class="card"><b>${escapeHtml(e.title)}</b> <small>(${escapeHtml(
            new Date(e.createdAt).toLocaleString()
          )})</small><p>${escapeHtml(e.notes)}</p></div>`
      )
      .join("") || "<p>No health diary entries.</p>"
  }

  <h2>Scanned Lab Reports &amp; Prescriptions (${reports.length})</h2>
  ${
    reports
      .slice(0, 15)
      .map(
        (rep) =>
          `<div class="card"><b>${escapeHtml(rep.title)}</b> [${escapeHtml(rep.urgency)}] <small>${escapeHtml(
            new Date(rep.createdAt).toLocaleString()
          )}</small><p>${escapeHtml(rep.noorReply.replace(/\[(\w+)\]/g, ""))}</p></div>`
      )
      .join("") || "<p>No scanned reports.</p>"
  }
</body>
</html>`;
    const blob = new Blob([html], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `Doctor-Visit-Summary-${new Date().toISOString().slice(0, 10)}.html`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    onToast("Doctor Visit Summary downloaded — open or print to share with your doctor!");
  };

  const [notifPerm, setNotifPerm] = useState<string>(
    typeof Notification !== "undefined" ? Notification.permission : "unsupported"
  );

  const requestNotifications = async () => {
    if (typeof Notification === "undefined") {
      onToast("Browser notifications are not supported on this device.");
      return;
    }
    try {
      const res = await Notification.requestPermission();
      setNotifPerm(res);
      if (res === "granted") {
        onToast("Daily medicine & dua alerts enabled!");
      } else {
        onToast("Notification permission was not granted.");
      }
    } catch {
      onToast("Could not request notification permission.");
    }
  };

  // Compute SVG sparkline points for Fever (°F)
  const tempSeries = [...vitals]
    .filter((v) => typeof v.tempF === "number")
    .slice(0, 12)
    .reverse();

  const tempSparkPoints = (() => {
    if (tempSeries.length < 2) return "";
    const min = 96;
    const max = 105;
    return tempSeries
      .map((v, idx) => {
        const x = (idx / (tempSeries.length - 1)) * 220 + 10;
        const clamped = Math.max(min, Math.min(max, v.tempF || 98.6));
        const y = 46 - ((clamped - min) / (max - min)) * 38;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ");
  })();

  return (
    <div className="flex flex-col h-full bg-[#15121e]">
      <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/10 overflow-x-auto noor-scroll">
        <button
          type="button"
          onClick={() => setSubTab("reminders")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "reminders"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Bell className="w-3.5 h-3.5 text-[#e8b86d]" />
          <span>Reminders</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab("vitals")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "vitals"
              ? "bg-[#5eead4]/15 border-[#5eead4]/55 text-[#5eead4]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Activity className="w-3.5 h-3.5 text-[#5eead4]" />
          <span>Vitals &amp; Report</span>
        </button>

        <button
          type="button"
          onClick={() => setSubTab("diary")}
          className={`min-h-[38px] px-3 rounded-lg text-xs font-semibold flex items-center gap-1.5 border transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
            subTab === "diary"
              ? "bg-[#e6483d]/15 border-[#e6483d]/45 text-[#faf6f0]"
              : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
          }`}
        >
          <Heart className="w-3.5 h-3.5 text-[#e6483d]" />
          <span>Diary</span>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto noor-scroll p-4 space-y-5">
        {subTab === "reminders" ? (
          <>
            <form
              onSubmit={addReminder}
              className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-3"
            >
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-semibold text-[#faf6f0]">
                  Daily Medicine, Water, or Dua Reminder
                </h2>
                {notifPerm !== "unsupported" && (
                  <button
                    type="button"
                    onClick={requestNotifications}
                    className={`min-h-[30px] px-2.5 rounded-lg border text-[11px] font-semibold flex items-center gap-1 cursor-pointer shrink-0 ${
                      notifPerm === "granted"
                        ? "bg-[#5eead4]/15 border-[#5eead4]/45 text-[#5eead4]"
                        : "bg-white/[0.05] border-white/15 text-[#e8b86d]"
                    }`}
                  >
                    <BellRing className="w-3 h-3" />
                    <span>{notifPerm === "granted" ? "Alerts On" : "Enable Alerts"}</span>
                  </button>
                )}
              </div>
              <p className="text-xs text-white/55">
                While this app is open, Dr. Noor gently speaks your reminder aloud and sends a
                notification when the clock reaches the set time.
              </p>

              <div className="grid grid-cols-[1fr_auto] gap-2">
                <input
                  type="text"
                  value={remTitle}
                  onChange={(e) => setRemTitle(e.target.value)}
                  placeholder="e.g., Ammi Blood Pressure Dawai / Subah Dua"
                  className="min-h-[42px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-sm text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
                <input
                  type="time"
                  value={remTime}
                  onChange={(e) => setRemTime(e.target.value)}
                  className="min-h-[42px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-sm font-mono-tabular text-[#faf6f0] outline-none"
                />
              </div>

              <input
                type="text"
                value={remNote}
                onChange={(e) => setRemNote(e.target.value)}
                placeholder="Optional note (e.g., After breakfast with water)"
                className="w-full min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs text-[#faf6f0] placeholder:text-white/40 outline-none"
              />

              <button
                type="submit"
                className="w-full min-h-[42px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Reminder</span>
              </button>
            </form>

            <div className="space-y-2.5">
              {reminders.length === 0 ? (
                <p className="text-xs text-white/50 text-center py-4">
                  No reminders saved yet.
                </p>
              ) : (
                reminders.map((r) => (
                  <div
                    key={r.id}
                    className="rounded-2xl bg-[#1c1826]/80 border border-white/10 p-3.5 space-y-2.5"
                  >
                    <div className="flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-mono-tabular text-xs font-bold text-[#e8b86d]">
                            {r.time}
                          </span>
                          <span className="text-sm font-semibold text-[#faf6f0] truncate">
                            {r.title}
                          </span>
                        </div>
                        {r.note && (
                          <p className="text-xs text-white/60 mt-0.5 truncate">{r.note}</p>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 shrink-0">
                        <button
                          type="button"
                          onClick={() =>
                            onSpeakText(
                              `[stethoscope] Yaad-dihani! ${r.title} ka waqt ho gaya hai. ${r.note}`
                            )
                          }
                          title="Hear reminder aloud"
                          className="min-h-[34px] min-w-[34px] rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-[#e8b86d] flex items-center justify-center cursor-pointer"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            onUpdateReminders(
                              reminders.map((x) =>
                                x.id === r.id ? { ...x, enabled: !x.enabled } : x
                              )
                            )
                          }
                          className={`min-h-[34px] px-2.5 rounded-lg text-[11px] font-semibold border cursor-pointer ${
                            r.enabled
                              ? "bg-[#5eead4]/15 border-[#5eead4]/45 text-[#5eead4]"
                              : "bg-white/[0.04] border-white/10 text-white/50"
                          }`}
                        >
                          {r.enabled ? "On" : "Off"}
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            if (r.calendarEventId && calendarToken) {
                              setConfirmAction({
                                kind: "delete_reminder",
                                reminder: r,
                                eventId: r.calendarEventId,
                              });
                            } else {
                              onUpdateReminders(reminders.filter((x) => x.id !== r.id));
                            }
                          }}
                          aria-label="Delete reminder"
                          className="min-h-[34px] min-w-[34px] rounded-lg hover:bg-white/[0.08] text-white/55 hover:text-[#e6483d] flex items-center justify-center cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Google Calendar Alarm Actions per reminder */}
                    <div className="flex items-center justify-between gap-2 pt-2 border-t border-white/10">
                      {r.calendarEventId ? (
                        <>
                          <span className="text-[11px] text-[#5eead4] flex items-center gap-1">
                            <CalendarCheck className="w-3.5 h-3.5" />
                            <span>Synced to Google Calendar</span>
                          </span>
                          <div className="flex items-center gap-1.5">
                            {calendarToken && (
                              <button
                                type="button"
                                disabled={calendarBusyId === r.id}
                                onClick={() =>
                                  setConfirmAction({
                                    kind: "update_reminder",
                                    reminder: r,
                                    eventId: r.calendarEventId!,
                                  })
                                }
                                className="min-h-[28px] px-2.5 rounded-lg bg-[#5eead4]/15 hover:bg-[#5eead4]/25 border border-[#5eead4]/35 text-[11px] font-semibold text-[#5eead4] flex items-center gap-1 cursor-pointer disabled:opacity-50"
                              >
                                {calendarBusyId === r.id ? (
                                  <Loader2 className="w-3 h-3 animate-spin" />
                                ) : (
                                  <RefreshCw className="w-3 h-3" />
                                )}
                                <span>Update Cal</span>
                              </button>
                            )}
                            {r.calendarLink && (
                              <a
                                href={r.calendarLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="min-h-[28px] px-2 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-[11px] text-white/80 flex items-center gap-1"
                              >
                                <ExternalLink className="w-3 h-3" />
                                <span>Open</span>
                              </a>
                            )}
                          </div>
                        </>
                      ) : (
                        <>
                          <span className="text-[11px] text-white/45 flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            <span>Phone Calendar Alarm</span>
                          </span>
                          {calendarToken ? (
                            <button
                              type="button"
                              disabled={calendarBusyId === r.id}
                              onClick={() => handleCreateCalendarAlarm(r)}
                              className="min-h-[28px] px-2.5 rounded-lg bg-[#e8b86d]/15 hover:bg-[#e8b86d]/25 border border-[#e8b86d]/40 text-[11px] font-semibold text-[#e8b86d] flex items-center gap-1 cursor-pointer disabled:opacity-50"
                            >
                              {calendarBusyId === r.id ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                <CalendarPlus className="w-3 h-3" />
                              )}
                              <span>Add to Google Calendar</span>
                            </button>
                          ) : (
                            <span className="text-[10px] text-white/40">
                              Connect Google Calendar below
                            </span>
                          )}
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Real Google Calendar Medicine Alarms Section */}
            <div className="rounded-2xl bg-[#1c1826] border border-[#5eead4]/25 p-4 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2 min-w-0">
                  <Calendar className="w-4 h-4 text-[#5eead4] shrink-0" />
                  <h3 className="text-xs font-semibold text-[#faf6f0] truncate">
                    Real Google Calendar Medicine Alarms
                  </h3>
                </div>
                {calendarToken && (
                  <button
                    type="button"
                    disabled={calendarLoading}
                    onClick={() => refreshCalendarEvents()}
                    className="min-h-[30px] px-2.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-[11px] font-medium text-[#5eead4] flex items-center gap-1 cursor-pointer disabled:opacity-50 shrink-0"
                  >
                    <RefreshCw className={`w-3 h-3 ${calendarLoading ? "animate-spin" : ""}`} />
                    <span>Refresh</span>
                  </button>
                )}
              </div>

              {!calendarToken ? (
                <div className="space-y-3">
                  <p className="text-xs text-white/60 leading-relaxed">
                    Sign in with Google to sync daily recurring medicine reminder alarms straight to
                    your phone&apos;s Google Calendar, even when the browser is closed.
                  </p>
                  {onConnectGoogleCalendar && (
                    <button
                      type="button"
                      onClick={() => onConnectGoogleCalendar()}
                      className="w-full min-h-[42px] px-4 rounded-xl bg-white hover:bg-[#f8f9fa] text-[#1f1f1f] border border-[#dadce0] text-sm font-medium flex items-center justify-center gap-2.5 shadow-sm transition-colors cursor-pointer"
                    >
                      <svg className="w-4 h-4 shrink-0" viewBox="0 0 48 48" aria-hidden="true">
                        <path
                          fill="#EA4335"
                          d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
                        />
                        <path
                          fill="#4285F4"
                          d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
                        />
                        <path
                          fill="#FBBC05"
                          d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
                        />
                        <path
                          fill="#34A853"
                          d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
                        />
                      </svg>
                      <span>Sign in with Google</span>
                    </button>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  {calendarLoading && calendarEvents.length === 0 ? (
                    <div className="flex items-center gap-2 text-xs text-white/60 py-2">
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-[#5eead4]" />
                      <span>Loading your Google Calendar medicine alarms…</span>
                    </div>
                  ) : calendarEvents.length === 0 ? (
                    <p className="text-xs text-white/55">
                      Connected! Tap &quot;Add to Google Calendar&quot; on any reminder above to
                      schedule a daily alarm.
                    </p>
                  ) : (
                    <div className="space-y-1.5">
                      {calendarEvents.map((ev) => (
                        <div
                          key={ev.id}
                          className="rounded-xl bg-[#15121e] border border-white/10 px-3 py-2 flex items-center justify-between gap-2"
                        >
                          <div className="min-w-0">
                            <div className="text-xs font-semibold text-[#faf6f0] truncate">
                              {ev.summary}
                            </div>
                            <div className="text-[11px] font-mono-tabular text-[#5eead4]">
                              {ev.timeLabel} · Daily Alarm
                            </div>
                          </div>
                          <div className="flex items-center gap-1 shrink-0">
                            {ev.htmlLink && (
                              <a
                                href={ev.htmlLink}
                                target="_blank"
                                rel="noopener noreferrer"
                                aria-label="Open in Google Calendar"
                                className="min-h-[30px] min-w-[30px] rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-white/75 flex items-center justify-center"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            )}
                            <button
                              type="button"
                              disabled={calendarBusyId === ev.id}
                              onClick={() => setConfirmAction({ kind: "delete_event", event: ev })}
                              aria-label="Remove from Google Calendar"
                              className="min-h-[30px] min-w-[30px] rounded-lg hover:bg-white/[0.08] text-white/55 hover:text-[#e6483d] flex items-center justify-center cursor-pointer disabled:opacity-50"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </>
        ) : subTab === "vitals" ? (
          <>
            <form
              onSubmit={addVital}
              className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-3"
            >
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-semibold text-[#faf6f0]">
                  Log Family Vitals (Fever, BP, Sugar, SpO2)
                </h2>
                <span className="text-[11px] text-[#5eead4]">Trend Tracked</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <input
                  type="number"
                  step="0.1"
                  value={tempF}
                  onChange={(e) => setTempF(e.target.value)}
                  placeholder="Fever °F (98.6)"
                  aria-label="Temperature in Fahrenheit"
                  className="min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
                <input
                  type="number"
                  value={bpSys}
                  onChange={(e) => setBpSys(e.target.value)}
                  placeholder="BP Sys (120)"
                  aria-label="Systolic blood pressure"
                  className="min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
                <input
                  type="number"
                  value={bpDia}
                  onChange={(e) => setBpDia(e.target.value)}
                  placeholder="BP Dia (80)"
                  aria-label="Diastolic blood pressure"
                  className="min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
                <input
                  type="number"
                  value={sugarMgDl}
                  onChange={(e) => setSugarMgDl(e.target.value)}
                  placeholder="Sugar mg/dL"
                  aria-label="Blood sugar mg/dL"
                  className="min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
                <input
                  type="number"
                  value={spo2}
                  onChange={(e) => setSpo2(e.target.value)}
                  placeholder="SpO2 % (98)"
                  aria-label="Blood oxygen saturation percentage"
                  className="min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
                <input
                  type="number"
                  value={heartRate}
                  onChange={(e) => setHeartRate(e.target.value)}
                  placeholder="Pulse BPM (76)"
                  aria-label="Heart rate BPM"
                  className="min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] placeholder:text-white/40 outline-none"
                />
              </div>

              <input
                type="text"
                value={vitalNote}
                onChange={(e) => setVitalNote(e.target.value)}
                placeholder="Note (e.g., After Panadol, Fasting morning test)"
                className="w-full min-h-[38px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs text-[#faf6f0] placeholder:text-white/40 outline-none"
              />

              <button
                type="submit"
                className="w-full min-h-[40px] px-4 rounded-xl bg-[#5eead4] hover:bg-[#49d9c2] text-[#0e0c14] text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Log Vitals</span>
              </button>
            </form>

            {/* Fever Trend Sparkline + Doctor Report Export */}
            <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-3.5 space-y-3">
              {tempSparkPoints && (
                <div className="space-y-1">
                  <div className="flex items-center justify-between text-[11px] text-white/65">
                    <span>Fever Trend (°F)</span>
                    <span className="font-mono-tabular text-[#e6483d]">
                      Latest: {tempSeries[tempSeries.length - 1]?.tempF}°F
                    </span>
                  </div>
                  <svg viewBox="0 0 240 52" className="w-full h-14 rounded-lg bg-[#120f1a] border border-white/10">
                    <line x1="8" y1="24" x2="232" y2="24" stroke="rgba(94,234,212,0.22)" strokeDasharray="3 3" />
                    <polyline
                      fill="none"
                      stroke="#e6483d"
                      strokeWidth="2.5"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      points={tempSparkPoints}
                    />
                  </svg>
                </div>
              )}

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={downloadClinicalHtmlReport}
                  className="min-h-[38px] px-3 rounded-xl bg-[#e6483d]/15 hover:bg-[#e6483d]/25 border border-[#e6483d]/45 text-xs font-semibold text-[#faf6f0] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <FileDown className="w-3.5 h-3.5 text-[#e6483d]" />
                  <span>Doctor Summary</span>
                </button>
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="min-h-[38px] px-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/15 text-xs font-semibold text-[#faf6f0] flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-[#5eead4]" />
                  <span>Print View</span>
                </button>
              </div>
            </div>

            <div className="space-y-2">
              {vitals.length === 0 ? (
                <p className="text-xs text-white/50 text-center py-4">
                  No vitals logged yet.
                </p>
              ) : (
                vitals.map((v) => (
                  <div
                    key={v.id}
                    className="rounded-2xl bg-[#1c1826]/80 border border-white/10 p-3 space-y-1.5"
                  >
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[11px] text-white/50">
                        {new Date(v.createdAt).toLocaleString()}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateVitals?.(vitals.filter((x) => x.id !== v.id))
                        }
                        aria-label="Delete vital record"
                        className="w-7 h-7 rounded-lg hover:bg-white/10 text-white/45 hover:text-[#e6483d] flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="flex flex-wrap gap-2 text-xs font-mono-tabular">
                      {v.tempF !== undefined && (
                        <span className="text-[#e6483d] font-semibold">Temp {v.tempF}°F</span>
                      )}
                      {v.bpSys !== undefined && (
                        <span className="text-[#e8b86d] font-semibold">
                          BP {v.bpSys}/{v.bpDia ?? "—"}
                        </span>
                      )}
                      {v.sugarMgDl !== undefined && (
                        <span className="text-[#faf6f0] font-semibold">Sugar {v.sugarMgDl}</span>
                      )}
                      {v.spo2 !== undefined && (
                        <span className="text-[#5eead4] font-semibold">SpO2 {v.spo2}%</span>
                      )}
                      {v.heartRate !== undefined && (
                        <span className="text-white/80">HR {v.heartRate} BPM</span>
                      )}
                    </div>
                    {v.note && <p className="text-[11px] text-white/65">{v.note}</p>}
                  </div>
                ))
              )}
            </div>
          </>
        ) : (
          <>
            <form
              onSubmit={addEntry}
              className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-3"
            >
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-sm font-semibold text-[#faf6f0]">
                  Save Health Log or Loving Memory
                </h2>
                <div className="flex gap-1.5">
                  <button
                    type="button"
                    onClick={() => setEntryKind("health")}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border cursor-pointer ${
                      entryKind === "health"
                        ? "bg-[#5eead4]/15 border-[#5eead4]/50 text-[#5eead4]"
                        : "bg-[#15121e] border-white/10 text-white/65"
                    }`}
                  >
                    Health
                  </button>
                  <button
                    type="button"
                    onClick={() => setEntryKind("memory")}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border cursor-pointer ${
                      entryKind === "memory"
                        ? "bg-[#e8b86d]/15 border-[#e8b86d]/50 text-[#e8b86d]"
                        : "bg-[#15121e] border-white/10 text-white/65"
                    }`}
                  >
                    Memory
                  </button>
                </div>
              </div>

              <input
                type="text"
                value={entryTitle}
                onChange={(e) => setEntryTitle(e.target.value)}
                placeholder={
                  entryKind === "health"
                    ? "e.g., Fever 100.2°F evening check"
                    : "e.g., Noor Haram's sweet smile & dua"
                }
                className="w-full min-h-[42px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-sm text-[#faf6f0] placeholder:text-white/40 outline-none"
              />

              <textarea
                rows={3}
                value={entryNotes}
                onChange={(e) => setEntryNotes(e.target.value)}
                placeholder="Write symptoms, temperature, medicines taken, or family memory…"
                className="w-full p-3 rounded-xl bg-[#15121e] border border-white/10 text-xs text-[#faf6f0] placeholder:text-white/40 outline-none resize-none"
              />

              <button
                type="submit"
                className="w-full min-h-[42px] px-4 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] text-white text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Save Entry</span>
              </button>
            </form>

            <div className="space-y-2.5">
              {entries.length === 0 ? (
                <p className="text-xs text-white/50 text-center py-6">
                  Your health &amp; family diary is empty.
                </p>
              ) : (
                entries.map((entry) => (
                  <div
                    key={entry.id}
                    className="rounded-2xl bg-[#1c1826]/80 border border-white/10 p-3.5 space-y-2"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        {entry.kind === "health" ? (
                          <Stethoscope className="w-4 h-4 text-[#5eead4] shrink-0" />
                        ) : (
                          <Heart className="w-4 h-4 text-[#e8b86d] shrink-0" />
                        )}
                        <div className="min-w-0">
                          <h3 className="text-sm font-semibold text-[#faf6f0] truncate">
                            {entry.title}
                          </h3>
                          <span className="text-[11px] text-white/45">
                            {new Date(entry.createdAt).toLocaleString()}
                          </span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() =>
                          onUpdateEntries(entries.filter((x) => x.id !== entry.id))
                        }
                        aria-label="Delete diary entry"
                        className="min-h-[32px] min-w-[32px] rounded-lg hover:bg-white/[0.08] text-white/50 hover:text-[#e6483d] flex items-center justify-center cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    {entry.notes && (
                      <p className="text-xs leading-relaxed text-white/80 whitespace-pre-wrap">
                        {entry.notes}
                      </p>
                    )}
                    <button
                      type="button"
                      onClick={() =>
                        onShareToChat(
                          `${entry.title}${entry.notes ? `: ${entry.notes}` : ""}`
                        )
                      }
                      className="min-h-[32px] px-3 rounded-lg bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-[11px] font-medium text-[#5eead4] inline-flex items-center gap-1.5 cursor-pointer"
                    >
                      <MessageSquarePlus className="w-3.5 h-3.5" />
                      <span>Ask Dr. Noor About This</span>
                    </button>
                  </div>
                ))
              )}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
