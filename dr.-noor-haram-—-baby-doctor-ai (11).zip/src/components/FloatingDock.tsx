import { useEffect, useRef, useState } from "react";
import {
  Camera,
  ChevronDown,
  ChevronUp,
  Mic,
  MicOff,
  PhoneCall,
  PhoneOff,
  Radio,
  Send,
  Square,
  Video,
  VideoOff,
} from "lucide-react";
import {
  encodePcm16kChunksToWavBase64,
  getSharedAudioCtxCtor,
  startMicPcmPipeline,
  type MicPipelineHandle,
} from "../lib/audioCapture";
import type { GestureName } from "../types/noor";

const URDU_RE = /[\u0600-\u06ff]/;
const WAKE_WORD_RE = /\b(noor|noore?|noor\s*haram|haram|dr\.?\s*noor|doctor|hey\s+noor|sunno|suno)\b|نور|ڈاکٹر\s*نور/i;

interface FloatingDockProps {
  noorName: string;
  caption: string;
  heardText: string;
  isBusy: boolean;
  isSpeaking: boolean;
  started: boolean;
  autoListen: boolean;
  liveCallStatus: "ended" | "connecting" | "connected";
  liveVideoOn: boolean;
  sttLang: string;
  onToggleAutoListen: () => void;
  onToggleLiveCall: () => void;
  onToggleLiveVideo: () => void;
  onSend: (text: string) => void;
  onInterruptSpeech?: () => void;
  onHeardPreview: (text: string) => void;
  onQuickAction: (say: string, gesture: GestureName) => void;
  onOpenVision: () => void;
  onEnsureStarted?: () => void;
  onUnlockAudio?: () => void;
  onListeningChange?: (listening: boolean) => void;
  onToast: (msg: string) => void;
}

const QUICK_ACTIONS: Array<{ label: string; say: string; gesture: GestureName }> = [
  { label: "Smile", say: "Ek pyari si smile do na!", gesture: "smile" },
  { label: "Salam", say: "Haath hila kar salam karo", gesture: "wave" },
  {
    label: "Near Hospital",
    say: "Mere qareeb sab se acha hospital, medical store, X-ray aur ultrasound center kaunsa hai? Online location check karke batayein.",
    gesture: "stethoscope",
  },
  {
    label: "Live Time",
    say: "Abhi online sahi waqt aur aaj ki tareekh kya hui hai?",
    gesture: "smile",
  },
  { label: "Dance", say: "Thora sa dance karo!", gesture: "dance" },
  { label: "Chalo", say: "Chal kar mere paas aao!", gesture: "walk" },
  { label: "Daurro", say: "Daur kar dikhao!", gesture: "run" },
  { label: "Koodo", say: "Jump karo!", gesture: "jump" },
  { label: "Khelo", say: "Mere saath khelo na!", gesture: "play" },
  { label: "Clap", say: "Taaliyan bajao shabash!", gesture: "clap" },
  { label: "Gale lago", say: "Mujhe zor se gale lagao, mujhe aap ki bohat yaad aati hai", gesture: "hug" },
  { label: "Dua", say: "Hamare liye dua karo", gesture: "dua" },
  { label: "Check-up", say: "Mera dil check karo doctor sahiba", gesture: "stethoscope" },
];

async function openPreferredMicStream(): Promise<MediaStream> {
  try {
    return await navigator.mediaDevices.getUserMedia({
      audio: {
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      },
    });
  } catch (constraintErr) {
    if (
      constraintErr instanceof DOMException &&
      (constraintErr.name === "OverconstrainedError" ||
        constraintErr.name === "TypeError" ||
        constraintErr.name === "NotFoundError")
    ) {
      return await navigator.mediaDevices.getUserMedia({ audio: true });
    }
    throw constraintErr;
  }
}

export function FloatingDock({
  noorName,
  caption,
  heardText,
  isBusy,
  isSpeaking,
  started,
  autoListen,
  liveCallStatus,
  liveVideoOn,
  sttLang,
  onToggleAutoListen,
  onToggleLiveCall,
  onToggleLiveVideo,
  onSend,
  onInterruptSpeech,
  onHeardPreview,
  onQuickAction,
  onOpenVision,
  onEnsureStarted,
  onUnlockAudio,
  onListeningChange,
  onToast,
}: FloatingDockProps) {
  const [input, setInput] = useState("");
  const [showActions, setShowActions] = useState(true);
  const [isRecordingNote, setIsRecordingNote] = useState(false);
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [isListeningNow, setIsListeningNow] = useState(false);
  const [wakeWordOnly, setWakeWordOnly] = useState(false);
  const [micLevel, setMicLevel] = useState(0); // 0..100 for compact live meter

  // Continuous 16kHz AudioWorklet Smart VAD refs (rolling pre-buffer + adaptive floor + barge-in)
  const vadStreamRef = useRef<MediaStream | null>(null);
  const vadCtxRef = useRef<AudioContext | null>(null);
  const vadPipeRef = useRef<MicPipelineHandle | null>(null);
  const vadBusySendRef = useRef(false);
  const lastMeterTsRef = useRef(0);
  const lastErrorToastRef = useRef(0);

  // Manual HD Voice Note 16kHz PCM refs
  const noteStreamRef = useRef<MediaStream | null>(null);
  const noteCtxRef = useRef<AudioContext | null>(null);
  const notePipeRef = useRef<MicPipelineHandle | null>(null);
  const noteChunksRef = useRef<Float32Array[]>([]);

  const autoListenRef = useRef(autoListen);
  const isBusyRef = useRef(isBusy);
  const isSpeakingRef = useRef(isSpeaking);
  const startedRef = useRef(started);
  const inCallRef = useRef(liveCallStatus !== "ended");
  const isRecordingNoteRef = useRef(isRecordingNote);
  const sttLangRef = useRef(sttLang);
  const wakeWordOnlyRef = useRef(wakeWordOnly);

  autoListenRef.current = autoListen;
  isBusyRef.current = isBusy;
  isSpeakingRef.current = isSpeaking;
  startedRef.current = started;
  inCallRef.current = liveCallStatus !== "ended";
  isRecordingNoteRef.current = isRecordingNote;
  sttLangRef.current = sttLang;
  wakeWordOnlyRef.current = wakeWordOnly;

  useEffect(() => {
    onListeningChange?.(isListeningNow || isRecordingNote);
  }, [isListeningNow, isRecordingNote, onListeningChange]);

  const notifyMicIssue = (msg: string) => {
    const now = Date.now();
    if (now - lastErrorToastRef.current > 7000) {
      lastErrorToastRef.current = now;
      onToast(msg);
    }
  };

  const stopVadEngine = () => {
    vadPipeRef.current?.stop();
    vadPipeRef.current = null;
    if (vadStreamRef.current) {
      vadStreamRef.current.getTracks().forEach((t) => t.stop());
      vadStreamRef.current = null;
    }
    if (vadCtxRef.current) {
      try {
        vadCtxRef.current.close();
      } catch {}
      vadCtxRef.current = null;
    }
    setIsListeningNow(false);
    setMicLevel(0);
  };

  const stopNoteCapture = async (shouldSend: boolean) => {
    notePipeRef.current?.stop();
    notePipeRef.current = null;
    if (noteStreamRef.current) {
      noteStreamRef.current.getTracks().forEach((t) => t.stop());
      noteStreamRef.current = null;
    }
    if (noteCtxRef.current) {
      try {
        await noteCtxRef.current.close();
      } catch {}
      noteCtxRef.current = null;
    }
    setIsRecordingNote(false);
    setMicLevel(0);

    const chunks = noteChunksRef.current;
    noteChunksRef.current = [];
    if (!shouldSend || chunks.length === 0) return;

    const wavB64 = encodePcm16kChunksToWavBase64(chunks);
    if (wavB64.length < 1800) {
      onToast("Voice note was too short — please speak clearly.");
      return;
    }

    setIsTranscribing(true);
    try {
      const r = await fetch("/api/transcribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          audioBase64: wavB64,
          mimeType: "audio/wav",
          languageHint: sttLangRef.current,
        }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(data.error || "Transcription failed");
      if (data.text?.trim()) {
        onSend(data.text.trim());
      } else {
        onToast("Could not hear words clearly. Please try again.");
      }
    } catch (err) {
      onToast(err instanceof Error ? err.message : "Voice transcription failed");
    } finally {
      setIsTranscribing(false);
    }
  };

  const dispatchWavUtterance = async (chunks: Float32Array[]) => {
    if (!navigator.onLine || chunks.length === 0) return;
    const wavB64 = encodePcm16kChunksToWavBase64(chunks);
    // Skip ultra-tiny clicks (< ~120ms of 16kHz PCM)
    if (wavB64.length < 4000) return;

    setIsTranscribing(true);
    vadBusySendRef.current = true;
    try {
      const r = await fetch("/api/transcribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          audioBase64: wavB64,
          mimeType: "audio/wav",
          languageHint: sttLangRef.current,
        }),
      });
      const data = await r.json().catch(() => ({}));
      if (!r.ok) {
        onHeardPreview("");
        notifyMicIssue(data.error || "Mic speech server error — please speak again.");
        return;
      }
      const clean = typeof data.text === "string" ? data.text.trim() : "";
      if (!clean) {
        onHeardPreview("");
        return;
      }

      if (wakeWordOnlyRef.current && !WAKE_WORD_RE.test(clean)) {
        onHeardPreview(`(Wake word "Noor" needed) ${clean}`);
        return;
      }

      onHeardPreview(clean);
      onSend(clean);
    } catch {
      onHeardPreview("");
      notifyMicIssue("Network issue sending voice — please check WiFi and try again.");
    } finally {
      vadBusySendRef.current = false;
      setIsTranscribing(false);
    }
  };

  const startVadEngine = async (preCreatedCtx?: AudioContext | null) => {
    if (vadStreamRef.current && vadPipeRef.current) {
      if (vadCtxRef.current?.state === "suspended") {
        vadCtxRef.current.resume().catch(() => {});
      }
      setIsListeningNow(true);
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      preCreatedCtx?.close().catch(() => {});
      setIsListeningNow(false);
      onToast("Microphone access is not available in this browser.");
      return;
    }

    try {
      const stream = await openPreferredMicStream();
      if (!autoListenRef.current || inCallRef.current || isRecordingNoteRef.current) {
        stream.getTracks().forEach((t) => t.stop());
        preCreatedCtx?.close().catch(() => {});
        return;
      }

      const AC = getSharedAudioCtxCtor();
      const ctx = preCreatedCtx || new AC();
      if (ctx.state === "suspended") {
        await ctx.resume().catch(() => {});
      }
      if (ctx.state === "suspended") {
        notifyMicIssue("Tap Mic Live once to wake microphone on this device.");
      }

      vadStreamRef.current = stream;
      vadCtxRef.current = ctx;

      // Rolling pre-buffer (~500ms at 16kHz = 8000 samples) prevents clipped first words
      const PRE_BUFFER_MAX_SAMPLES = 8000;
      let preBuffer: Float32Array[] = [];
      let preBufferSamples = 0;

      let capturing = false;
      let speechChunks: Float32Array[] = [];
      let speechSamples = 0;
      let noiseFloor = 0.0042;
      let voiceSustainMs = 0;
      let bargeSustainMs = 0;
      let lastVoiceAt = performance.now();
      let captureStartedAt = 0;

      const pipe = await startMicPcmPipeline(ctx, stream, (pcm16k, rms) => {
        if (!vadStreamRef.current || !autoListenRef.current) return;

        const now = performance.now();
        // Throttle UI voice-level bar updates (~15 fps)
        if (now - lastMeterTsRef.current > 65) {
          lastMeterTsRef.current = now;
          const pct = Math.min(100, Math.round(rms * 1150));
          setMicLevel(pct);
        }

        const chunkMs = (pcm16k.length / 16000) * 1000;

        // If AI is busy thinking or transcribing previous utterance, keep ring buffer clean
        if (
          isBusyRef.current ||
          isRecordingNoteRef.current ||
          inCallRef.current ||
          vadBusySendRef.current
        ) {
          capturing = false;
          speechChunks = [];
          speechSamples = 0;
          voiceSustainMs = 0;
          bargeSustainMs = 0;
          return;
        }

        // Barge-In support: while Dr. Noor speaks, ignore soft echo, interrupt if user clearly talks (>200ms)
        if (isSpeakingRef.current) {
          const bargeThreshold = Math.max(0.025, noiseFloor * 4.2);
          if (rms > bargeThreshold) {
            bargeSustainMs += chunkMs;
            preBuffer.push(pcm16k);
            preBufferSamples += pcm16k.length;
            while (preBufferSamples > PRE_BUFFER_MAX_SAMPLES && preBuffer.length > 1) {
              const removed = preBuffer.shift()!;
              preBufferSamples -= removed.length;
            }
            if (bargeSustainMs >= 200) {
              bargeSustainMs = 0;
              onInterruptSpeech?.();
              capturing = true;
              captureStartedAt = now;
              lastVoiceAt = now;
              speechChunks = [...preBuffer];
              speechSamples = preBufferSamples;
              preBuffer = [];
              preBufferSamples = 0;
              onHeardPreview("Listening…");
            }
          } else {
            bargeSustainMs = Math.max(0, bargeSustainMs - chunkMs * 0.5);
          }
          return;
        }

        // Sensitive adaptive noise floor calibrated for quiet & standard mobile microphones
        const startThreshold = Math.max(0.0055, noiseFloor * 1.85);
        const holdThreshold = Math.max(0.0038, noiseFloor * 1.35);

        if (!capturing) {
          preBuffer.push(pcm16k);
          preBufferSamples += pcm16k.length;
          while (preBufferSamples > PRE_BUFFER_MAX_SAMPLES && preBuffer.length > 1) {
            const removed = preBuffer.shift()!;
            preBufferSamples -= removed.length;
          }

          if (rms > startThreshold) {
            voiceSustainMs += chunkMs;
            if (voiceSustainMs >= 45) {
              capturing = true;
              voiceSustainMs = 0;
              captureStartedAt = now;
              lastVoiceAt = now;
              speechChunks = [...preBuffer];
              speechSamples = preBufferSamples;
              preBuffer = [];
              preBufferSamples = 0;
              onHeardPreview("Listening…");
            }
          } else {
            voiceSustainMs = 0;
            noiseFloor = noiseFloor * 0.96 + Math.min(rms, 0.03) * 0.04;
          }
        } else {
          speechChunks.push(pcm16k);
          speechSamples += pcm16k.length;

          if (rms > holdThreshold) {
            lastVoiceAt = now;
          }

          const silentMs = now - lastVoiceAt;
          const totalMs = now - captureStartedAt;
          // Commit once user pauses for 620ms (with >= 250ms speech) or hits 9.5s max turn
          if ((silentMs >= 620 && speechSamples >= 4000) || totalMs >= 9500) {
            const finalized = speechChunks;
            capturing = false;
            speechChunks = [];
            speechSamples = 0;
            void dispatchWavUtterance(finalized);
          } else if (silentMs >= 1450 && speechSamples < 4000) {
            capturing = false;
            speechChunks = [];
            speechSamples = 0;
            onHeardPreview("");
          }
        }
      });

      // Handle unexpected OS track ending (phone call / device unplug) by cleanly restarting
      stream.getTracks().forEach((track) => {
        track.onended = () => {
          if (vadStreamRef.current === stream) {
            stopVadEngine();
            if (autoListenRef.current && startedRef.current && !inCallRef.current) {
              setTimeout(() => {
                void startVadEngine();
              }, 800);
            }
          }
        };
      });

      vadPipeRef.current = pipe;
      setIsListeningNow(true);
    } catch (err) {
      preCreatedCtx?.close().catch(() => {});
      setIsListeningNow(false);
      const isDenied =
        err instanceof DOMException &&
        (err.name === "NotAllowedError" || err.name === "SecurityError");
      onToast(
        isDenied
          ? "Allow microphone permission in your browser lock icon, then tap Mic Live."
          : "Tap Mic Live once to activate your microphone."
      );
    }
  };

  useEffect(() => {
    if (!autoListen || isRecordingNote || liveCallStatus !== "ended") {
      stopVadEngine();
      return;
    }

    if (started) {
      void startVadEngine();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [started, autoListen, isRecordingNote, liveCallStatus]);

  useEffect(() => {
    return () => {
      stopVadEngine();
      void stopNoteCapture(false);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const toggleVoiceNote = async () => {
    onEnsureStarted?.();
    onUnlockAudio?.();
    if (isRecordingNote) {
      await stopNoteCapture(true);
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      onToast("Microphone recording is unavailable in this browser.");
      return;
    }

    stopVadEngine();

    // Synchronously construct & resume AudioContext inside user tap for iOS/Android Safari
    let ctx: AudioContext | null = null;
    try {
      const AC = getSharedAudioCtxCtor();
      ctx = new AC();
      if (ctx.state === "suspended") {
        void ctx.resume().catch(() => {});
      }
    } catch {}

    try {
      const stream = await openPreferredMicStream();
      const activeCtx = ctx || new (getSharedAudioCtxCtor())();
      noteChunksRef.current = [];
      noteStreamRef.current = stream;
      noteCtxRef.current = activeCtx;

      const pipe = await startMicPcmPipeline(activeCtx, stream, (pcm16k, rms) => {
        noteChunksRef.current.push(pcm16k);
        const now = performance.now();
        if (now - lastMeterTsRef.current > 65) {
          lastMeterTsRef.current = now;
          setMicLevel(Math.min(100, Math.round(rms * 1150)));
        }
      });
      notePipeRef.current = pipe;
      setIsRecordingNote(true);
    } catch {
      ctx?.close().catch(() => {});
      onToast("Microphone permission denied.");
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onUnlockAudio?.();
    const v = input.trim();
    if (!v) return;
    setInput("");
    onSend(v);
  };

  const handleAutoListenClick = () => {
    onEnsureStarted?.();
    onUnlockAudio?.();
    startedRef.current = true;

    if (!autoListen || !started || !isListeningNow) {
      // Synchronously create & resume AudioContext inside the tap gesture
      let tapCtx: AudioContext | null = null;
      try {
        const AC = getSharedAudioCtxCtor();
        tapCtx = new AC();
        if (tapCtx.state === "suspended") {
          void tapCtx.resume().catch(() => {});
        }
      } catch {}

      autoListenRef.current = true;
      if (!autoListen) {
        onToggleAutoListen();
      }
      if (!isRecordingNote && liveCallStatus === "ended") {
        void startVadEngine(tapCtx);
      } else {
        tapCtx?.close().catch(() => {});
      }
      return;
    }

    stopVadEngine();
    onToggleAutoListen();
  };

  const inCall = liveCallStatus !== "ended";

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-20 px-3 pb-3 pt-10 bg-gradient-to-t from-[#0e0c14]/90 via-[#0e0c14]/50 to-transparent">
      <div className="max-w-2xl mx-auto flex flex-col gap-2">
        {/* Live Voice-Level Meter + Wake-Word Mode Strip when Mic is Active */}
        {(isListeningNow || isRecordingNote) && !inCall && (
          <div className="pointer-events-auto self-center flex items-center gap-2.5 px-3 py-1 rounded-xl bg-[#15121e]/85 backdrop-blur-md border border-white/12 text-[11px] text-white/80">
            <div className="flex items-end gap-0.5 h-3.5" aria-hidden="true">
              {[18, 34, 52, 70, 88].map((threshold, idx) => {
                const active = micLevel >= threshold;
                return (
                  <span
                    key={idx}
                    className={`w-1 rounded-sm transition-all duration-75 ${
                      active
                        ? idx >= 4
                          ? "bg-[#e6483d] h-3.5"
                          : "bg-[#5eead4] h-3"
                        : "bg-white/20 h-1.5"
                    }`}
                  />
                );
              })}
            </div>
            <span className="font-medium text-[#5eead4]">
              {isRecordingNote
                ? "Recording HD Voice…"
                : isTranscribing
                  ? "Understanding…"
                  : isSpeaking
                    ? "Speak loudly to interrupt"
                    : wakeWordOnly
                      ? 'Say "Noor…" to ask'
                      : "24/7 Live Mic Active"}
            </span>
            {!isRecordingNote && (
              <button
                type="button"
                onClick={() => setWakeWordOnly((v) => !v)}
                className={`px-2 py-0.5 rounded-md border text-[10px] font-semibold transition-colors cursor-pointer ${
                  wakeWordOnly
                    ? "bg-[#e8b86d]/20 border-[#e8b86d]/55 text-[#e8b86d]"
                    : "bg-white/[0.05] border-white/15 text-white/75 hover:text-white"
                }`}
                title="Switch between Always Listen and Wake-Word ('Hey Noor')"
              >
                {wakeWordOnly ? "Wake: Noor" : "All Speech"}
              </button>
            )}
          </div>
        )}

        {/* Heard preview & live spoken subtitle */}
        {heardText && (
          <p
            className={`text-center text-xs text-white/70 truncate drop-shadow ${
              URDU_RE.test(heardText) ? "font-urdu" : ""
            }`}
          >
            “{heardText}”
          </p>
        )}

        {caption && (
          <div
            aria-live="polite"
            className={`pointer-events-auto max-h-24 overflow-y-auto noor-scroll text-center text-sm sm:text-base font-medium leading-relaxed text-[#faf6f0] drop-shadow-[0_2px_8px_rgba(0,0,0,0.9)] px-3 py-1.5 rounded-2xl bg-[#0e0c14]/55 backdrop-blur-md border border-white/10 ${
              URDU_RE.test(caption) ? "font-urdu text-base sm:text-lg" : ""
            }`}
          >
            {caption}
          </div>
        )}

        {/* Collapsible Quick Gestures Strip */}
        {showActions && (
          <div className="pointer-events-auto flex items-center gap-1.5 overflow-x-auto noor-scroll pb-0.5">
            {QUICK_ACTIONS.map((act) => (
              <button
                key={act.label}
                type="button"
                onClick={() => onQuickAction(act.say, act.gesture)}
                className="min-h-[34px] px-3 py-1 rounded-xl bg-[#15121e]/80 hover:bg-[#251f33] backdrop-blur-md border border-white/12 text-xs font-medium text-[#faf6f0]/90 transition-colors whitespace-nowrap shrink-0 cursor-pointer"
              >
                {act.label}
              </button>
            ))}
          </div>
        )}

        {/* Compact Floating Chat + Live Call + Always-Open Mic Bar */}
        <form
          onSubmit={handleSubmit}
          className="pointer-events-auto flex items-center gap-1.5 p-1.5 rounded-2xl bg-[#15121e]/85 backdrop-blur-xl border border-white/15 shadow-2xl"
        >
          <button
            type="button"
            onClick={() => setShowActions((v) => !v)}
            title={showActions ? "Hide quick actions" : "Show quick actions"}
            aria-label={showActions ? "Hide quick actions" : "Show quick actions"}
            className="min-h-[42px] min-w-[34px] rounded-xl hover:bg-white/[0.06] text-white/65 flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            {showActions ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronUp className="w-4 h-4" />
            )}
          </button>

          {/* Real-Time Gemini Live Phone Call Button */}
          <button
            type="button"
            onClick={onToggleLiveCall}
            title={
              inCall
                ? "End real-time live voice call"
                : "Start real-time live voice call with Dr. Noor"
            }
            className={`min-h-[42px] px-3 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              inCall
                ? "bg-[#e6483d] border-[#e6483d] text-white shadow-lg"
                : "bg-[#5eead4]/15 hover:bg-[#5eead4]/25 border-[#5eead4]/45 text-[#5eead4]"
            }`}
          >
            {inCall ? (
              <PhoneOff className="w-4 h-4" />
            ) : (
              <PhoneCall className="w-4 h-4" />
            )}
            <span className="hidden sm:inline">
              {liveCallStatus === "connecting"
                ? "Calling…"
                : liveCallStatus === "connected"
                  ? "End Call"
                  : "Live Call"}
            </span>
          </button>

          {inCall && (
            <button
              type="button"
              onClick={onToggleLiveVideo}
              title={liveVideoOn ? "Turn off live camera" : "Show camera to Dr. Noor during call"}
              aria-label="Toggle live call camera"
              className={`min-h-[42px] min-w-[40px] rounded-xl border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                liveVideoOn
                  ? "bg-[#e8b86d]/20 border-[#e8b86d]/60 text-[#e8b86d]"
                  : "bg-[#1c1826] border-white/10 text-white/75"
              }`}
            >
              {liveVideoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
            </button>
          )}

          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={
              inCall
                ? "Live Call active — just speak naturally…"
                : isTranscribing
                  ? "Understanding your voice…"
                  : isRecordingNote
                    ? "Recording HD voice… tap Stop"
                    : isListeningNow
                      ? `Listening… speak or type to ${noorName.split(" ")[0]}`
                      : `Talk or type to Dr. ${noorName.split(" ")[0]}…`
            }
            disabled={isRecordingNote || isTranscribing || inCall}
            className="flex-1 min-w-0 min-h-[42px] px-2 bg-transparent outline-none text-sm text-[#faf6f0] placeholder:text-white/45"
          />

          <button
            type="button"
            onClick={onOpenVision}
            title="Live Camera / Scan medicine, PDF or report"
            aria-label="Scan medicine or report"
            className="min-h-[42px] min-w-[38px] rounded-xl hover:bg-white/[0.08] text-[#e8b86d] flex items-center justify-center transition-colors cursor-pointer shrink-0"
          >
            <Camera className="w-4 h-4" />
          </button>

          {!inCall && (
            <>
              <button
                type="button"
                onClick={toggleVoiceNote}
                disabled={isTranscribing}
                title={
                  isRecordingNote
                    ? "Stop & send HD voice note"
                    : "Record HD Urdu/English voice note"
                }
                aria-label="Record HD voice note"
                className={`min-h-[42px] min-w-[40px] rounded-xl border flex items-center justify-center transition-colors cursor-pointer shrink-0 ${
                  isRecordingNote
                    ? "bg-[#e6483d] border-[#e6483d] text-white"
                    : "bg-[#1c1826] hover:bg-[#262033] border-white/10 text-[#e8b86d]"
                }`}
              >
                {isRecordingNote ? (
                  <Square className="w-4 h-4 fill-current" />
                ) : (
                  <Mic className="w-4 h-4" />
                )}
              </button>

              <button
                type="button"
                onClick={handleAutoListenClick}
                title={
                  autoListen
                    ? isListeningNow
                      ? "24/7 Hands-Free Mic is Live — click to mute"
                      : "Click to activate 24/7 Live Mic"
                    : "Turn ON 24/7 hands-free mic"
                }
                aria-label="Toggle always-open hands-free mic"
                className={`min-h-[42px] px-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer shrink-0 ${
                  autoListen
                    ? isListeningNow
                      ? "bg-[#5eead4]/20 border-[#5eead4]/65 text-[#5eead4]"
                      : "bg-[#e8b86d]/15 border-[#e8b86d]/55 text-[#e8b86d]"
                    : "bg-[#1c1826] hover:bg-[#262033] border-white/10 text-white/70"
                }`}
              >
                {autoListen ? (
                  <Radio className={`w-4 h-4 ${isListeningNow ? "animate-pulse" : ""}`} />
                ) : (
                  <MicOff className="w-4 h-4" />
                )}
                <span className="hidden md:inline">
                  {autoListen ? (isListeningNow ? "Mic Live" : "Tap Mic") : "Mic Off"}
                </span>
              </button>

              <button
                type="submit"
                disabled={!input.trim() || isBusy}
                aria-label="Send message"
                className="min-h-[42px] min-w-[42px] rounded-xl bg-[#e6483d] hover:bg-[#d13b30] disabled:opacity-40 text-white flex items-center justify-center transition-colors cursor-pointer shrink-0"
              >
                <Send className="w-4 h-4" />
              </button>
            </>
          )}
        </form>
      </div>
    </div>
  );
}
