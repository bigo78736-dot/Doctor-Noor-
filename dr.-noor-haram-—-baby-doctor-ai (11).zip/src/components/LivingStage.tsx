import { useEffect, useRef, useState } from "react";
import { Heart, Maximize2, Minimize2, ScanFace, Sparkles, Stethoscope, VolumeX, X } from "lucide-react";
import { AvatarEngine } from "../lib/avatarEngine";
import type { FacePoints, GestureName } from "../types/noor";

interface FxItem {
  id: number;
  kind: "float" | "sparkle" | "hand" | "ball" | "card" | "think";
  text?: string;
  left: number;
  top: number;
  dx?: number;
  rot?: number;
  delay?: number;
  size?: number;
  bpm?: number;
}

interface LivingStageProps {
  photoUrl: string;
  points: FacePoints;
  bodyMode: boolean;
  name: string;
  isSpeaking: boolean;
  familyMode: boolean;
  started: boolean;
  onStart: () => void;
  onStopSpeech: () => void;
  onAvatarReady: (engine: AvatarEngine | null) => void;
  onToast?: (msg: string) => void;
}

export function LivingStage({
  photoUrl,
  points,
  bodyMode,
  name,
  isSpeaking,
  familyMode,
  started,
  onStart,
  onStopSpeech,
  onAvatarReady,
  onToast,
}: LivingStageProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const stageRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<AvatarEngine | null>(null);
  const lastTapRef = useRef(0);
  const [zoomed, setZoomed] = useState(false);
  const [fxList, setFxList] = useState<FxItem[]>([]);
  const fxIdRef = useRef(1);

  // Opt-in Camera Face-Tracking stage refs & state
  const [faceTrackOn, setFaceTrackOn] = useState(false);
  const faceVideoRef = useRef<HTMLVideoElement | null>(null);
  const faceStreamRef = useRef<MediaStream | null>(null);
  const faceIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const lastTrackGestureAtRef = useRef(0);

  const spawnEffects = (gesture: GestureName) => {
    const engine = engineRef.current;
    const stage = stageRef.current;
    const rect = stage?.getBoundingClientRect();
    const W = rect?.width || 400;
    const H = rect?.height || 600;
    const f = engine?.getFace();
    const cx = f?.x ?? W / 2;
    const cy = f?.y ?? H * 0.35;
    const d = f?.d ?? 90;

    const batch: FxItem[] = [];
    const pushItem = (item: Omit<FxItem, "id">, durationMs = 2800) => {
      const id = fxIdRef.current++;
      batch.push({ ...item, id });
      setTimeout(() => {
        setFxList((prev) => prev.filter((x) => x.id !== id));
      }, durationMs);
    };

    if (gesture === "heart" || gesture === "hug") {
      const chars = gesture === "hug" ? ["🤗", "❤️", "💞", "💖"] : ["❤️", "💖", "💕", "💗"];
      for (let i = 0; i < 9; i++) {
        pushItem(
          {
            kind: "float",
            text: chars[i % chars.length],
            left: cx + (Math.random() - 0.5) * d * 2.6,
            top: cy + d * 0.8,
            dx: (Math.random() - 0.5) * 90,
            rot: (Math.random() - 0.5) * 45,
            delay: i * 0.14,
            size: 20 + Math.random() * 14,
          },
          3200
        );
      }
    }

    if (["smile", "laugh", "jump", "dua", "hug", "play", "clap"].includes(gesture)) {
      const count = gesture === "dua" || gesture === "jump" ? 10 : 6;
      for (let i = 0; i < count; i++) {
        pushItem(
          {
            kind: "sparkle",
            left: cx + (Math.random() - 0.5) * d * 2.8,
            top: cy + (Math.random() - 0.4) * d * 2.4,
            delay: Math.random() * 0.7,
          },
          2200
        );
      }
    }

    if (gesture === "dance") {
      const notes = ["🎵", "🎶", "✨"];
      for (let i = 0; i < 7; i++) {
        pushItem(
          {
            kind: "float",
            text: notes[i % notes.length],
            left: cx + (Math.random() - 0.5) * d * 2.6,
            top: cy + d * 0.5,
            dx: (Math.random() - 0.5) * 80,
            rot: (Math.random() - 0.5) * 35,
            delay: i * 0.18,
            size: 22,
          },
          3000
        );
      }
    }

    if (gesture === "wave") {
      pushItem(
        {
          kind: "hand",
          text: "👋",
          left: Math.min(W - 70, cx + d * 1.15),
          top: cy + d * 0.3,
          size: 44,
        },
        2400
      );
    }

    if (gesture === "play") {
      pushItem(
        {
          kind: "ball",
          text: "⚽",
          left: cx - 18,
          top: Math.min(H - 160, cy + d * 1.8),
          size: 38,
        },
        4800
      );
    }

    if (gesture === "think") {
      pushItem(
        {
          kind: "think",
          text: "💭",
          left: Math.min(W - 60, cx + d * 0.8),
          top: Math.max(64, cy - d * 1.1),
          size: 32,
        },
        2400
      );
    }

    if (gesture === "stethoscope") {
      pushItem(
        {
          kind: "card",
          left: W / 2,
          top: 90,
          bpm: 74 + Math.floor(Math.random() * 14),
        },
        3200
      );
    }

    if (batch.length) {
      setFxList((prev) => [...prev.slice(-24), ...batch]);
    }
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const engine = new AvatarEngine(canvas, {
      fit: "contain",
      body: bodyMode,
      onEffect: spawnEffects,
    });
    engineRef.current = engine;
    onAvatarReady(engine);

    engine.load(photoUrl, points, bodyMode).catch(() => {});

    return () => {
      onAvatarReady(null);
      engine.destroy();
      engineRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const engine = engineRef.current;
    if (!engine) return;
    engine.load(photoUrl, points, bodyMode).catch(() => {});
  }, [photoUrl, points, bodyMode]);

  const stopFaceTrack = () => {
    if (faceIntervalRef.current) {
      clearInterval(faceIntervalRef.current);
      faceIntervalRef.current = null;
    }
    if (faceStreamRef.current) {
      faceStreamRef.current.getTracks().forEach((t) => t.stop());
      faceStreamRef.current = null;
    }
    if (faceVideoRef.current) {
      faceVideoRef.current.srcObject = null;
    }
    setFaceTrackOn(false);
  };

  useEffect(() => {
    return () => {
      if (faceIntervalRef.current) clearInterval(faceIntervalRef.current);
      if (faceStreamRef.current) faceStreamRef.current.getTracks().forEach((t) => t.stop());
    };
  }, []);

  const toggleFaceTrack = async () => {
    if (faceTrackOn) {
      stopFaceTrack();
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia) {
      onToast?.("Front camera is unavailable in this browser.");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user", width: { ideal: 320 }, height: { ideal: 240 } },
      });
      faceStreamRef.current = stream;
      setFaceTrackOn(true);

      const offscreen = document.createElement("canvas");
      offscreen.width = 64;
      offscreen.height = 48;
      const ctx = offscreen.getContext("2d", { willReadFrequently: true });
      let prevLuma: Uint8Array | null = null;
      let smoothNx = 0.5;
      let smoothNy = 0.35;

      requestAnimationFrame(() => {
        if (faceVideoRef.current) {
          faceVideoRef.current.srcObject = stream;
        }
      });

      faceIntervalRef.current = setInterval(() => {
        const v = faceVideoRef.current;
        const stage = stageRef.current;
        const engine = engineRef.current;
        if (!v || v.videoWidth === 0 || !ctx || !stage || !engine) return;

        ctx.drawImage(v, 0, 0, 64, 48);
        const frame = ctx.getImageData(0, 0, 64, 48).data;
        const luma = new Uint8Array(64 * 48);

        let sumX = 0;
        let sumY = 0;
        let sumW = 0;
        let motionTotal = 0;

        for (let y = 0; y < 48; y++) {
          for (let x = 0; x < 64; x++) {
            const p = y * 64 + x;
            const i = p * 4;
            const yVal = (frame[i] * 77 + frame[i + 1] * 150 + frame[i + 2] * 29) >> 8;
            luma[p] = yVal;

            if (prevLuma) {
              const diff = Math.abs(yVal - prevLuma[p]);
              if (diff > 18) {
                motionTotal += diff;
                // Front camera is mirrored naturally
                sumX += (63 - x) * diff;
                sumY += y * diff;
                sumW += diff;
              }
            }
          }
        }
        prevLuma = luma;

        // If motionless, fall back softly to upper-center brightness centroid
        if (sumW < 250) {
          let bx = 0;
          let by = 0;
          let bw = 0;
          for (let y = 4; y < 34; y++) {
            for (let x = 10; x < 54; x++) {
              const val = luma[y * 64 + x];
              if (val > 85) {
                const w = val - 85;
                bx += (63 - x) * w;
                by += y * w;
                bw += w;
              }
            }
          }
          if (bw > 0) {
            sumX = bx;
            sumY = by;
            sumW = bw;
          }
        }

        if (sumW > 0) {
          const nx = Math.max(0.1, Math.min(0.9, sumX / sumW / 63));
          const ny = Math.max(0.1, Math.min(0.9, sumY / sumW / 47));
          smoothNx = smoothNx * 0.65 + nx * 0.35;
          smoothNy = smoothNy * 0.65 + ny * 0.35;
          const rect = stage.getBoundingClientRect();
          engine.lookAt(rect.left + smoothNx * rect.width, rect.top + smoothNy * rect.height);
        }

        if (motionTotal > 32000 && Date.now() - lastTrackGestureAtRef.current > 9000) {
          lastTrackGestureAtRef.current = Date.now();
          engine.play(Math.random() > 0.45 ? "smile" : "wave");
        }
      }, 130);

      onToast?.("Face Tracking on — Dr. Noor looks at you & smiles naturally!");
    } catch {
      onToast?.("Could not open front camera for face tracking.");
    }
  };

  const toggleZoom = () => {
    const next = !zoomed;
    setZoomed(next);
    engineRef.current?.setZoom(next);
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const engine = engineRef.current;
    if (!engine) return;
    engine.lookAt(e.clientX, e.clientY);
    if (!started) return;
    const now = Date.now();
    if (now - lastTapRef.current < 850) return;
    lastTapRef.current = now;
    const f = engine.getFace();
    const nearFace = f && Math.hypot(e.clientX - f.x, e.clientY - f.y) < f.d * 2.2;
    const moves: GestureName[] = nearFace
      ? ["smile", "wink", "laugh", "heart"]
      : ["wave", "hug", "jump", "clap", "play", "dance"];
    engine.play(moves[Math.floor(Math.random() * moves.length)]);
  };

  return (
    <div
      ref={stageRef}
      onPointerMove={(e) => engineRef.current?.lookAt(e.clientX, e.clientY)}
      className="relative w-full h-full overflow-hidden bg-[#0e0c14] select-none"
    >
      <canvas
        ref={canvasRef}
        onPointerDown={handlePointerDown}
        onDoubleClick={toggleZoom}
        aria-label={`Dr. ${name} living portrait`}
        className="w-full h-full block cursor-pointer"
      />

      {/* Stage Subtle Vignette */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-[#0e0c14]/70 via-transparent to-[#0e0c14]/40" />

      {/* Stage Status & Zoom/Mute/Face-Track Controls below header */}
      <div className="absolute top-16 left-3 right-3 z-10 flex items-center justify-between gap-2 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#15121e]/75 backdrop-blur-md border border-white/10">
          <Stethoscope className="w-3.5 h-3.5 text-[#e6483d] shrink-0" />
          <span className="text-xs font-medium text-[#faf6f0]/90">
            {familyMode ? "Family Mode" : "Baby Doctor AI"}
          </span>
          {isSpeaking && (
            <svg className="w-11 h-4 ml-0.5" viewBox="0 0 120 30" aria-hidden="true">
              <path
                className="ecg-line"
                d="M0 15h30l5-9 6 20 6-16 4 5h69"
                fill="none"
                stroke="#5eead4"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </svg>
          )}
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          {isSpeaking && (
            <button
              type="button"
              onClick={onStopSpeech}
              title="Stop speaking"
              className="min-h-[38px] px-3 rounded-xl bg-[#e6483d]/90 hover:bg-[#e6483d] text-white text-xs font-semibold flex items-center gap-1.5 shadow-lg transition-colors whitespace-nowrap shrink-0 cursor-pointer"
            >
              <VolumeX className="w-4 h-4" />
              <span>Mute</span>
            </button>
          )}
          <button
            type="button"
            onClick={toggleFaceTrack}
            title={
              faceTrackOn
                ? "Turn off Eye Face-Tracking"
                : "Eye Face-Tracking: Dr. Noor watches & reacts to you"
            }
            aria-label="Toggle camera eye face tracking"
            className={`min-h-[38px] px-2.5 rounded-xl backdrop-blur-md border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              faceTrackOn
                ? "bg-[#5eead4]/20 border-[#5eead4]/65 text-[#5eead4]"
                : "bg-[#15121e]/75 hover:bg-[#1c1826] border-white/10 text-white/85"
            }`}
          >
            <ScanFace className="w-4 h-4" />
            <span className="hidden sm:inline">{faceTrackOn ? "Eye Track" : "Face Track"}</span>
          </button>
          <button
            type="button"
            onClick={toggleZoom}
            title={zoomed ? "Full body view" : "Close-up face view"}
            aria-label={zoomed ? "Full body view" : "Close-up face view"}
            className="min-h-[38px] min-w-[38px] rounded-xl bg-[#15121e]/75 hover:bg-[#1c1826] backdrop-blur-md border border-white/10 text-white/85 flex items-center justify-center transition-colors cursor-pointer"
          >
            {zoomed ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>
      </div>

      {/* Dismissible Corner Face-Track Self Preview */}
      {faceTrackOn && (
        <div className="absolute top-28 right-3 z-20 w-24 h-20 rounded-2xl overflow-hidden border border-[#5eead4]/55 bg-black shadow-xl">
          <video
            ref={faceVideoRef}
            autoPlay
            playsInline
            muted
            className="w-full h-full object-cover scale-x-[-1]"
          />
          <button
            type="button"
            onClick={stopFaceTrack}
            aria-label="Stop face tracking"
            className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/70 text-white flex items-center justify-center cursor-pointer"
          >
            <X className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Expressive Effects Layer */}
      <div className="pointer-events-none absolute inset-0 z-10 overflow-hidden" aria-hidden="true">
        {fxList.map((item) => {
          if (item.kind === "float") {
            return (
              <div
                key={item.id}
                className="fx-float"
                style={
                  {
                    left: `${item.left}px`,
                    fontSize: `${item.size || 24}px`,
                    animationDelay: `${item.delay || 0}s`,
                    "--dx": `${item.dx || 0}px`,
                    "--rot": `${item.rot || 0}deg`,
                  } as React.CSSProperties
                }
              >
                {item.text}
              </div>
            );
          }
          if (item.kind === "sparkle") {
            return (
              <div
                key={item.id}
                className="fx-sparkle"
                style={{
                  left: `${item.left}px`,
                  top: `${item.top}px`,
                  animationDelay: `${item.delay || 0}s`,
                }}
              />
            );
          }
          if (item.kind === "hand") {
            return (
              <div
                key={item.id}
                className="fx-hand"
                style={{
                  left: `${item.left}px`,
                  top: `${item.top}px`,
                  fontSize: `${item.size || 44}px`,
                }}
              >
                {item.text}
              </div>
            );
          }
          if (item.kind === "ball") {
            return (
              <div
                key={item.id}
                className="fx-ball"
                style={{
                  left: `${item.left}px`,
                  top: `${item.top}px`,
                  fontSize: `${item.size || 36}px`,
                }}
              >
                {item.text}
              </div>
            );
          }
          if (item.kind === "think") {
            return (
              <div
                key={item.id}
                className="fx-float"
                style={{
                  left: `${item.left}px`,
                  top: `${item.top}px`,
                  fontSize: `${item.size || 32}px`,
                }}
              >
                {item.text}
              </div>
            );
          }
          if (item.kind === "card") {
            return (
              <div
                key={item.id}
                className="absolute left-1/2 -translate-x-1/2 top-24 px-4 py-2 rounded-2xl bg-[#15121e]/95 border border-white/15 shadow-xl flex items-center gap-3 text-sm font-semibold text-[#faf6f0]"
              >
                <Stethoscope className="w-4 h-4 text-[#e6483d]" />
                <svg className="w-16 h-5" viewBox="0 0 90 28">
                  <path
                    className="ecg-line"
                    d="M0 14h24l4-8 6 18 6-14 4 4h46"
                    fill="none"
                    stroke="#5eead4"
                    strokeWidth="2.4"
                  />
                </svg>
                <span className="font-mono-tabular text-[#5eead4]">{item.bpm} BPM</span>
              </div>
            );
          }
          return null;
        })}
      </div>

      {/* Initial Audio & Mic Unlock Overlay */}
      {!started && (
        <div className="absolute inset-0 z-30 flex items-center justify-center bg-[#0e0c14]/65 backdrop-blur-sm p-6">
          <button
            type="button"
            onClick={onStart}
            className="group flex flex-col items-center gap-2.5 px-8 py-6 rounded-3xl bg-[#1c1826]/95 hover:bg-[#251f33] border border-[#e8b86d]/40 shadow-2xl transition-transform active:scale-[0.98] cursor-pointer text-center"
          >
            <div className="w-14 h-14 rounded-2xl bg-[#e6483d]/20 border border-[#e6483d]/45 flex items-center justify-center text-[#e6483d] group-hover:scale-105 transition-transform">
              <Heart className="w-7 h-7 fill-current" />
            </div>
            <span className="text-xl font-bold tracking-tight text-[#faf6f0] flex items-center gap-2">
              Meet Dr. {name.split(" ")[0]}
              <Sparkles className="w-4 h-4 text-[#e8b86d]" />
            </span>
            <span className="text-xs text-white/75 max-w-xs leading-relaxed">
              Tap once to wake her baby-girl voice, living portrait &amp; hands-free listening
            </span>
          </button>
        </div>
      )}
    </div>
  );
}
