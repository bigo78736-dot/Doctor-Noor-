import { useEffect, useRef, useState } from "react";
import {
  Camera,
  Check,
  Cloud,
  Copy,
  HardDriveDownload,
  Lock,
  LogIn,
  LogOut,
  RotateCcw,
  Search,
  Sparkles,
  Unlock,
  Upload,
  Users,
  Volume2,
  X,
} from "lucide-react";
import type { NoorBackupBundle } from "../lib/autoSave";
import { DEFAULT_PROFILE, hashPin } from "../lib/constants";
import { GEMINI_VOICE_STYLES, VOICE_PRESETS, girlVoices } from "../lib/voices";
import type {
  FacePoints,
  FamilyRoomConfig,
  NoorProfile,
  VoiceSettings,
} from "../types/noor";

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  profile: NoorProfile;
  settings: VoiceSettings;
  familyMode: boolean;
  customPinHash: string;
  onUpdateProfile: (next: NoorProfile) => void;
  onUpdateSettings: (next: VoiceSettings) => void;
  onToggleFamilyMode: (enable: boolean) => void;
  onSaveCustomPinHash: (hash: string) => void;
  onDownloadBackup: () => void;
  onRestoreBackup: (bundle: NoorBackupBundle) => void;
  onTestVoice: (sampleText: string) => void;
  cloudUser?: { uid: string; displayName: string | null; email: string | null } | null;
  cloudSyncStatus?: "signed_out" | "syncing" | "synced" | "error";
  onSignInCloud?: () => void;
  onSignOutCloud?: () => void;
  activeRoom?: FamilyRoomConfig | null;
  roomBusy?: boolean;
  shareAppBaseUrl?: string;
  onCreateFamilyRoom?: (roomName: string, passcode?: string) => Promise<void>;
  onJoinFamilyRoom?: (roomCode: string, passcode: string) => Promise<void>;
  onLeaveFamilyRoom?: () => Promise<void>;
  onToast: (msg: string) => void;
}

type LandmarkKey = "leftEye" | "rightEye" | "mouth";

export function SettingsModal({
  open,
  onClose,
  profile,
  settings,
  familyMode,
  customPinHash,
  onUpdateProfile,
  onUpdateSettings,
  onToggleFamilyMode,
  onSaveCustomPinHash,
  onDownloadBackup,
  onRestoreBackup,
  onTestVoice,
  cloudUser,
  cloudSyncStatus = "signed_out",
  onSignInCloud,
  onSignOutCloud,
  activeRoom,
  roomBusy = false,
  shareAppBaseUrl = "",
  onCreateFamilyRoom,
  onJoinFamilyRoom,
  onLeaveFamilyRoom,
  onToast,
}: SettingsModalProps) {
  const [section, setSection] = useState<"voice" | "family" | "photo">("voice");
  const [deviceVoices, setDeviceVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [voiceQuery, setVoiceQuery] = useState("");
  const [newPin, setNewPin] = useState("");
  const [activeMarker, setActiveMarker] = useState<LandmarkKey>("leftEye");
  const [roomNameInput, setRoomNameInput] = useState("Ayan & Muhammad Family");
  const [roomCodeInput, setRoomCodeInput] = useState("");
  const [roomPassInput, setRoomPassInput] = useState("");

  const photoInputRef = useRef<HTMLInputElement | null>(null);
  const backupInputRef = useRef<HTMLInputElement | null>(null);
  const calibratorRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open || !window.speechSynthesis) return;
    const refresh = () => setDeviceVoices(girlVoices(window.speechSynthesis.getVoices()));
    refresh();
    window.speechSynthesis.onvoiceschanged = refresh;
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const q = voiceQuery.trim().toLowerCase();
  const filteredGeminiVoices = GEMINI_VOICE_STYLES.filter((v) => {
    if (!q) return true;
    return (
      v.label.toLowerCase().includes(q) ||
      v.category.toLowerCase().includes(q) ||
      String(v.index) === q
    );
  });

  const filteredOfflinePresets = VOICE_PRESETS.filter((p) => {
    if (!q) return true;
    return p.name.toLowerCase().includes(q) || String(p.id + 1) === q;
  });

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const rawUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ""));
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
      const img = await new Promise<HTMLImageElement>((resolve, reject) => {
        const el = new Image();
        el.onload = () => resolve(el);
        el.onerror = reject;
        el.src = rawUrl;
      });
      const max = 960;
      const scale = Math.min(1, max / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const c = document.createElement("canvas");
      c.width = w;
      c.height = h;
      c.getContext("2d")?.drawImage(img, 0, 0, w, h);
      const dataUrl = c.toDataURL("image/jpeg", 0.88);
      onUpdateProfile({
        ...profile,
        photoDataUrl: dataUrl,
      });
      onToast("Photo updated — tap the eyes and mouth markers below to align animation.");
    } catch {
      onToast("Could not load photo.");
    }
  };

  const handleCalibratorClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const box = calibratorRef.current?.getBoundingClientRect();
    if (!box) return;
    const x = Math.min(0.95, Math.max(0.05, (e.clientX - box.left) / box.width));
    const y = Math.min(0.95, Math.max(0.05, (e.clientY - box.top) / box.height));
    const nextPoints: FacePoints = {
      ...profile.points,
      [activeMarker]: { x, y },
    };
    onUpdateProfile({ ...profile, points: nextPoints });
    if (activeMarker === "leftEye") setActiveMarker("rightEye");
    else if (activeMarker === "rightEye") setActiveMarker("mouth");
  };

  const saveNewPin = async () => {
    const clean = newPin.trim();
    if (clean.length < 4 || clean.length > 8) {
      onToast("Please enter a 4 to 8 digit PIN.");
      return;
    }
    const h = await hashPin(clean, "noor-local-pin");
    onSaveCustomPinHash(h);
    setNewPin("");
    onToast("Custom Family PIN saved on this device.");
  };

  const handleRestoreFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    try {
      const text = await file.text();
      const parsed = JSON.parse(text) as NoorBackupBundle;
      if (!parsed || typeof parsed !== "object" || !parsed.profile || !parsed.settings) {
        throw new Error("Invalid backup format");
      }
      onRestoreBackup(parsed);
    } catch {
      onToast("Could not restore backup file. Please choose a valid Noor Auto-Save .json file.");
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Noor Haram Settings"
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-sm p-3 sm:p-6"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="w-full max-w-2xl max-h-[90dvh] flex flex-col rounded-3xl bg-[#15121e] border border-white/15 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-white/10">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-[#e8b86d]" />
            <h2 className="text-base font-semibold text-[#faf6f0]">
              100 Baby Voices, AI Search &amp; Family Studio
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Close settings"
            className="min-h-[40px] min-w-[40px] rounded-xl hover:bg-white/10 text-white/75 flex items-center justify-center cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Section Tabs */}
        <div className="flex gap-2 px-5 py-3 border-b border-white/10 overflow-x-auto noor-scroll">
          {[
            { id: "voice" as const, label: "100 Baby Voices & Mic" },
            { id: "family" as const, label: "Family Mode & Memory" },
            { id: "photo" as const, label: "Photo & Calibration" },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setSection(t.id)}
              className={`min-h-[38px] px-3.5 rounded-lg text-xs font-semibold border whitespace-nowrap shrink-0 cursor-pointer ${
                section === t.id
                  ? "bg-[#e8b86d]/15 border-[#e8b86d]/50 text-[#faf6f0]"
                  : "bg-white/[0.03] border-white/10 text-white/65 hover:text-white"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto noor-scroll p-5 space-y-5">
          {section === "voice" && (
            <div className="space-y-5">
              {/* Language & Mic Settings */}
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <label htmlFor="reply-lang" className="block text-xs font-medium text-white/75">
                    Reply Language
                  </label>
                  <select
                    id="reply-lang"
                    value={settings.lang}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        lang: e.target.value as VoiceSettings["lang"],
                      })
                    }
                    className="w-full min-h-[42px] px-3 rounded-xl bg-[#1c1826] border border-white/10 text-sm text-[#faf6f0] outline-none"
                  >
                    <option value="auto">Auto (Urdu / Punjabi / English)</option>
                    <option value="roman">Pakistani Roman Urdu</option>
                    <option value="pa">Punjabi (پنجابی / Roman Punjabi)</option>
                    <option value="ur">Urdu Script (اردو)</option>
                    <option value="en">English</option>
                  </select>
                </div>

                <div className="space-y-1.5">
                  <label htmlFor="stt-lang" className="block text-xs font-medium text-white/75">
                    Microphone Recognition
                  </label>
                  <select
                    id="stt-lang"
                    value={settings.stt}
                    onChange={(e) =>
                      onUpdateSettings({
                        ...settings,
                        stt: e.target.value as VoiceSettings["stt"],
                      })
                    }
                    className="w-full min-h-[42px] px-3 rounded-xl bg-[#1c1826] border border-white/10 text-sm text-[#faf6f0] outline-none"
                  >
                    <option value="ur-PK">Urdu Pakistan (ur-PK)</option>
                    <option value="pa-IN">Punjabi (pa-IN)</option>
                    <option value="hi-IN">Roman Urdu / Hindi (hi-IN)</option>
                    <option value="en-US">English (en-US)</option>
                  </select>
                </div>
              </div>

              {/* Hands-Free Mic & Live Web Search Toggles */}
              <div className="grid sm:grid-cols-2 gap-3">
                <label className="flex items-center justify-between gap-2 rounded-xl bg-[#1c1826] border border-white/10 px-3.5 py-3 cursor-pointer">
                  <div>
                    <div className="text-xs font-semibold text-[#faf6f0]">Always-Open Mic</div>
                    <div className="text-[11px] text-white/55">Auto-listens whenever idle</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.autoListen}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, autoListen: e.target.checked })
                    }
                    className="w-4 h-4 accent-[#5eead4]"
                  />
                </label>

                <label className="flex items-center justify-between gap-2 rounded-xl bg-[#1c1826] border border-white/10 px-3.5 py-3 cursor-pointer">
                  <div>
                    <div className="text-xs font-semibold text-[#faf6f0]">Live Online Check</div>
                    <div className="text-[11px] text-white/55">Google Search for all info &amp; dawai</div>
                  </div>
                  <input
                    type="checkbox"
                    checked={settings.useSearch}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, useSearch: e.target.checked })
                    }
                    className="w-4 h-4 accent-[#5eead4]"
                  />
                </label>
              </div>

              {/* Voice Engine */}
              <div className="space-y-2">
                <span className="block text-xs font-medium text-white/75">Voice Engine</span>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, engine: "gemini" })}
                    className={`min-h-[44px] px-3.5 rounded-xl border text-left transition-colors cursor-pointer ${
                      settings.engine === "gemini"
                        ? "bg-[#e6483d]/15 border-[#e6483d]/55 text-[#faf6f0]"
                        : "bg-[#1c1826] border-white/10 text-white/70"
                    }`}
                  >
                    <div className="text-xs font-semibold">100 Real Baby-Girl Voices</div>
                    <div className="text-[11px] text-white/55">Gemini 3.8 HD Natural Voice</div>
                  </button>

                  <button
                    type="button"
                    onClick={() => onUpdateSettings({ ...settings, engine: "device" })}
                    className={`min-h-[44px] px-3.5 rounded-xl border text-left transition-colors cursor-pointer ${
                      settings.engine === "device"
                        ? "bg-[#e8b86d]/15 border-[#e8b86d]/55 text-[#faf6f0]"
                        : "bg-[#1c1826] border-white/10 text-white/70"
                    }`}
                  >
                    <div className="text-xs font-semibold">Offline Backup Voice</div>
                    <div className="text-[11px] text-white/55">Works without internet</div>
                  </button>
                </div>
              </div>

              {settings.engine === "gemini" ? (
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-medium text-white/75">
                      Choose from 100 Real Baby Girl Voices
                    </span>
                    <div className="relative">
                      <Search className="w-3.5 h-3.5 text-white/45 absolute left-2.5 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={voiceQuery}
                        onChange={(e) => setVoiceQuery(e.target.value)}
                        placeholder="Search name or 1-100…"
                        className="h-8 pl-8 pr-2.5 rounded-lg bg-[#1c1826] border border-white/10 text-xs text-[#faf6f0] outline-none"
                      />
                    </div>
                  </div>
                  <div className="max-h-64 overflow-y-auto noor-scroll grid grid-cols-1 sm:grid-cols-2 gap-2.5 pr-1">
                    {filteredGeminiVoices.map((st) => {
                      const isSelected = settings.geminiStyleId === st.id;
                      return (
                        <div
                          key={st.id}
                          className={`p-3 rounded-2xl border flex flex-col justify-between gap-2 transition-colors ${
                            isSelected
                              ? "bg-[#e8b86d]/15 border-[#e8b86d]/60 text-[#faf6f0]"
                              : "bg-[#1c1826] border-white/10 text-white/75 hover:border-white/25"
                          }`}
                        >
                          <button
                            type="button"
                            onClick={() =>
                              onUpdateSettings({ ...settings, geminiStyleId: st.id })
                            }
                            className="text-left w-full cursor-pointer"
                          >
                            <div className="text-xs font-bold flex items-center justify-between gap-1">
                              <span className="truncate">{st.label}</span>
                              {isSelected && <Check className="w-3.5 h-3.5 text-[#e8b86d] shrink-0" />}
                            </div>
                            <p className="text-[11px] text-white/55 mt-0.5 line-clamp-1">
                              {st.category} — {st.description}
                            </p>
                          </button>

                          <div className="flex items-center justify-between pt-2 border-t border-white/10">
                            <span className="text-[10px] font-mono-tabular text-[#5eead4]">
                              Voice: {st.voiceName}
                            </span>
                            <button
                              type="button"
                              onClick={() => {
                                onUpdateSettings({ ...settings, geminiStyleId: st.id });
                                onTestVoice(
                                  `[wave] Assalam o Alaikum! Main ${st.label} voice hoon. Aap kaise hain?`
                                );
                              }}
                              className="min-h-[28px] px-2.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/12 text-[11px] font-semibold text-[#e8b86d] flex items-center gap-1 cursor-pointer"
                            >
                              <Volume2 className="w-3 h-3" />
                              <span>Preview</span>
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="space-y-1.5">
                    <label htmlFor="device-voice" className="block text-xs font-medium text-white/75">
                      System Voice
                    </label>
                    <select
                      id="device-voice"
                      value={settings.voiceURI}
                      onChange={(e) => onUpdateSettings({ ...settings, voiceURI: e.target.value })}
                      className="w-full min-h-[42px] px-3 rounded-xl bg-[#1c1826] border border-white/10 text-sm text-[#faf6f0] outline-none"
                    >
                      <option value="">Auto Best Girl Voice</option>
                      {deviceVoices.map((v) => (
                        <option key={v.voiceURI} value={v.voiceURI}>
                          {v.name} ({v.lang})
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-medium text-white/75">
                        100 Offline Voice Presets
                      </span>
                      <div className="relative">
                        <Search className="w-3.5 h-3.5 text-white/45 absolute left-2.5 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={voiceQuery}
                          onChange={(e) => setVoiceQuery(e.target.value)}
                          placeholder="Search name or #…"
                          className="h-8 pl-8 pr-2.5 rounded-lg bg-[#1c1826] border border-white/10 text-xs text-[#faf6f0] outline-none"
                        />
                      </div>
                    </div>
                    <div className="max-h-40 overflow-y-auto noor-scroll grid grid-cols-2 sm:grid-cols-3 gap-1.5 pr-1">
                      {filteredOfflinePresets.map((p) => (
                        <button
                          key={p.id}
                          type="button"
                          onClick={() =>
                            onUpdateSettings({
                              ...settings,
                              preset: p.id,
                              pitch: p.pitch,
                              rate: p.rate,
                            })
                          }
                          className={`px-2.5 py-2 rounded-lg border text-left text-xs transition-colors cursor-pointer ${
                            settings.preset === p.id
                              ? "bg-[#e8b86d]/15 border-[#e8b86d]/50 text-[#faf6f0]"
                              : "bg-[#1c1826] border-white/10 text-white/75"
                          }`}
                        >
                          <span className="mr-1">{p.emoji}</span>
                          {p.name}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Speaking Speed & Device Pitch */}
              <div className="grid sm:grid-cols-2 gap-4 rounded-2xl bg-[#1c1826] border border-white/10 p-3.5">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/75">Backup Pitch</span>
                    <span className="font-mono-tabular text-[#e8b86d]">
                      {settings.pitch.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={1.0}
                    max={2.0}
                    step={0.05}
                    value={settings.pitch}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, pitch: Number(e.target.value) })
                    }
                    className="w-full accent-[#e8b86d]"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/75">Speaking Speed</span>
                    <span className="font-mono-tabular text-[#5eead4]">
                      {settings.rate.toFixed(2)}x
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.8}
                    max={1.25}
                    step={0.05}
                    value={settings.rate}
                    onChange={(e) =>
                      onUpdateSettings({ ...settings, rate: Number(e.target.value) })
                    }
                    className="w-full accent-[#5eead4]"
                  />
                </div>
              </div>

              <button
                type="button"
                onClick={() =>
                  onTestVoice(
                    settings.lang === "pa"
                      ? "[wave] Assalam o Alaikum ji! Main tuhadi pyari Dr. Noor Haram haan. Tusi kiven ho?"
                      : settings.lang === "en"
                        ? "[wave] Hello! I am Dr. Noor Haram. How are you feeling today?"
                        : "[wave] Assalam o Alaikum Ammi Abbu! Main aap ki pyari Dr. Noor Haram hoon."
                  )
                }
                className="w-full min-h-[42px] px-4 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/10 text-sm font-medium text-[#faf6f0] flex items-center justify-center gap-2 cursor-pointer"
              >
                <Volume2 className="w-4 h-4 text-[#e8b86d]" />
                <span>Hear Selected Baby Voice</span>
              </button>
            </div>
          )}

          {section === "family" && (
            <div className="space-y-4">
              {/* Multi-Phone Google Cloud Sync Card */}
              <div className="rounded-2xl bg-[#1c1826] border border-[#5eead4]/30 p-4 space-y-2.5">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Cloud className="w-4 h-4 text-[#5eead4] shrink-0" />
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-[#faf6f0] truncate">
                        Multi-Phone Cloud Sync (Worldwide)
                      </h3>
                      <p className="text-[11px] text-white/60 truncate">
                        {cloudUser
                          ? `${cloudUser.displayName || "Signed in"} (${cloudUser.email || ""})`
                          : "Sign in with Google to sync memories, chats & reminders across phones"}
                      </p>
                    </div>
                  </div>
                  {cloudUser ? (
                    <button
                      type="button"
                      onClick={onSignOutCloud}
                      className="min-h-[36px] px-3 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/15 text-xs font-semibold text-white/85 flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <LogOut className="w-3.5 h-3.5 text-[#e6483d]" />
                      <span>Sign Out</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={onSignInCloud}
                      className="min-h-[36px] px-3.5 rounded-xl bg-[#5eead4] hover:bg-[#49d9c2] text-[#0e0c14] text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <LogIn className="w-3.5 h-3.5" />
                      <span>Google Sync</span>
                    </button>
                  )}
                </div>
                {cloudUser && (
                  <div className="text-[11px] font-medium text-[#5eead4]">
                    {cloudSyncStatus === "syncing"
                      ? "Syncing encrypted workspace with cloud…"
                      : cloudSyncStatus === "error"
                        ? "Sync paused — offline or check connection"
                        : "Cloud Sync Active across all your phones & browsers"}
                  </div>
                )}
              </div>

              {/* Multi-Phone Shared Family Room (Live Sync Across Different Phones/Accounts) */}
              <div className="rounded-2xl bg-[#1c1826] border border-[#e8b86d]/35 p-4 space-y-3">
                <div className="flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2 min-w-0">
                    <Users className="w-4 h-4 text-[#e8b86d] shrink-0" />
                    <div className="min-w-0">
                      <h3 className="text-sm font-semibold text-[#faf6f0] truncate">
                        Shared Family Room (Multi-Phone Live)
                      </h3>
                      <p className="text-[11px] text-white/60">
                        Link 2+ phones with a shared Room Code to sync chats, reminders, vitals &amp; scans live
                      </p>
                    </div>
                  </div>
                </div>

                {activeRoom ? (
                  <div className="rounded-xl bg-[#120f1a] border border-white/10 p-3 space-y-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <div>
                        <div className="text-xs font-semibold text-[#faf6f0]">
                          {activeRoom.roomName}
                        </div>
                        <div className="text-[11px] font-mono-tabular text-[#5eead4] mt-0.5">
                          Code: <b>{activeRoom.roomCode}</b> · Passcode: <b>{activeRoom.passcode}</b>
                        </div>
                      </div>
                      <button
                        type="button"
                        disabled={roomBusy}
                        onClick={() => onLeaveFamilyRoom?.()}
                        className="min-h-[32px] px-3 rounded-lg bg-white/[0.06] hover:bg-[#e6483d]/20 border border-white/15 text-[11px] font-semibold text-white/85 cursor-pointer shrink-0"
                      >
                        Leave
                      </button>
                    </div>
                    <button
                      type="button"
                      onClick={async () => {
                        const base = shareAppBaseUrl || window.location.origin;
                        const link = `${base.replace(/\/$/, "")}/?room=${encodeURIComponent(
                          activeRoom.roomCode
                        )}&key=${encodeURIComponent(activeRoom.passcode)}`;
                        try {
                          await navigator.clipboard.writeText(link);
                          onToast("Family Room invite link copied — open on any 2nd phone!");
                        } catch {
                          onToast(`Share Code: ${activeRoom.roomCode} / Key: ${activeRoom.passcode}`);
                        }
                      }}
                      className="w-full min-h-[36px] px-3 rounded-xl bg-[#e8b86d]/20 hover:bg-[#e8b86d]/30 border border-[#e8b86d]/50 text-xs font-semibold text-[#e8b86d] flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy 2nd-Phone Room Invite Link</span>
                    </button>
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {!cloudUser && (
                      <p className="text-[11px] text-[#e8b86d]">
                        Sign in with Google above first, then create or join a Family Room:
                      </p>
                    )}
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={roomNameInput}
                        onChange={(e) => setRoomNameInput(e.target.value)}
                        placeholder="Room Name (e.g. Home Care)"
                        className="flex-1 min-h-[38px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs text-[#faf6f0] outline-none"
                      />
                      <button
                        type="button"
                        disabled={roomBusy || !cloudUser}
                        onClick={() => onCreateFamilyRoom?.(roomNameInput)}
                        className="min-h-[38px] px-3.5 rounded-xl bg-[#e8b86d] hover:bg-[#d8a75b] disabled:opacity-45 text-[#0e0c14] text-xs font-bold cursor-pointer shrink-0"
                      >
                        Create Room
                      </button>
                    </div>

                    <div className="grid grid-cols-[1fr_100px_auto] gap-2">
                      <input
                        type="text"
                        value={roomCodeInput}
                        onChange={(e) => setRoomCodeInput(e.target.value)}
                        placeholder="Room Code (NOOR-…)"
                        className="min-h-[38px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] outline-none"
                      />
                      <input
                        type="text"
                        value={roomPassInput}
                        onChange={(e) => setRoomPassInput(e.target.value)}
                        placeholder="Passcode"
                        className="min-h-[38px] px-2.5 rounded-xl bg-[#15121e] border border-white/10 text-xs font-mono-tabular text-[#faf6f0] outline-none"
                      />
                      <button
                        type="button"
                        disabled={roomBusy || !cloudUser || !roomCodeInput.trim()}
                        onClick={() => onJoinFamilyRoom?.(roomCodeInput, roomPassInput)}
                        className="min-h-[38px] px-3 rounded-xl bg-[#5eead4] hover:bg-[#49d9c2] disabled:opacity-45 text-[#0e0c14] text-xs font-bold cursor-pointer"
                      >
                        Join
                      </button>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex items-center justify-between gap-3 rounded-2xl bg-[#1c1826] border border-white/10 p-4">
                <div>
                  <h3 className="text-sm font-semibold text-[#faf6f0]">
                    Private Family Mode
                  </h3>
                  <p className="text-xs text-white/60 mt-0.5">
                    Unlocks extra affectionate family greetings and private family memories.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleFamilyMode(!familyMode)}
                  className={`min-h-[40px] px-3.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 border cursor-pointer shrink-0 ${
                    familyMode
                      ? "bg-[#e8b86d]/20 border-[#e8b86d]/55 text-[#e8b86d]"
                      : "bg-white/[0.04] border-white/15 text-white/80"
                  }`}
                >
                  {familyMode ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                  <span>{familyMode ? "Unlocked" : "Unlock"}</span>
                </button>
              </div>

              <div className="space-y-1.5">
                <label htmlFor="noor-name" className="block text-xs font-medium text-white/75">
                  Display Name
                </label>
                <input
                  id="noor-name"
                  type="text"
                  value={profile.name}
                  onChange={(e) => onUpdateProfile({ ...profile, name: e.target.value })}
                  className="w-full min-h-[42px] px-3.5 rounded-xl bg-[#1c1826] border border-white/10 text-sm text-[#faf6f0] outline-none"
                />
              </div>

              <div className="space-y-1.5">
                <label htmlFor="noor-about" className="block text-xs font-medium text-white/75">
                  Persona &amp; Dedication
                </label>
                <textarea
                  id="noor-about"
                  rows={3}
                  value={profile.about}
                  onChange={(e) => onUpdateProfile({ ...profile, about: e.target.value })}
                  className="w-full p-3 rounded-xl bg-[#1c1826] border border-white/10 text-sm text-[#faf6f0] outline-none resize-none"
                />
              </div>

              <div className="space-y-1.5">
                <label htmlFor="family-notes" className="block text-xs font-medium text-white/75">
                  Private Family Memories (Used when Family Mode is active)
                </label>
                <textarea
                  id="family-notes"
                  rows={3}
                  disabled={!familyMode}
                  value={profile.familyNotes}
                  onChange={(e) => onUpdateProfile({ ...profile, familyNotes: e.target.value })}
                  placeholder={
                    familyMode
                      ? "Add loving nicknames, favorite stories, or family details…"
                      : "Unlock Family Mode above to edit private memories"
                  }
                  className="w-full p-3 rounded-xl bg-[#1c1826] border border-white/10 text-sm text-[#faf6f0] disabled:opacity-50 outline-none resize-none"
                />
              </div>

              <div className="rounded-2xl bg-[#1c1826] border border-white/10 p-4 space-y-2">
                <label htmlFor="custom-pin" className="block text-xs font-medium text-white/80">
                  {customPinHash ? "Change Local Family PIN" : "Set Custom Family PIN (optional)"}
                </label>
                <div className="flex gap-2">
                  <input
                    id="custom-pin"
                    type="password"
                    inputMode="numeric"
                    maxLength={8}
                    value={newPin}
                    onChange={(e) => setNewPin(e.target.value)}
                    placeholder="4–8 digits"
                    className="flex-1 min-h-[40px] px-3 rounded-xl bg-[#15121e] border border-white/10 text-sm text-[#faf6f0] outline-none"
                  />
                  <button
                    type="button"
                    onClick={saveNewPin}
                    className="min-h-[40px] px-4 rounded-xl bg-[#e8b86d]/20 hover:bg-[#e8b86d]/30 border border-[#e8b86d]/45 text-xs font-semibold text-[#faf6f0] cursor-pointer"
                  >
                    Save PIN
                  </button>
                </div>
              </div>

              <div className="rounded-2xl bg-[#1c1826] border border-[#5eead4]/25 p-4 space-y-3">
                <input
                  ref={backupInputRef}
                  type="file"
                  accept="application/json,.json"
                  onChange={handleRestoreFile}
                  className="hidden"
                />
                <div className="flex items-center justify-between gap-2">
                  <div>
                    <h3 className="text-xs font-semibold text-[#faf6f0]">
                      Auto-Save &amp; Offline Backup
                    </h3>
                    <p className="text-[11px] text-[#5eead4] mt-0.5">
                      Auto-Save Active (Browser + IndexedDB)
                    </p>
                  </div>
                </div>
                <p className="text-[11px] text-white/60 leading-relaxed">
                  All chats, family memories, dawai reminders, voice preferences, and photo calibration
                  save automatically. Download a backup file to move or keep a safe copy.
                </p>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={onDownloadBackup}
                    className="flex-1 min-h-[40px] px-3.5 rounded-xl bg-[#5eead4]/15 hover:bg-[#5eead4]/25 border border-[#5eead4]/45 text-xs font-semibold text-[#5eead4] flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <HardDriveDownload className="w-4 h-4" />
                    <span>Download Backup (.json)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => backupInputRef.current?.click()}
                    className="flex-1 min-h-[40px] px-3.5 rounded-xl bg-white/[0.06] hover:bg-white/[0.1] border border-white/15 text-xs font-semibold text-[#faf6f0] flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <Upload className="w-4 h-4 text-[#e8b86d]" />
                    <span>Restore Backup</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {section === "photo" && (
            <div className="space-y-4">
              <input
                ref={photoInputRef}
                type="file"
                accept="image/*"
                onChange={handlePhotoUpload}
                className="hidden"
              />

              <div className="flex flex-wrap items-center justify-between gap-2">
                <button
                  type="button"
                  onClick={() => photoInputRef.current?.click()}
                  className="min-h-[40px] px-3.5 rounded-xl bg-[#e6483d]/15 hover:bg-[#e6483d]/25 border border-[#e6483d]/45 text-xs font-semibold text-[#faf6f0] flex items-center gap-1.5 cursor-pointer"
                >
                  <Camera className="w-4 h-4 text-[#e6483d]" />
                  <span>Upload Custom Photo</span>
                </button>

                <button
                  type="button"
                  onClick={() =>
                    onUpdateProfile({
                      ...profile,
                      photoDataUrl: DEFAULT_PROFILE.photoDataUrl,
                      points: DEFAULT_PROFILE.points,
                    })
                  }
                  className="min-h-[40px] px-3.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-medium text-white/80 flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Reset to Noor&apos;s Photo</span>
                </button>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-white/70">Select marker, then click photo:</span>
                {(
                  [
                    ["leftEye", "Left Eye"],
                    ["rightEye", "Right Eye"],
                    ["mouth", "Mouth"],
                  ] as Array<[LandmarkKey, string]>
                ).map(([k, label]) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setActiveMarker(k)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border cursor-pointer ${
                      activeMarker === k
                        ? "bg-[#5eead4]/20 border-[#5eead4]/60 text-[#5eead4]"
                        : "bg-[#1c1826] border-white/10 text-white/75"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>

              <div
                ref={calibratorRef}
                onClick={handleCalibratorClick}
                className="relative max-w-xs mx-auto rounded-2xl overflow-hidden border border-white/15 cursor-crosshair select-none bg-[#0e0c14]"
              >
                <img
                  src={profile.photoDataUrl}
                  alt="Facial landmark calibration preview"
                  className="w-full block pointer-events-none"
                />
                {(["leftEye", "rightEye", "mouth"] as LandmarkKey[]).map((key) => {
                  const pt = profile.points[key];
                  return (
                    <div
                      key={key}
                      style={{ left: `${pt.x * 100}%`, top: `${pt.y * 100}%` }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 shadow-md pointer-events-none ${
                        key === "mouth"
                          ? "bg-[#e6483d]/70 border-white"
                          : "bg-[#5eead4]/75 border-white"
                      }`}
                    />
                  );
                })}
              </div>

              <div className="grid sm:grid-cols-2 gap-4 rounded-2xl bg-[#1c1826] border border-white/10 p-3.5">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/75">Eye Scale</span>
                    <span className="font-mono-tabular text-[#e8b86d]">
                      {profile.points.eyeScale.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.6}
                    max={1.8}
                    step={0.04}
                    value={profile.points.eyeScale}
                    onChange={(e) =>
                      onUpdateProfile({
                        ...profile,
                        points: { ...profile.points, eyeScale: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-[#e8b86d]"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/75">Mouth Scale</span>
                    <span className="font-mono-tabular text-[#e6483d]">
                      {profile.points.mouthScale.toFixed(2)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.6}
                    max={1.8}
                    step={0.04}
                    value={profile.points.mouthScale}
                    onChange={(e) =>
                      onUpdateProfile({
                        ...profile,
                        points: { ...profile.points, mouthScale: Number(e.target.value) },
                      })
                    }
                    className="w-full accent-[#e6483d]"
                  />
                </div>
              </div>

              <label className="flex items-center justify-between rounded-xl bg-[#1c1826] border border-white/10 px-4 py-3 cursor-pointer">
                <span className="text-xs font-medium text-[#faf6f0]">
                  Articulated Body Motion (Hands, Arms, Legs, Head)
                </span>
                <input
                  type="checkbox"
                  checked={profile.bodyMode}
                  onChange={(e) => onUpdateProfile({ ...profile, bodyMode: e.target.checked })}
                  className="w-4 h-4 accent-[#e6483d]"
                />
              </label>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
