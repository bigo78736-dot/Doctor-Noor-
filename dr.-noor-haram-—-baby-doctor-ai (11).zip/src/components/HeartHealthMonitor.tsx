import { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  HeartPulse,
  MapPin,
  Stethoscope,
  Volume2,
  Wind,
} from "lucide-react";
import type { AiVitalState, VoiceSettings } from "../types/noor";

interface StateVisualProfile {
  label: string;
  subtitle: string;
  targetBpm: number;
  accent: string;
  secondary: string;
  glow: string;
  ampScale: number;
}

const STATE_PROFILES: Record<AiVitalState, StateVisualProfile> = {
  idle: {
    label: "Serene Resting",
    subtitle: "Gentle calm rhythm — Dr. Noor is here with you",
    targetBpm: 66,
    accent: "#5eead4",
    secondary: "#e8b86d",
    glow: "rgba(94, 234, 212, 0.35)",
    ampScale: 0.9,
  },
  listening: {
    label: "Attentive Listening",
    subtitle: "Softly tuned in and ready to hear your voice",
    targetBpm: 72,
    accent: "#2dd4bf",
    secondary: "#99f6e4",
    glow: "rgba(45, 212, 191, 0.42)",
    ampScale: 0.96,
  },
  thinking: {
    label: "Checking Medical Care",
    subtitle: "Carefully verifying trusted answers online",
    targetBpm: 80,
    accent: "#e8b86d",
    secondary: "#5eead4",
    glow: "rgba(232, 184, 109, 0.4)",
    ampScale: 1.0,
  },
  speaking: {
    label: "Speaking With Care",
    subtitle: "Warm baby doctor voice flowing in soothing cadence",
    targetBpm: 76,
    accent: "#e6483d",
    secondary: "#fda4af",
    glow: "rgba(230, 72, 61, 0.42)",
    ampScale: 1.04,
  },
  live_call: {
    label: "Live Voice Sync",
    subtitle: "Real-time voice & heart presence connected",
    targetBpm: 82,
    accent: "#34d399",
    secondary: "#5eead4",
    glow: "rgba(52, 211, 153, 0.42)",
    ampScale: 1.05,
  },
  offline: {
    label: "Quiet Offline Care",
    subtitle: "Resting softly in local comfort mode",
    targetBpm: 62,
    accent: "#e8b86d",
    secondary: "#cbd5e1",
    glow: "rgba(232, 184, 109, 0.28)",
    ampScale: 0.84,
  },
};

function gaussian(x: number, center: number, width: number): number {
  const z = (x - center) / width;
  return Math.exp(-0.5 * z * z);
}

/**
 * Produces a gentle, rounded P-Q-R-S-T pediatric cardiac waveform in [-0.32, +0.96]
 * for a normalized cycle position u in [0, 1).
 */
function sampleGentleEcg(u: number): number {
  const p = 0.14 * gaussian(u, 0.18, 0.038);
  const q = -0.1 * gaussian(u, 0.295, 0.014);
  const r = 0.9 * gaussian(u, 0.335, 0.018);
  const s = -0.24 * gaussian(u, 0.378, 0.016);
  const t = 0.25 * gaussian(u, 0.57, 0.055);
  const breathDrift = 0.025 * Math.sin(u * Math.PI * 2);
  return p + q + r + s + t + breathDrift;
}

function buildStaticEcgPath(width: number, height: number, cycles: number, ampScale: number): string {
  const midY = height * 0.58;
  const amp = height * 0.38 * ampScale;
  const steps = 140;
  let d = "";
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    const x = t * width;
    const u = (t * cycles) % 1;
    const y = midY - sampleGentleEcg(u) * amp;
    d += i === 0 ? `M ${x.toFixed(1)} ${y.toFixed(1)}` : ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
  }
  return d;
}

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const handler = () => setReduced(mq.matches);
    mq.addEventListener?.("change", handler);
    return () => mq.removeEventListener?.("change", handler);
  }, []);
  return reduced;
}

interface SvgFrameState {
  trailD: string;
  afterglowD: string;
  headX: number;
  headY: number;
  displayBpm: number;
  beatScale: number;
  ripple1Progress: number;
  ripple2Progress: number;
  breathRatio: number; // 0..1 inhale->exhale expansion
  breathPhaseLabel: string;
  breathProgressRing: number; // 0..1 within 10s cycle
}

function useHeartPulseAnimation(
  profile: StateVisualProfile,
  reducedMotion: boolean,
  width: number,
  height: number,
  cyclesAcross: number
): SvgFrameState {
  const targetBpmRef = useRef(profile.targetBpm);
  const ampRef = useRef(profile.ampScale);
  targetBpmRef.current = profile.targetBpm;
  ampRef.current = profile.ampScale;

  const staticPath = useMemo(
    () => buildStaticEcgPath(width, height, cyclesAcross, profile.ampScale),
    [width, height, cyclesAcross, profile.ampScale]
  );

  const [frame, setFrame] = useState<SvgFrameState>(() => ({
    trailD: staticPath,
    afterglowD: "",
    headX: width * 0.72,
    headY: height * 0.58,
    displayBpm: profile.targetBpm,
    beatScale: 1,
    ripple1Progress: 0.2,
    ripple2Progress: 0.65,
    breathRatio: 0.5,
    breathPhaseLabel: "Breathe In",
    breathProgressRing: 0,
  }));

  useEffect(() => {
    if (reducedMotion) {
      setFrame((prev) => ({
        ...prev,
        trailD: staticPath,
        afterglowD: "",
        headX: width * 0.72,
        headY: height * 0.58,
        displayBpm: targetBpmRef.current,
        beatScale: 1,
      }));
      return;
    }

    let rafId = 0;
    let lastTime = performance.now();
    let currentBpm = targetBpmRef.current;
    let currentAmp = ampRef.current;
    let beatPhase = 0;
    let sweepProgress = 0.15;
    let lastBpmUiSync = 0;
    let shownBpm = Math.round(currentBpm);

    const midY = height * 0.58;
    const samples = 132;
    const trailSpan = 0.66;
    const gapSpan = 0.055;

    const tick = (now: number) => {
      const dt = Math.min(0.06, Math.max(0.001, (now - lastTime) / 1000));
      lastTime = now;

      // Smoothly damp BPM & amplitude transitions so state switches feel serene
      const smoothFactor = 1 - Math.exp(-dt * 2.4);
      currentBpm += (targetBpmRef.current - currentBpm) * smoothFactor;
      currentAmp += (ampRef.current - currentAmp) * smoothFactor;

      const beatsPerSec = currentBpm / 60;
      beatPhase += dt * beatsPerSec;
      sweepProgress = (sweepProgress + (dt * beatsPerSec) / cyclesAcross) % 1;

      if (now - lastBpmUiSync > 350) {
        shownBpm = Math.round(currentBpm);
        lastBpmUiSync = now;
      }

      const ampPx = height * 0.38 * currentAmp;

      // Helper to evaluate waveform y at normalized x in [0, 1]
      const evalY = (nx: number) => {
        const u = (nx * cyclesAcross) % 1;
        return midY - sampleGentleEcg(u) * ampPx;
      };

      // Build active trailing curve (from sweepProgress - trailSpan to sweepProgress)
      let trailD = "";
      const trailSteps = Math.round(samples * trailSpan);
      for (let i = 0; i <= trailSteps; i++) {
        const backOffset = (1 - i / trailSteps) * trailSpan;
        let nx = sweepProgress - backOffset;
        const prevNx = nx;
        if (nx < 0) nx += 1;
        const x = nx * width;
        const y = evalY(nx);
        // Break stroke cleanly across the wraparound boundary
        const wrapped = i > 0 && prevNx < 0 && sweepProgress - ((1 - (i - 1) / trailSteps) * trailSpan) < 0 && false;
        const prevBack = (1 - (i - 1) / trailSteps) * trailSpan;
        const crossedZero = i > 0 && sweepProgress - prevBack < 0 && sweepProgress - backOffset >= 0;
        if (i === 0 || crossedZero || wrapped) {
          trailD += ` M ${x.toFixed(1)} ${y.toFixed(1)}`;
        } else {
          trailD += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
        }
      }

      // Build subtle receding afterglow ahead of the blank gap
      let afterglowD = "";
      const afterSpan = 1 - trailSpan - gapSpan;
      const afterSteps = Math.max(14, Math.round(samples * afterSpan));
      for (let i = 0; i <= afterSteps; i++) {
        const fwdOffset = gapSpan + (i / afterSteps) * afterSpan;
        const rawNx = sweepProgress + fwdOffset;
        const nx = rawNx >= 1 ? rawNx - 1 : rawNx;
        const x = nx * width;
        const y = evalY(nx);
        const prevRaw = sweepProgress + gapSpan + ((i - 1) / afterSteps) * afterSpan;
        const crossedOne = i > 0 && prevRaw < 1 && rawNx >= 1;
        if (i === 0 || crossedOne) {
          afterglowD += ` M ${x.toFixed(1)} ${y.toFixed(1)}`;
        } else {
          afterglowD += ` L ${x.toFixed(1)} ${y.toFixed(1)}`;
        }
      }

      const headX = sweepProgress * width;
      const headY = evalY(sweepProgress);

      // Lub-dub heart pulse aligned to the sweep beam's current ECG cycle phase
      const localBeatU = (sweepProgress * cyclesAcross) % 1;
      const lub = gaussian(localBeatU, 0.34, 0.055);
      const dub = 0.58 * gaussian(localBeatU, 0.48, 0.06);
      const beatScale = 1 + 0.16 * Math.max(lub, dub);

      const ripple1Progress = (localBeatU + 0.66) % 1;
      const ripple2Progress = (localBeatU + 0.16) % 1;

      // 10s coherent breathing cycle: 4s inhale, 1s soft hold, 5s exhale
      const cycle10 = (now / 1000) % 10;
      let breathRatio = 0;
      let breathPhaseLabel = "Breathe In";
      if (cycle10 < 4) {
        const p = cycle10 / 4;
        breathRatio = 0.5 - 0.5 * Math.cos(Math.PI * p);
        breathPhaseLabel = "Breathe In";
      } else if (cycle10 < 5) {
        breathRatio = 1;
        breathPhaseLabel = "Hold Softly";
      } else {
        const p = (cycle10 - 5) / 5;
        breathRatio = 0.5 + 0.5 * Math.cos(Math.PI * p);
        breathPhaseLabel = "Breathe Out";
      }

      setFrame({
        trailD: trailD.trim(),
        afterglowD: afterglowD.trim(),
        headX,
        headY,
        displayBpm: shownBpm,
        beatScale,
        ripple1Progress,
        ripple2Progress,
        breathRatio,
        breathPhaseLabel,
        breathProgressRing: cycle10 / 10,
      });

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [reducedMotion, staticPath, width, height, cyclesAcross]);

  return frame;
}

interface HeartHealthStripProps {
  aiState: AiVitalState;
  onOpenHeartTab: () => void;
}

export function HeartHealthStrip({ aiState, onOpenHeartTab }: HeartHealthStripProps) {
  const profile = STATE_PROFILES[aiState];
  const reducedMotion = usePrefersReducedMotion();
  const frame = useHeartPulseAnimation(profile, reducedMotion, 180, 36, 2);

  return (
    <button
      type="button"
      onClick={onOpenHeartTab}
      title="Open full Heart Health monitor"
      className="w-full px-4 py-2 bg-[#120f1a]/90 hover:bg-[#191524] border-b border-white/10 flex items-center justify-between gap-3 transition-colors cursor-pointer text-left"
    >
      <div className="flex items-center gap-2.5 min-w-0">
        <div
          className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 border border-white/10"
          style={{
            backgroundColor: `${profile.accent}18`,
            transform: `scale(${0.92 + (frame.beatScale - 1) * 0.7})`,
          }}
        >
          <HeartPulse className="w-4 h-4" style={{ color: profile.accent }} />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-semibold text-[#faf6f0] truncate">
              Heart Health
            </span>
            <span
              className="text-[10px] font-medium truncate"
              style={{ color: profile.accent }}
            >
              · {profile.label}
            </span>
          </div>
          <p className="text-[10px] text-white/50 truncate">
            Synced calm AI pulse · Tap for breathing guide
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2.5 shrink-0">
        <svg
          viewBox="0 0 180 36"
          aria-hidden="true"
          className="w-28 h-7 overflow-visible"
        >
          <path
            d={frame.afterglowD}
            fill="none"
            stroke={profile.accent}
            strokeWidth="1.4"
            strokeLinecap="round"
            opacity="0.22"
          />
          <path
            d={frame.trailD}
            fill="none"
            stroke={profile.accent}
            strokeWidth="1.9"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
          {!reducedMotion && (
            <circle
              cx={frame.headX}
              cy={frame.headY}
              r="2.6"
              fill={profile.accent}
            />
          )}
        </svg>
        <div className="text-right font-mono-tabular">
          <span className="text-xs font-bold text-[#faf6f0]">{frame.displayBpm}</span>
          <span className="block text-[9px] uppercase tracking-wider text-white/45">
            BPM
          </span>
        </div>
      </div>
    </button>
  );
}

interface HeartHealthMonitorProps {
  aiState: AiVitalState;
  noorName: string;
  language: VoiceSettings["lang"];
  onSpeakResult: (taggedText: string) => void;
  onOpenTriage: () => void;
  onOpenNearby: () => void;
}

export function HeartHealthMonitor({
  aiState,
  noorName,
  language,
  onSpeakResult,
  onOpenTriage,
  onOpenNearby,
}: HeartHealthMonitorProps) {
  const [previewOverride, setPreviewOverride] = useState<AiVitalState | null>(null);
  const [showBreathingGuide, setShowBreathingGuide] = useState(true);

  const effectiveState = previewOverride ?? aiState;
  const profile = STATE_PROFILES[effectiveState];
  const reducedMotion = usePrefersReducedMotion();
  const frame = useHeartPulseAnimation(profile, reducedMotion, 420, 136, 2.5);

  const firstName = noorName.split(" ")[0] || "Noor";

  const handleSpeakCalmNote = () => {
    if (language === "en") {
      onSpeakResult(
        `[heart] Assalam-o-Alaikum, I am Dr. ${firstName}. Take a slow, peaceful breath in with me... and gently breathe out. Your calm presence helps the whole family feel safe.`
      );
    } else if (language === "ur") {
      onSpeakResult(
        `[heart] السلام علیکم! میں ڈاکٹر ${firstName} ہوں۔ آئیے میرے ساتھ آہستہ سے گہری سانس لیں اور آرام سے چھوڑیں۔ اللہ آپ کے دل کو ہمیشہ سکون اور صحت عطا فرمائے۔`
      );
    } else if (language === "pa") {
      onSpeakResult(
        `[heart] Assalam-o-Alaikum! Main Dr. ${firstName} haan. Mere naal hauli jehi lambi saah lao te aaram naal chhado — Allah tuhade dil nu hamesha sukoon te sehat rakhe.`
      );
    } else {
      onSpeakResult(
        `[heart] Assalam-o-Alaikum! Main Dr. ${firstName} hoon. Aaiye mere saath aahista se gehri saans lein... aur sukoon se bahar chhodein. Allah aap ke dil ko hamesha chain aur sehat de.`
      );
    }
  };

  const breathCircumference = 2 * Math.PI * 22;
  const breathStrokeOffset = breathCircumference * (1 - frame.breathProgressRing);

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-semibold text-[#faf6f0]">
              Heart Health &amp; Calm Pulse
            </h2>
            <span
              className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-md border"
              style={{
                color: profile.accent,
                borderColor: `${profile.accent}45`,
                backgroundColor: `${profile.accent}15`,
              }}
            >
              {previewOverride ? "Preview" : "Live AI Sync"}
            </span>
          </div>
          <p className="text-xs text-white/60 leading-relaxed">
            A gentle, soothing heartbeat monitor synced in real time with Dr. {firstName}&apos;s
            current voice and thinking state.
          </p>
        </div>
      </div>

      {/* Main SVG Heartbeat Visualization Card */}
      <div
        className="rounded-2xl bg-[#120f1a] border border-white/10 p-4 space-y-3 shadow-inner relative overflow-hidden"
        style={{
          boxShadow: `inset 0 0 42px ${profile.glow.replace(/0\.\d+\)$/, "0.10)")}`,
        }}
      >
        {/* Top Status Row: Animated Beating Heart Emblem + Live Cadence Readout */}
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <svg
              viewBox="0 0 64 64"
              aria-hidden="true"
              className="w-14 h-14 shrink-0 overflow-visible"
            >
              <defs>
                <radialGradient id="heartAuraGrad" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor={profile.accent} stopOpacity="0.38" />
                  <stop offset="100%" stopColor={profile.accent} stopOpacity="0" />
                </radialGradient>
              </defs>

              {/* Soft ambient aura */}
              <circle cx="32" cy="32" r="28" fill="url(#heartAuraGrad)" />

              {/* Expanding calming ripple rings synced to each beat */}
              {!reducedMotion && (
                <>
                  <circle
                    cx="32"
                    cy="32"
                    r={14 + frame.ripple1Progress * 16}
                    fill="none"
                    stroke={profile.accent}
                    strokeWidth="1.2"
                    opacity={(1 - frame.ripple1Progress) * 0.45}
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r={14 + frame.ripple2Progress * 16}
                    fill="none"
                    stroke={profile.secondary}
                    strokeWidth="1"
                    opacity={(1 - frame.ripple2Progress) * 0.32}
                  />
                </>
              )}

              {/* Beating SVG Heart */}
              <g
                transform={`translate(32 33) scale(${frame.beatScale}) translate(-12 -12)`}
              >
                <path
                  d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"
                  fill={profile.accent}
                  fillOpacity="0.92"
                  stroke="#faf6f0"
                  strokeOpacity="0.35"
                  strokeWidth="0.9"
                />
              </g>
            </svg>

            <div className="min-w-0">
              <div className="flex items-center gap-1.5">
                <Activity className="w-3.5 h-3.5 shrink-0" style={{ color: profile.accent }} />
                <span className="text-sm font-semibold text-[#faf6f0] truncate">
                  {profile.label}
                </span>
              </div>
              <p className="text-xs text-white/60 leading-snug mt-0.5">
                {profile.subtitle}
              </p>
            </div>
          </div>

          <div className="text-right shrink-0 pl-2">
            <div className="flex items-baseline justify-end gap-1 font-mono-tabular">
              <span
                className="text-2xl font-bold tracking-tight"
                style={{ color: profile.accent }}
              >
                {frame.displayBpm}
              </span>
              <span className="text-[11px] font-semibold uppercase text-white/55">
                BPM
              </span>
            </div>
            <span className="block text-[10px] text-white/45">
              AI Calm Cadence
            </span>
          </div>
        </div>

        {/* Continuous Calming PQRST SVG Waveform Oscilloscope */}
        <div className="rounded-xl bg-[#0b0911] border border-white/10 p-2 relative">
          <svg
            viewBox="0 0 420 136"
            role="img"
            aria-label={`Heartbeat pulse visualization in ${profile.label} state at ${frame.displayBpm} beats per minute`}
            className="w-full h-[136px] block"
          >
            <defs>
              <pattern id="ecgMinorGrid" width="14" height="14" patternUnits="userSpaceOnUse">
                <path
                  d="M 14 0 L 0 0 0 14"
                  fill="none"
                  stroke="rgba(255,255,255,0.035)"
                  strokeWidth="0.7"
                />
              </pattern>
              <pattern id="ecgMajorGrid" width="70" height="70" patternUnits="userSpaceOnUse">
                <rect width="70" height="70" fill="url(#ecgMinorGrid)" />
                <path
                  d="M 70 0 L 0 0 0 70"
                  fill="none"
                  stroke="rgba(255,255,255,0.075)"
                  strokeWidth="0.9"
                />
              </pattern>
              <filter id="ecgGlow" x="-15%" y="-30%" width="130%" height="160%">
                <feGaussianBlur stdDeviation="2.6" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>

            {/* Subtle clinical grid */}
            <rect width="420" height="136" fill="url(#ecgMajorGrid)" rx="8" />

            {/* Soft baseline reference */}
            <line
              x1="0"
              y1="79"
              x2="420"
              y2="79"
              stroke="rgba(255,255,255,0.08)"
              strokeDasharray="3 5"
              strokeWidth="1"
            />

            {/* Receding phosphor afterglow */}
            {frame.afterglowD && (
              <path
                d={frame.afterglowD}
                fill="none"
                stroke={profile.accent}
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                opacity="0.2"
              />
            )}

            {/* Active flowing P-Q-R-S-T pulse trace */}
            <path
              d={frame.trailD}
              fill="none"
              stroke={profile.accent}
              strokeWidth="2.6"
              strokeLinecap="round"
              strokeLinejoin="round"
              filter="url(#ecgGlow)"
            />

            {/* Soft leading pulse dot */}
            {!reducedMotion && (
              <g>
                <circle
                  cx={frame.headX}
                  cy={frame.headY}
                  r="10"
                  fill={profile.accent}
                  opacity="0.22"
                />
                <circle
                  cx={frame.headX}
                  cy={frame.headY}
                  r="4.2"
                  fill="#faf6f0"
                  stroke={profile.accent}
                  strokeWidth="2"
                />
              </g>
            )}
          </svg>
        </div>

        {/* Sync Status Indicator Text Underneath ECG Monitor (Green = AI Processing, Red = Standby) */}
        {(() => {
          const isProcessing =
            effectiveState === "thinking" ||
            effectiveState === "speaking" ||
            effectiveState === "listening" ||
            effectiveState === "live_call";
          return (
            <div
              role="status"
              aria-live="polite"
              className="flex items-center justify-between gap-2 px-2.5 py-1.5 rounded-lg bg-[#0b0911]/85 border border-white/10"
            >
              <div className="flex items-center gap-2 min-w-0">
                <span
                  className={`w-2.5 h-2.5 rounded-full shrink-0 transition-colors ${
                    isProcessing
                      ? "bg-[#22c55e] shadow-[0_0_10px_2px_rgba(34,197,94,0.85)] animate-pulse"
                      : "bg-[#ef4444] shadow-[0_0_10px_2px_rgba(239,68,68,0.85)]"
                  }`}
                />
                <span
                  className={`text-xs font-semibold tracking-wide transition-colors ${
                    isProcessing
                      ? "text-[#4ade80] drop-shadow-[0_0_8px_rgba(74,222,128,0.8)]"
                      : "text-[#f87171] drop-shadow-[0_0_8px_rgba(248,113,113,0.8)]"
                  }`}
                >
                  {isProcessing
                    ? `Sync Status: Active AI Processing (${profile.label})`
                    : "Sync Status: Standby Mode"}
                </span>
              </div>
              <span className="text-[10px] font-mono-tabular uppercase tracking-wider text-white/45 shrink-0">
                {isProcessing ? "LIVE" : "IDLE"}
              </span>
            </div>
          );
        })()}

        {/* Descriptive Legend for Heart Rate Measurements */}
        <div className="rounded-xl bg-[#0b0911]/90 border border-white/10 p-3 space-y-2">
          <div className="flex items-center justify-between text-[11px] font-semibold text-[#faf6f0]">
            <span>Heart Rate Measurement Legend</span>
            <span className="text-white/45">Standard Clinical Ranges</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            <div className="rounded-lg bg-white/[0.04] p-2 space-y-1 border border-white/5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#5eead4]" />
                <span className="text-[11px] font-medium text-white/90">Resting</span>
              </div>
              <p className="text-[10px] text-white/55 font-mono-tabular">60 - 80 BPM (Idle)</p>
            </div>
            <div className="rounded-lg bg-white/[0.04] p-2 space-y-1 border border-white/5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#e8b86d]" />
                <span className="text-[11px] font-medium text-white/90">Active / AI</span>
              </div>
              <p className="text-[10px] text-white/55 font-mono-tabular">81 - 110 BPM (Sync)</p>
            </div>
            <div className="rounded-lg bg-white/[0.04] p-2 space-y-1 border border-white/5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#e6483d]" />
                <span className="text-[11px] font-medium text-white/90">Peak / Alert</span>
              </div>
              <p className="text-[10px] text-white/55 font-mono-tabular">&gt; 110 BPM (Elevated)</p>
            </div>
            <div className="rounded-lg bg-white/[0.04] p-2 space-y-1 border border-white/5">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#22c55e]" />
                <span className="text-[11px] font-medium text-white/90">Normal Range</span>
              </div>
              <p className="text-[10px] text-white/55 font-mono-tabular">60 - 100 BPM</p>
            </div>
          </div>
        </div>

        {/* Coherent Calming Breathing Sync Pacer */}
        <div className="rounded-xl bg-[#1c1826]/80 border border-white/10 p-3 flex items-center justify-between gap-3">
          {showBreathingGuide ? (
            <div className="flex items-center gap-3 min-w-0">
              <svg
                viewBox="0 0 56 56"
                aria-hidden="true"
                className="w-12 h-12 shrink-0"
              >
                <circle
                  cx="28"
                  cy="28"
                  r="22"
                  fill="none"
                  stroke="rgba(255,255,255,0.1)"
                  strokeWidth="3"
                />
                <circle
                  cx="28"
                  cy="28"
                  r="22"
                  fill="none"
                  stroke={profile.secondary}
                  strokeWidth="3"
                  strokeLinecap="round"
                  strokeDasharray={breathCircumference}
                  strokeDashoffset={breathStrokeOffset}
                  transform="rotate(-90 28 28)"
                />
                <circle
                  cx="28"
                  cy="28"
                  r={7 + frame.breathRatio * 9}
                  fill={profile.accent}
                  fillOpacity={0.22 + frame.breathRatio * 0.28}
                />
                <circle
                  cx="28"
                  cy="28"
                  r={4 + frame.breathRatio * 3.5}
                  fill={profile.accent}
                />
              </svg>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <Wind className="w-3.5 h-3.5 text-[#5eead4] shrink-0" />
                  <span className="text-xs font-semibold text-[#faf6f0]">
                    {frame.breathPhaseLabel}
                  </span>
                </div>
                <p className="text-[11px] text-white/55 leading-snug">
                  Calm 4-1-5 breathing rhythm synced for parent &amp; child comfort
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-center gap-2 text-xs text-white/60">
              <Wind className="w-4 h-4 text-white/40" />
              <span>Breathing guide paused</span>
            </div>
          )}

          <button
            type="button"
            onClick={() => setShowBreathingGuide((v) => !v)}
            className="min-h-[34px] px-3 rounded-lg bg-white/[0.06] hover:bg-white/[0.12] border border-white/10 text-xs font-medium text-[#faf6f0] shrink-0 cursor-pointer"
          >
            {showBreathingGuide ? "Hide Pacer" : "Show Pacer"}
          </button>
        </div>
      </div>

      {/* Sync Mode Switcher: Live AI vs Previewing Each AI State */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-medium text-white/75">
            AI State Pulse Sync
          </span>
          {previewOverride && (
            <button
              type="button"
              onClick={() => setPreviewOverride(null)}
              className="text-[11px] font-semibold text-[#5eead4] hover:underline cursor-pointer"
            >
              Return to Live AI State
            </button>
          )}
        </div>
        <div className="grid grid-cols-3 gap-1.5">
          {(
            [
              { id: null, label: "Live Sync" },
              { id: "idle", label: "Resting" },
              { id: "listening", label: "Listening" },
              { id: "thinking", label: "Thinking" },
              { id: "speaking", label: "Speaking" },
              { id: "live_call", label: "Live Call" },
            ] as Array<{ id: AiVitalState | null; label: string }>
          ).map((item) => {
            const active = previewOverride === item.id;
            return (
              <button
                key={item.label}
                type="button"
                onClick={() => setPreviewOverride(item.id)}
                className={`min-h-[36px] px-2.5 rounded-lg text-xs font-medium border transition-colors cursor-pointer ${
                  active
                    ? "bg-[#5eead4]/15 border-[#5eead4]/55 text-[#faf6f0]"
                    : "bg-[#1c1826] border-white/10 text-white/70 hover:text-white"
                }`}
              >
                {item.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Helpful Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
        <button
          type="button"
          onClick={handleSpeakCalmNote}
          className="min-h-[42px] px-3.5 rounded-xl bg-[#e6483d] hover:bg-[#d13b30] text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <Volume2 className="w-4 h-4" />
          <span>Hear Calm Breathing Note</span>
        </button>
        <button
          type="button"
          onClick={onOpenTriage}
          className="min-h-[42px] px-3.5 rounded-xl bg-[#1c1826] hover:bg-[#272136] border border-white/10 text-[#faf6f0] text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
        >
          <Stethoscope className="w-4 h-4 text-[#e8b86d]" />
          <span>Symptom Checkup</span>
        </button>
      </div>

      <button
        type="button"
        onClick={onOpenNearby}
        className="w-full min-h-[40px] px-3.5 rounded-xl bg-[#1c1826]/70 hover:bg-[#1c1826] border border-white/10 text-xs font-medium text-[#5eead4] flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
      >
        <MapPin className="w-3.5 h-3.5" />
        <span>Find Nearby Cardiology / Hospitals &amp; Emergency Care</span>
      </button>

      <p className="text-[11px] text-white/45 leading-relaxed">
        Note: This calm pulse reflects Dr. {firstName}&apos;s live AI state for comfort and breathing
        support—not a physical heart-rate sensor. For chest pain, fast breathing, or emergencies,
        seek urgent care or call 1122.
      </p>
    </div>
  );
}
